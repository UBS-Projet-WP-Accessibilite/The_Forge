(function(){
  const root=document.getElementById('rgaa-root'); if(!root) return;
  const CFG=typeof RGAA_AUDIT_SETTINGS!=='undefined'?RGAA_AUDIT_SETTINGS:{statuses:['fail','manual','pass','wip'],themes:[1,2,3,4,5,6,7,8,9,10,11,12,13],home:'/'};
  const STATUS_LABEL={fail:'fail',manual:'manual',pass:'pass',wip:'en cours'};
  const THEMES=[{id:1,name:'Images',tests:['1.1','1.2','1.3']},{id:2,name:'Cadres',tests:['2.1','2.2']},{id:3,name:'Couleurs',tests:['3.1','3.2']},{id:4,name:'Multimédia',tests:['4.1','4.2']},{id:5,name:'Tableaux',tests:['5.1','5.2','5.3']},{id:6,name:'Liens',tests:['6.1','6.2']},{id:7,name:'Scripts',tests:['7.1','7.2','7.3']},{id:8,name:'Éléments obligatoires',tests:['8.1','8.2']},{id:9,name:'Structuration de l’information',tests:['9.1','9.2','9.3']},{id:10,name:'Présentation de l’information',tests:['10.1','10.2']},{id:11,name:'Formulaires',tests:['11.1','11.2','11.3']},{id:12,name:'Navigation',tests:['12.1','12.2','12.3']},{id:13,name:'Consultation',tests:['13.1','13.2']}];
  const THEMES_MAP=new Map(THEMES.map(t=>[String(t.id),t]));

  root.innerHTML='\
  <div class="rgaa-row">\
    <div class="rgaa-col">\
      <label>URL de la page active\
        <input id="rgaa-url" type="text" style="width:100%" placeholder="https://exemple.com/page"/>\
      </label>\
    </div>\
    <div style="display:flex;gap:8px;align-items:flex-end">\
      <button id="rgaa-home" class="button" aria-label="Aller à l’accueil"><span class="dashicons dashicons-admin-home"></span> Accueil</button>\
      <button id="rgaa-scan" class="button button-primary">Lancer</button>\
      <button id="rgaa-export" class="button">Export JSON (page)</button>\
    </div>\
  </div>\
  <div class="rgaa-two-col">\
    <div class="rgaa-preview"><iframe id="rgaa-frame" class="rgaa-iframe" sandbox="allow-same-origin allow-scripts allow-forms"></iframe></div>\
    <div class="rgaa-panel"><div id="rgaa-panel-scroll" class="rgaa-panel-scroll">\
      <strong>Résumé (page courante)</strong>\
      <div id="rgaa-summary">En attente…</div>\
      <div style="margin-top:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">\
        <label>Statut <select id="rgaa-filter-status"></select></label>\
        <label>Catégorie <select id="rgaa-filter-theme"></select></label>\
      </div>\
      <div id="rgaa-placeholders" style="margin:8px 0; display:none"></div>\
      <table id="rgaa-issues"><thead><tr><th>#</th><th>Type</th><th>Catégorie</th><th>Règle</th><th>Statut</th><th>Message</th><th>Action</th></tr></thead><tbody></tbody></table>\
    </div></div>\
  </div>\
  <div class="rgaa-queue-wrap">\
    <strong>File d’URLs</strong>\
    <textarea id="rgaa-urls-text" placeholder="https://exemple.com/\nhttps://exemple.com/page-2"></textarea>\
    <div style="margin-top:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">\
      <button id="rgaa-queue-add" class="button">Ajouter à la file</button>\
      <button id="rgaa-queue-sitemap" class="button">Charger WP Sitemap</button>\
      <label>Limite <input id="rgaa-sitemap-limit" type="number" min="1" max="2000" value="200" style="width:80px"></label>\
      <button id="rgaa-queue-start" class="button button-primary">Démarrer</button>\
      <button id="rgaa-queue-stop" class="button">Arrêter</button>\
      <button id="rgaa-queue-clear" class="button">Vider</button>\
      <button id="rgaa-queue-export-json" class="button">Export JSON (lot)</button>\
      <button id="rgaa-queue-export-csv" class="button">Export CSV (lot)</button>\
    </div>\
    <div class="rgaa-progress"><div id="rgaa-progress-bar" class="rgaa-progress-bar"></div></div>\
    <table id="rgaa-queue"><thead><tr><th>#</th><th>URL</th><th>Statut</th><th>Échecs</th><th>À vérifier</th><th>OK</th><th>Durée (s)</th></tr></thead><tbody></tbody></table>\
  </div>';

  const statusSelect=document.getElementById('rgaa-filter-status');
  const allStatuses=['fail','manual','pass','wip'];
  const enabledStatuses=(CFG.statuses||allStatuses).filter(s=>allStatuses.includes(s));
  statusSelect.innerHTML='<option value="all">Tous</option>'+enabledStatuses.map(s=>`<option value="${s}">${STATUS_LABEL[s]||s}</option>`).join('');
  const themeSelect=document.getElementById('rgaa-filter-theme');
  const enabledThemes=(CFG.themes||[]).map(String);
  themeSelect.innerHTML='<option value="all">Toutes</option>'+[{id:1,name:'Images'},{id:2,name:'Cadres'},{id:3,name:'Couleurs'},{id:4,name:'Multimédia'},{id:5,name:'Tableaux'},{id:6,name:'Liens'},{id:7,name:'Scripts'},{id:8,name:'Éléments obligatoires'},{id:9,name:'Structuration de l’information'},{id:10,name:'Présentation de l’information'},{id:11,name:'Formulaires'},{id:12,name:'Navigation'},{id:13,name:'Consultation'}].filter(t=>enabledThemes.length===0||enabledThemes.includes(String(t.id))).map(t=>`<option value="${t.id}">${t.id}. ${t.name}</option>`).join('');

  const $=(s,c=document)=>c.querySelector(s), $$=(s,c=document)=>Array.from(c.querySelectorAll(s)), byId=id=>document.getElementById(id);
  const iframe=byId('rgaa-frame'), urlInput=byId('rgaa-url'), panelScroll=byId('rgaa-panel-scroll');
  const issues=[];
  function syncPanelHeight(){ const h=iframe.clientHeight||600; panelScroll.style.height=h+'px'; }
  window.addEventListener('resize',syncPanelHeight);
  function updateUrlBar(){ try{ const href=iframe.contentWindow.location.href; if(href) urlInput.value=href; }catch(e){} }
  iframe.addEventListener('load',()=>{ syncPanelHeight(); updateUrlBar(); });

  byId('rgaa-home').addEventListener('click',()=>{ iframe.src=CFG.home||'/'; });
  urlInput.addEventListener('keydown',e=>{ if(e.key==='Enter'){ e.preventDefault(); const v=urlInput.value.trim(); if(v) iframe.src=v; }});

  const queue=[]; let running=false, stopFlag=false;
  function setProgress(p){ byId('rgaa-progress-bar').style.width=Math.max(0,Math.min(100,p))+'%'; }
  function statusClass(s){ return s==='pending'?'status-pending':s==='running'?'status-running':s==='done'?'status-done':'status-error'; }

  function renderQueue(){ const tbody=$('#rgaa-queue tbody'); tbody.innerHTML=''; queue.forEach((it,idx)=>{ const tr=document.createElement('tr'); tr.innerHTML=`<td>${idx+1}</td><td><a href="${escapeHtml(it.url)}" target="_blank" rel="noopener">${escapeHtml(it.url)}</a></td><td><span class="rgaa-status ${statusClass(it.status)}">${it.status}</span></td><td>${it.counts?.fail??''}</td><td>${it.counts?.manual??''}</td><td>${it.counts?.pass??''}</td><td>${it.durationMs?(it.durationMs/1000).toFixed(1):''}</td>`; tbody.appendChild(tr); }); const done=queue.filter(q=>q.status==='done'||q.status==='error').length; const p=queue.length?(done*100/queue.length):0; setProgress(p); }

  async function loadWPSitemap(limit){ const indexUrl=new URL('/wp-sitemap.xml',location.origin).toString(); try{ const res=await fetch(indexUrl,{credentials:'include'}); if(!res.ok) throw new Error('HTTP '+res.status); const xml=await res.text(); const doc=new DOMParser().parseFromString(xml,'application/xml'); let urls=[]; if(doc.querySelector('sitemapindex')){ const sitemaps=Array.from(doc.querySelectorAll('sitemap > loc')).map(n=>n.textContent.trim()); for(const sm of sitemaps){ if(urls.length>=limit) break; try{ const r=await fetch(sm,{credentials:'include'}); if(!r.ok) continue; const x=await r.text(); const d=new DOMParser().parseFromString(x,'application/xml'); const locs=Array.from(d.querySelectorAll('url > loc')).map(n=>n.textContent.trim()); for(const u of locs){ if(urls.length>=limit) break; urls.push(u); } }catch(_){} } } else { urls=Array.from(doc.querySelectorAll('url > loc')).map(n=>n.textContent.trim()).slice(0,limit); } return urls; }catch(e){ alert('Chargement du sitemap impossible: '+e.message); return []; } }

  function mapTypeToThemeId(type){ if(type==='images') return 1; if(type==='contrast') return 3; if(type==='aria') return 7; return null; }
  const ARIA_MAP={button:{requiresName:true,allowed:['aria-pressed','aria-expanded','aria-controls','aria-disabled']},link:{requiresName:true,allowed:['aria-expanded','aria-controls','aria-current','aria-disabled']},img:{requiresName:true,allowed:['aria-label','aria-labelledby','aria-describedby']},checkbox:{requiresName:true,allowed:['aria-checked','aria-disabled','aria-labelledby','aria-label']},switch:{requiresName:true,allowed:['aria-checked','aria-disabled','aria-labelledby','aria-label']},menuitem:{requiresName:true,allowed:['aria-checked','aria-haspopup']},tab:{requiresName:true,allowed:['aria-selected','aria-controls']},textbox:{requiresName:true,allowed:['aria-required','aria-invalid','aria-describedby','aria-label','aria-labelledby']},dialog:{requiresName:true,allowed:['aria-modal','aria-labelledby','aria-label','aria-describedby']}};

  let RGAA_COUNTER=0;
  function tag(el){ if(!el||!el.setAttribute) return null; let id=el.getAttribute('data-rgaa-id'); if(!id){ id='rgaa-'+(++RGAA_COUNTER); el.setAttribute('data-rgaa-id',id);} return id; }
  function findByIssue(doc,issue){ if(issue.eid){ const el=doc.querySelector(`[data-rgaa-id="${issue.eid}"]`); if(el) return el; } return issue.selector?doc.querySelector(issue.selector):null; }
  function isScrollable(el){ const cs=iframe.contentWindow.getComputedStyle(el); return /(auto|scroll)/.test(cs.overflow+cs.overflowY+cs.overflowX); }
  function scrollAncestors(el,offsetTop=80){ const doc=iframe.contentDocument; const anc=[]; for(let e=el.parentElement; e&&e!==doc.body; e=e.parentElement){ if(isScrollable(e)) anc.push(e); } anc.push(doc.scrollingElement||doc.documentElement); const r=el.getBoundingClientRect(); const header=doc.querySelector('header,.site-header,[role="banner"]'); let headerH=0; if(header){ const cs=iframe.contentWindow.getComputedStyle(header); if(cs.position==='fixed'){ headerH=header.getBoundingClientRect().height; } } const mainScroller=anc[anc.length-1]; const topAdj=r.top+(mainScroller.scrollTop||iframe.contentWindow.scrollY||0)-(headerH+offsetTop); mainScroller.scrollTo({top:topAdj,behavior:'smooth'}); for(const a of anc.slice(0,-1)){ const ar=a.getBoundingClientRect(); const dy=r.top-ar.top-20; a.scrollTop+=dy; } }
  function ensureOverlay(){ const doc=iframe.contentDocument; let host=doc.getElementById('rgaa-overlay-host'); if(host) return host; host=doc.createElement('div'); host.id='rgaa-overlay-host'; host.style.position='fixed'; host.style.left=0; host.style.top=0; host.style.right=0; host.style.bottom=0; host.style.pointerEvents='none'; host.style.zIndex=2147483647; const style=doc.createElement('style'); style.textContent=' .rgaa-pin{position:fixed; transform:translate(-50%,-100%); background:#111; color:#fff; font:600 12px/1.6 system-ui; padding:2px 6px; border-radius:12px; box-shadow:0 2px 8px rgba(0,0,0,.25)} .rgaa-halo{position:fixed; outline:3px solid #f80; outline-offset:-3px; border-radius:2px; animation:rgaaPulse .9s ease-out 1} @keyframes rgaaPulse{0%{outline-color:rgba(255,136,0,.2)}100%{outline-color:#f80}} .rgaa-tooltip{position:fixed; background:#fff; color:#111; border:1px solid #ddd; border-radius:6px; padding:6px 8px; font:12px/1.4 system-ui; box-shadow:0 2px 10px rgba(0,0,0,.15); max-width:320px} '; doc.head.appendChild(style); doc.body.appendChild(host); return host; }
  let currentMark=null;
  function pin(el,index,issue){ const doc=iframe.contentDocument,win=iframe.contentWindow; const host=ensureOverlay(); if(currentMark){ currentMark.remove(); currentMark=null; } const r=el.getBoundingClientRect(); const halo=doc.createElement('div'); halo.className='rgaa-halo'; Object.assign(halo.style,{left:r.left+'px',top:r.top+'px',width:r.width+'px',height:r.height+'px'}); const label=doc.createElement('div'); label.className='rgaa-pin'; label.textContent=String(index+1); const px=Math.max(8,Math.min(win.innerWidth-8,r.left+r.width)); const py=Math.max(16,r.top); Object.assign(label.style,{left:px+'px',top:py+'px'}); const tip=doc.createElement('div'); tip.className='rgaa-tooltip'; tip.textContent=`${issue.type} • ${(issue.themeName||'')} • ${issue.rule||''} • ${issue.status}`; Object.assign(tip.style,{left:Math.max(8,r.left)+'px',top:(r.bottom+8)+'px'}); const wrap=doc.createElement('div'); wrap.style.position='fixed'; wrap.style.left=0; wrap.style.top=0; wrap.style.right=0; wrap.style.bottom=0; wrap.style.pointerEvents='none'; wrap.appendChild(halo); wrap.appendChild(label); wrap.appendChild(tip); host.appendChild(wrap); currentMark=wrap; const upd=()=>{ const rr=el.getBoundingClientRect(); Object.assign(halo.style,{left:rr.left+'px',top:rr.top+'px',width:rr.width+'px',height:rr.height+'px'}); Object.assign(label.style,{left:Math.max(8,Math.min(win.innerWidth-8,rr.left+rr.width))+'px',top:Math.max(16,rr.top)+'px'}); Object.assign(tip.style,{left:Math.max(8,rr.left)+'px',top:(rr.bottom+8)+'px'}); }; const ro=new win.ResizeObserver(upd); ro.observe(doc.documentElement); win.addEventListener('scroll',upd,{passive:true}); setTimeout(upd,0); }

  function escapeHtml(s){ return (s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  async function waitForEl(issue,timeoutMs){ const doc=iframe.contentDocument; const start=performance.now(); return new Promise(resolve=>{ const tryFind=()=>{ const el=findByIssue(doc,issue); if(el) return resolve(el); if(performance.now()-start>timeoutMs) return resolve(null); requestAnimationFrame(tryFind); }; tryFind(); }); }
  async function highlightIssue(index){ const it=issues[index]; if(!it||!iframe.contentDocument) return; const el=await waitForEl(it,1500); if(!el){ alert('Élément introuvable.'); return; } scrollAncestors(el); pin(el,index,it); el.setAttribute('tabindex','-1'); el.focus({preventScroll:true}); setTimeout(()=>{ try{ el.removeAttribute('tabindex'); }catch(_){ } },1000); }

  function updateSummary(){ const counts={fail:0,manual:0,pass:0}; for(const it of issues){ counts[it.status]=(counts[it.status]||0)+1; } $('#rgaa-summary').innerHTML=`<span class="rgaa-badge badge-fail">échecs: ${counts.fail||0}</span> <span class="rgaa-badge badge-manual">à vérifier: ${counts.manual||0}</span> <span class="rgaa-badge badge-pass">ok: ${counts.pass||0}</span> <div>Total: ${issues.length}</div>`; }
  function renderPlaceholders(themeId){ const holder=byId('rgaa-placeholders'); if(themeId==='all'||!THEMES_MAP.get(String(themeId))){ holder.style.display='none'; holder.innerHTML=''; return;} const t=THEMES_MAP.get(String(themeId)); holder.style.display='block'; holder.innerHTML='<div><strong>Placeholders — '+t.name+'</strong></div>'+t.tests.map(code=>`<span class="rgaa-chip">Critère ${code} — en cours</span>`).join(''); }
  function addPlaceholderRows(tbody,themeId){ const t=THEMES_MAP.get(String(themeId)); if(!t) return; t.tests.forEach(code=>{ const tr=document.createElement('tr'); tr.className='rgaa-wip'; tr.innerHTML=`<td>–</td><td>placeholder</td><td>${t.name}</td><td>${code}</td><td><span class="rgaa-badge badge-manual">en cours</span></td><td>Critère ${code} non encore implémenté</td><td><span class="button disabled">Voir</span></td>`; tbody.appendChild(tr); }); }
  function renderTable(){ const tbody=$('#rgaa-issues tbody'); const filterStatus=byId('rgaa-filter-status').value; const filterTheme=byId('rgaa-filter-theme').value; tbody.innerHTML=''; let n=0; if(filterStatus==='wip'){ if(filterTheme==='all'){ const tr=document.createElement('tr'); tr.className='rgaa-wip'; tr.innerHTML='<td>–</td><td colspan="6">Sélectionnez une catégorie pour voir les critères "en cours".</td>'; tbody.appendChild(tr); } else { addPlaceholderRows(tbody,filterTheme); } renderPlaceholders(filterTheme); return; } const filtered=issues.filter(it=>{ const okTheme=filterTheme==='all'||String(it.themeId||'')===String(filterTheme); const okStatus=filterStatus==='all'||it.status===filterStatus; return okTheme&&okStatus; }); filtered.forEach(it=>{ const tr=document.createElement('tr'); tr.innerHTML=`<td>${++n}</td><td>${it.type}</td><td>${it.themeName||''}</td><td>${it.rule||''}</td><td><span class="rgaa-badge ${it.status==='fail'?'badge-fail':it.status==='manual'?'badge-manual':'badge-pass'}">${it.status}</span></td><td>${escapeHtml(it.message||'')}</td><td><a class="button" href="#rgaa=${issues.indexOf(it)}">Voir</a></td>`; tbody.appendChild(tr); }); $$('a.button[href^="#rgaa="]',tbody).forEach(a=>{ a.addEventListener('click',ev=>{ ev.preventDefault(); const idx=parseInt(a.getAttribute('href').split('=')[1],10); if(Number.isFinite(idx)){ location.hash=`#rgaa=${idx}`; highlightIssue(idx); } }); }); renderPlaceholders(filterTheme); }
  function countsFromIssues(arr){ const c={fail:0,manual:0,pass:0}; arr.forEach(i=>{ c[i.status]=(c[i.status]||0)+1; }); return c; }
  function pushIssue(type,rule,status,message,selector,eid,themeId){ const tId=themeId||mapTypeToThemeId(type); const tObj=tId?THEMES_MAP.get(String(tId)):null; issues.push({type,rule,status,message,selector,eid,themeId:tId,themeName:tObj?tObj.name:''}); }

  function parseColor(v){ const ctx=(v||'').trim(); if(ctx.startsWith('rgb')){ const m=ctx.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/); if(!m) return null; return {r:+m[1],g:+m[2],b:+m[3],a:m[4]!==undefined?+m[4]:1}; } return null; }
  function relLuminance({r,g,b}){ const sr=[r,g,b].map(v=>{ v/=255; return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4);}); return 0.2126*sr[0]+0.7152*sr[1]+0.0722*sr[2]; }
  function contrastRatio(c1,c2){ const L1=relLuminance(c1),L2=relLuminance(c2); const [a,b]=L1>=L2?[L1,L2]:[L2,L1]; return (a+0.05)/(b+0.05); }
  function getEffectiveBg(el){ let e=el,s=0; while(e&&s++<20){ const cs=iframe.contentWindow.getComputedStyle(e); const bg=parseColor(cs.backgroundColor||''); if(bg&&bg.a>=0.99) return bg; e=e.parentElement; } return null; }
  function isVisible(el){ const cs=iframe.contentWindow.getComputedStyle(el); if(cs.display==='none'||cs.visibility==='hidden') return false; if(el.closest('[aria-hidden="true"]')) return false; return true; }
  function isLargeText(el){ const cs=iframe.contentWindow.getComputedStyle(el); const sizePx=parseFloat(cs.fontSize)||0; const weight=parseInt(cs.fontWeight)||400; return sizePx>=19||(sizePx>=14&&weight>=700); }
  function uniqueSelector(el){ if(!(el instanceof Element)) return ''; const doc=iframe.contentDocument; const parts=[]; while(el&&el.nodeType===1&&el!==doc.body){ let sel=el.nodeName.toLowerCase(); if(el.id){ sel+='#'+CSS.escape(el.id); parts.unshift(sel); break; } let sib=el,i=1; while((sib=sib.previousElementSibling)!=null){ if(sib.nodeName===el.nodeName) i++; } sel+=':nth-of-type('+i+')'; parts.unshift(sel); el=el.parentElement; } return parts.join(' > '); }
  function accessibleName(el){ if(!el) return ''; const ariaLabel=el.getAttribute('aria-label'); if(ariaLabel) return ariaLabel.trim(); const labelledby=el.getAttribute('aria-labelledby'); if(labelledby){ const s=labelledby.split(/\s+/).map(id=>iframe.contentDocument.getElementById(id)).filter(Boolean).map(n=>n.textContent.trim()).join(' '); if(s) return s; } if(el.alt) return String(el.alt).trim(); if(el.title) return String(el.title).trim(); return (el.textContent||'').trim(); }

  function ruleImageAlt(doc){ $$('img',doc).forEach(img=>{ if(!isVisible(img)) return; const alt=img.getAttribute('alt'); const sel=uniqueSelector(img); const eid=tag(img); if(alt===null){ pushIssue('images','1.1.1','fail','Image sans attribut alt',sel,eid,1); } else if(alt.trim()===''){ pushIssue('images','1.1.1','manual','alt vide. Vérifier décoratif',sel,eid,1); } else { if(/\.(jpe?g|png|gif|webp|svg)$/i.test(alt)||/IMG_\d+/i.test(alt)) pushIssue('images','1.1.1','manual','alt semble être un nom de fichier',sel,eid,1); else pushIssue('images','1.1.1','pass','alt présent',sel,eid,1); } }); $$('svg[role="img"]',doc).forEach(svg=>{ const hasName=svg.getAttribute('aria-label')||svg.getAttribute('aria-labelledby')||svg.querySelector('title'); const eid=tag(svg); pushIssue('images','1.1.1',hasName?'pass':'fail',hasName?'nom accessible présent':'SVG role="img" sans nom',uniqueSelector(svg),eid,1); }); }
  function ruleAria(doc){ $$('[role]',doc).forEach(el=>{ if(!isVisible(el)) return; const role=(el.getAttribute('role')||'').trim(); const meta=ARIA_MAP[role]; const sel=uniqueSelector(el); const eid=tag(el); if(!meta){ pushIssue('aria','4.1.2','manual','rôle ARIA non répertorié: '+role,sel,eid,7); return; } if(meta.requiresName){ const name=accessibleName(el); if(!name) pushIssue('aria','4.1.2','fail','Nom accessible manquant',sel,eid,7); else pushIssue('aria','4.1.2','pass','Nom accessible présent',sel,eid,7); } Array.from(el.attributes).filter(a=>a.name.startsWith('aria-')).forEach(a=>{ if(a.name==='aria-hidden') return; if(!meta.allowed.includes(a.name)) pushIssue('aria','4.1.2','manual','Attribut '+a.name+' peu pertinent pour rôle '+role,sel,eid,7); }); }); $$('[aria-hidden="true"]',doc).forEach(el=>{ if(el.matches('a, button, input, select, textarea, [tabindex]')){ pushIssue('aria','4.1.2','fail','Élément focusable masqué avec aria-hidden="true"',uniqueSelector(el),tag(el),7); } }); }
  function ruleContrast(doc){ const walker=doc.createTreeWalker(doc.body,NodeFilter.SHOW_ELEMENT,{acceptNode(node){ if(!isVisible(node)) return NodeFilter.FILTER_REJECT; const txt=(node.textContent||'').trim(); if(!txt) return NodeFilter.FILTER_SKIP; if(node.children.length>0 && node.innerText.trim()==='') return NodeFilter.FILTER_SKIP; return NodeFilter.FILTER_ACCEPT; }}); let node; const seen=new Set(); while((node=walker.nextNode())){ if(seen.has(node)) continue; seen.add(node); const cs=iframe.contentWindow.getComputedStyle(node); const fg=parseColor(cs.color||''); const bg=getEffectiveBg(node); const sel=uniqueSelector(node); const eid=tag(node); if(!fg||!bg){ pushIssue('contrast','3.2.x','manual','Contexte de couleur indéterminé',sel,eid,3); continue; } const ratio=contrastRatio(fg,bg); const large=isLargeText(node); const threshold=large?3.0:4.5; if(ratio<threshold) pushIssue('contrast','3.2.x','fail','Contraste '+ratio.toFixed(2)+' < '+threshold+':1',sel,eid,3); else pushIssue('contrast','3.2.x','pass','Contraste '+ratio.toFixed(2)+' ≥ '+threshold+':1',sel,eid,3); } }

  function resetVisuals(){ const doc=iframe.contentDocument; if(!doc) return; const host=doc.getElementById('rgaa-overlay-host'); if(host) host.remove(); RGAA_COUNTER=0; }
  async function auditURL(url,updateUI){ issues.length=0; if(updateUI){ renderTable(); updateSummary(); } resetVisuals(); iframe.src=url; await new Promise((res,rej)=>{ const to=setTimeout(()=>rej(new Error('timeout')),20000); iframe.onload=()=>{clearTimeout(to);res();}; iframe.onerror=()=>{clearTimeout(to);rej(new Error('load error'));}; }); const doc=iframe.contentDocument; if(!doc) throw new Error('Accès document impossible.'); ruleImageAlt(doc); ruleAria(doc); ruleContrast(doc); if(updateUI){ updateSummary(); renderTable(); } syncPanelHeight(); updateUrlBar(); return issues.slice(); }

  async function runQueue(){ if(running) return; running=true; stopFlag=false; setProgress(0); renderQueue(); for(const item of queue){ if(stopFlag) break; if(item.status!=='pending') continue; item.status='running'; renderQueue(); const t0=performance.now(); try{ const list=await auditURL(item.url,true); item.issues=list; item.counts=countsFromIssues(list); item.status='done'; }catch(e){ item.status='error'; item.error=e.message; } item.durationMs=performance.now()-t0; renderQueue(); } running=false; }
  function stopQueue(){ stopFlag=true; }
  function clearQueue(){ if(running){ alert('Arrêtez d’abord la file.'); return; } queue.length=0; renderQueue(); }
  function exportBatchJSON(){ const payload=queue.map(q=>({url:q.url,status:q.status,counts:q.counts,durationMs:q.durationMs,issues:q.issues})); const blob=new Blob([JSON.stringify({generatedAt:new Date().toISOString(),pages:payload},null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='rgaa-batch.json'; a.click(); URL.revokeObjectURL(a.href); }
  function exportBatchCSV(){ const rows=[['url','type','theme','regle','statut','message','selector','eid']]; queue.forEach(q=>{ (q.issues||[]).forEach(i=>{ rows.push([q.url,i.type,i.themeName||'',i.rule,i.status,(i.message||'').replace(/\n/g,' '),i.selector||'',i.eid||'']); }); }); const csv=rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n'); const blob=new Blob([csv],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='rgaa-batch.csv'; a.click(); URL.revokeObjectURL(a.href); }

  document.getElementById('rgaa-scan').addEventListener('click',async()=>{ let target=urlInput.value.trim(); try{ const href=iframe.contentWindow.location.href; if(href) target=href; }catch(_){} if(!target){ alert('Aucune URL.'); return; } try{ await auditURL(target,true); }catch(e){ alert('Erreur: '+e.message); } });
  document.getElementById('rgaa-export').addEventListener('click',()=>{ const blob=new Blob([JSON.stringify({issues},null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='rgaa-audit.json'; a.click(); URL.revokeObjectURL(a.href); });

  document.getElementById('rgaa-queue-add').addEventListener('click',()=>{ const lines=document.getElementById('rgaa-urls-text').value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean); addToQueue(lines); });
  document.getElementById('rgaa-queue-sitemap').addEventListener('click',async()=>{ const limit=Math.max(1,Math.min(2000,parseInt(document.getElementById('rgaa-sitemap-limit').value)||200)); const urls=await loadWPSitemap(limit); addToQueue(urls); });
  document.getElementById('rgaa-queue-start').addEventListener('click',runQueue);
  document.getElementById('rgaa-queue-stop').addEventListener('click',stopQueue);
  document.getElementById('rgaa-queue-clear').addEventListener('click',clearQueue);
  document.getElementById('rgaa-queue-export-json').addEventListener('click',exportBatchJSON);
  document.getElementById('rgaa-queue-export-csv').addEventListener('click',exportBatchCSV);
  document.getElementById('rgaa-filter-status').addEventListener('change',renderTable);
  document.getElementById('rgaa-filter-theme').addEventListener('change',renderTable);

  iframe.src=CFG.home||'/'; urlInput.value=CFG.home||'/';
})();