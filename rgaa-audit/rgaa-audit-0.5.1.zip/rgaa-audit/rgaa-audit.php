<?php
/**
 * Plugin Name: RGAA Audit (POC)
 * Description: Audit d’accessibilité RGAA pour WordPress. URL active, bouton Accueil, alignement des boutons.
 * Version: 0.5.1
 * Author: Vous
 * License: MIT
 * Text Domain: rgaa-audit
 */
if (!defined('ABSPATH')) exit;

const RGAA_AUDIT_OPT = 'rgaa_audit_settings';

function rgaa_audit_default_settings() {
    return array('statuses'=>array('fail','manual','pass','wip'),'themes'=>array(1,2,3,4,5,6,7,8,9,10,11,12,13));
}
function rgaa_audit_get_settings() {
    $opt = get_option(RGAA_AUDIT_OPT);
    $defaults = rgaa_audit_default_settings();
    if (!is_array($opt)) $opt = array();
    $opt['statuses'] = array_values(array_intersect($opt['statuses'] ?? $defaults['statuses'], $defaults['statuses']));
    $opt['themes'] = array_map('intval', $opt['themes'] ?? $defaults['themes']);
    if (empty($opt['statuses'])) $opt['statuses'] = $defaults['statuses'];
    if (empty($opt['themes'])) $opt['themes'] = $defaults['themes'];
    return $opt;
}
function rgaa_audit_sanitize($input) {
    $out = rgaa_audit_default_settings();
    if (isset($input['statuses']) && is_array($input['statuses'])) {
        $allowed = array('fail','manual','pass','wip');
        $out['statuses'] = array_values(array_intersect($input['statuses'], $allowed));
    }
    if (isset($input['themes']) && is_array($input['themes'])) {
        $themes = array();
        foreach($input['themes'] as $t) { $t = intval($t); if($t>=1 && $t<=13) $themes[]=$t; }
        if ($themes) $out['themes'] = $themes;
    }
    return $out;
}

add_action('admin_menu', function(){
    add_menu_page(
        __('Audit RGAA','rgaa-audit'),
        __('Audit RGAA','rgaa-audit'),
        'manage_options',
        'rgaa-audit',
        'rgaa_audit_render_main',
        'dashicons-visibility',
        58
    );
    add_submenu_page('rgaa-audit', __('Audit RGAA','rgaa-audit'), __('Tableau de bord','rgaa-audit'), 'manage_options', 'rgaa-audit', 'rgaa_audit_render_main');
    add_submenu_page('rgaa-audit', __('Configuration','rgaa-audit'), __('Configuration','rgaa-audit'), 'manage_options', 'rgaa-audit-settings', 'rgaa_audit_render_settings');
}, 20);

function rgaa_audit_render_main(){
    $nonce = wp_create_nonce('rgaa_audit');
    echo '<div class="wrap"><h1>'.esc_html__('Audit RGAA','rgaa-audit').'</h1>';
    echo '<div id="rgaa-root" data-nonce="'.esc_attr($nonce).'"></div>';
    echo '</div>';
}
function rgaa_audit_render_settings(){
    $opt = rgaa_audit_get_settings();
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Configuration Audit RGAA','rgaa-audit'); ?></h1>
        <form method="post" action="options.php">
            <?php settings_fields('rgaa_audit_group'); ?>
            <h2>Filtres — Statuts</h2>
            <fieldset>
                <?php 
                $statuses = array('fail'=>'fail','manual'=>'manual','pass'=>'pass','wip'=>'en cours');
                foreach($statuses as $key=>$label): 
                    $checked = in_array($key, $opt['statuses'], true) ? 'checked' : '';
                ?>
                <label style="display:inline-block;margin-right:12px">
                    <input type="checkbox" name="<?php echo RGAA_AUDIT_OPT; ?>[statuses][]" value="<?php echo esc_attr($key); ?>" <?php echo $checked; ?> />
                    <?php echo esc_html($label); ?>
                </label>
                <?php endforeach; ?>
            </fieldset>
            <h2>Filtres — Catégories</h2>
            <fieldset>
                <?php 
                $names = array(1=>'Images',2=>'Cadres',3=>'Couleurs',4=>'Multimédia',5=>'Tableaux',6=>'Liens',7=>'Scripts',8=>'Éléments obligatoires',9=>'Structuration de l’information',10=>'Présentation de l’information',11=>'Formulaires',12=>'Navigation',13=>'Consultation');
                for($i=1;$i<=13;$i++):
                    $checked = in_array($i, $opt['themes'], true) ? 'checked' : '';
                ?>
                <label style="display:inline-block;width:320px;margin:4px 12px 4px 0">
                    <input type="checkbox" name="<?php echo RGAA_AUDIT_OPT; ?>[themes][]" value="<?php echo esc_attr($i); ?>" <?php echo $checked; ?> />
                    <?php echo esc_html($i.'. '.$names[$i]); ?>
                </label>
                <?php endfor; ?>
            </fieldset>
            <?php submit_button(__('Enregistrer')); ?>
        </form>
    </div>
    <?php
}

add_action('admin_init', function(){
    register_setting('rgaa_audit_group', RGAA_AUDIT_OPT, array(
        'type' => 'array',
        'sanitize_callback' => 'rgaa_audit_sanitize',
        'default' => rgaa_audit_default_settings()
    ));
});

add_action('admin_bar_menu', function($wp_admin_bar){
    if (!current_user_can('manage_options')) return;
    $wp_admin_bar->add_node(array(
        'id'    => 'rgaa-audit-top',
        'title' => 'Audit RGAA',
        'href'  => admin_url('admin.php?page=rgaa-audit'),
    ));
}, 100);

add_action('admin_enqueue_scripts', function($hook){
    if ($hook !== 'toplevel_page_rgaa-audit') return;
    wp_enqueue_style('rgaa-admin', plugins_url('rgaa-admin.css', __FILE__), [], '0.5.1');
    wp_enqueue_script('rgaa-admin', plugins_url('rgaa-admin.js', __FILE__), [], '0.5.1', true);
    $opt = rgaa_audit_get_settings();
    wp_localize_script('rgaa-admin', 'RGAA_AUDIT_SETTINGS', array(
        'statuses' => $opt['statuses'],
        'themes'   => $opt['themes'],
        'home'     => home_url('/'),
    ));
});
