<?php
/**
 * Plugin Name: RGAA Audit (POC)
 * Description: Audit RGAA avec aperçu, filtres, ordre de tabulation, éléments non tabulables, overlay de code et évaluation des plugins.
 * Version: 0.7.0
 * Author: Vous
 * License: MIT
 * Text Domain: rgaa-audit
 */
if (!defined('ABSPATH')) exit;

const RGAA_AUDIT_OPT = 'rgaa_audit_settings';

function rgaa_audit_default_settings() {
    return array('statuses'=>array('fail','manual','pass','wip'),'themes'=>array(1,2,3,4,5,6,7,8,9,10,11,12,13));
}

function rgaa_audit_get_settings() {
    $opt = get_option(RGAA_AUDIT_OPT);
    $defaults = rgaa_audit_default_settings();
    if (!is_array($opt)) $opt = array();
    $opt['statuses'] = array_values(array_intersect($opt['statuses'] ?? $defaults['statuses'], $defaults['statuses']));
    $opt['themes'] = array_map('intval', $opt['themes'] ?? $defaults['themes']);
    if (empty($opt['statuses'])) $opt['statuses'] = $defaults['statuses'];
    if (empty($opt['themes'])) $opt['themes'] = $defaults['themes'];
    return $opt;
}

function rgaa_audit_sanitize($input) {
    $out = rgaa_audit_default_settings();
    if (isset($input['statuses']) && is_array($input['statuses'])) {
        $allowed = array('fail','manual','pass','wip');
        $out['statuses'] = array_values(array_intersect($input['statuses'], $allowed));
    }
    if (isset($input['themes']) && is_array($input['themes'])) {
        $themes = array();
        foreach($input['themes'] as $t) { $t = intval($t); if($t>=1 && $t<=13) $themes[]=$t; }
        if ($themes) $out['themes'] = $themes;
    }
    return $out;
}

// ============= NOUVELLE FONCTIONNALITÉ: DÉTECTION ET ÉVALUATION DES PLUGINS =============

/**
 * Récupère la liste des plugins actifs avec leurs informations
 */
function rgaa_audit_get_active_plugins() {
    if (!function_exists('get_plugins')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    
    $all_plugins = get_plugins();
    $active_plugins = get_option('active_plugins', array());
    $plugins_data = array();
    
    foreach ($active_plugins as $plugin_path) {
        if (isset($all_plugins[$plugin_path])) {
            $plugin = $all_plugins[$plugin_path];
            $plugin_dir = dirname(WP_PLUGIN_DIR . '/' . $plugin_path);
            
            $plugins_data[] = array(
                'name' => $plugin['Name'],
                'version' => $plugin['Version'],
                'author' => strip_tags($plugin['Author']),
                'description' => strip_tags($plugin['Description']),
                'path' => $plugin_path,
                'dir' => $plugin_dir,
                'text_domain' => $plugin['TextDomain'] ?? '',
                'slug' => dirname($plugin_path)
            );
        }
    }
    
    return $plugins_data;
}

/**
 * Analyse un plugin pour les problèmes RGAA
 */
function rgaa_audit_analyze_plugin($plugin_data) {
    $issues = array();
    $score = 100;
    $plugin_dir = $plugin_data['dir'];
    
    // 1. Vérifier les fichiers CSS
    $css_files = rgaa_scan_directory($plugin_dir, 'css');
    foreach ($css_files as $css_file) {
        $css_content = @file_get_contents($css_file);
        if ($css_content) {
            $css_issues = rgaa_audit_analyze_css($css_content, basename($css_file));
            $issues = array_merge($issues, $css_issues);
        }
    }
    
    // 2. Vérifier les fichiers JavaScript
    $js_files = rgaa_scan_directory($plugin_dir, 'js');
    foreach ($js_files as $js_file) {
        $js_content = @file_get_contents($js_file);
        if ($js_content) {
            $js_issues = rgaa_audit_analyze_js($js_content, basename($js_file));
            $issues = array_merge($issues, $js_issues);
        }
    }
    
    // 3. Vérifier les fichiers PHP pour les sorties HTML
    $php_files = rgaa_scan_directory($plugin_dir, 'php');
    foreach ($php_files as $php_file) {
        $php_content = @file_get_contents($php_file);
        if ($php_content) {
            $html_issues = rgaa_audit_analyze_php_html($php_content, basename($php_file));
            $issues = array_merge($issues, $html_issues);
        }
    }
    
    // 4. Calculer le score
    $critical_issues = count(array_filter($issues, function($i) { return $i['severity'] === 'critical'; }));
    $major_issues = count(array_filter($issues, function($i) { return $i['severity'] === 'major'; }));
    $minor_issues = count(array_filter($issues, function($i) { return $i['severity'] === 'minor'; }));
    
    $score -= ($critical_issues * 20);
    $score -= ($major_issues * 10);
    $score -= ($minor_issues * 5);
    $score = max(0, $score);
    
    // 5. Déterminer le statut global
    $status = 'pass';
    if ($score < 50) {
        $status = 'fail';
    } elseif ($score < 80) {
        $status = 'manual';
    }
    
    return array(
        'plugin' => $plugin_data['name'],
        'version' => $plugin_data['version'],
        'score' => $score,
        'status' => $status,
        'issues' => $issues,
        'stats' => array(
            'critical' => $critical_issues,
            'major' => $major_issues,
            'minor' => $minor_issues,
            'total' => count($issues)
        )
    );
}

/**
 * Scanne un répertoire pour trouver des fichiers d'une extension donnée
 */
function rgaa_scan_directory($dir, $extension, $max_depth = 3, $current_depth = 0) {
    $files = array();
    
    if ($current_depth >= $max_depth || !is_dir($dir)) {
        return $files;
    }
    
    $items = @scandir($dir);
    if (!$items) return $files;
    
    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item === 'node_modules' || $item === 'vendor') {
            continue;
        }
        
        $path = $dir . '/' . $item;
        
        if (is_file($path) && pathinfo($path, PATHINFO_EXTENSION) === $extension) {
            $files[] = $path;
        } elseif (is_dir($path)) {
            $files = array_merge($files, rgaa_scan_directory($path, $extension, $max_depth, $current_depth + 1));
        }
    }
    
    return $files;
}

/**
 * Analyse le contenu CSS pour les problèmes d'accessibilité
 */
function rgaa_audit_analyze_css($content, $filename) {
    $issues = array();
    
    // Vérifier les contrastes de couleurs définies
    if (preg_match_all('/color\s*:\s*([#\w\(\),\.\s]+);/i', $content, $matches)) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'css',
            'theme' => 3,
            'criterion' => '3.2',
            'severity' => 'minor',
            'message' => 'Couleurs définies trouvées - vérifier les contrastes manuellement',
            'details' => 'Trouvé ' . count($matches[0]) . ' déclarations de couleur'
        );
    }
    
    // Vérifier les tailles de police en pixels absolus
    if (preg_match_all('/font-size\s*:\s*(\d+)px/i', $content, $matches)) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'css',
            'theme' => 10,
            'criterion' => '10.4',
            'severity' => 'major',
            'message' => 'Tailles de police en pixels absolus détectées',
            'details' => 'Utiliser des unités relatives (em, rem, %) pour l\'accessibilité'
        );
    }
    
    // Vérifier l'utilisation de !important excessif
    $important_count = substr_count($content, '!important');
    if ($important_count > 10) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'css',
            'theme' => 10,
            'criterion' => '10.1',
            'severity' => 'minor',
            'message' => 'Utilisation excessive de !important',
            'details' => $important_count . ' occurrences trouvées - peut compliquer les adaptations utilisateur'
        );
    }
    
    // Vérifier les animations qui peuvent causer des problèmes
    if (preg_match('/@keyframes|animation:/i', $content)) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'css',
            'theme' => 13,
            'criterion' => '13.8',
            'severity' => 'major',
            'message' => 'Animations CSS détectées',
            'details' => 'Vérifier que les animations peuvent être désactivées et ne causent pas de clignotements'
        );
    }
    
    // Vérifier l'utilisation de outline: none sans alternative
    if (preg_match('/outline\s*:\s*none|outline\s*:\s*0/i', $content) && 
        !preg_match('/outline\s*:\s*\d+px|focus-visible/i', $content)) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'css',
            'theme' => 10,
            'criterion' => '10.7',
            'severity' => 'critical',
            'message' => 'Suppression du contour de focus sans alternative visible',
            'details' => 'Le contour de focus est essentiel pour la navigation au clavier'
        );
    }
    
    return $issues;
}

/**
 * Analyse le contenu JavaScript pour les problèmes d'accessibilité
 */
function rgaa_audit_analyze_js($content, $filename) {
    $issues = array();
    
    // Vérifier l'utilisation de document.write
    if (stripos($content, 'document.write') !== false) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'js',
            'theme' => 7,
            'criterion' => '7.1',
            'severity' => 'major',
            'message' => 'Utilisation de document.write détectée',
            'details' => 'Peut causer des problèmes d\'accessibilité et de performance'
        );
    }
    
    // Vérifier les gestionnaires d'événements clavier
    if (preg_match('/onclick|onmousedown|onmouseover/i', $content) && 
        !preg_match('/onkeydown|onkeypress|onkeyup/i', $content)) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'js',
            'theme' => 7,
            'criterion' => '7.3',
            'severity' => 'critical',
            'message' => 'Événements souris sans équivalent clavier',
            'details' => 'Les interactions doivent être accessibles au clavier'
        );
    }
    
    // Vérifier les timeouts automatiques
    if (preg_match('/setTimeout|setInterval/i', $content)) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'js',
            'theme' => 13,
            'criterion' => '13.1',
            'severity' => 'minor',
            'message' => 'Timeouts automatiques détectés',
            'details' => 'Vérifier que l\'utilisateur peut contrôler les limites de temps'
        );
    }
    
    // Vérifier l'utilisation d'ARIA
    if (preg_match('/aria-/i', $content)) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'js',
            'theme' => 7,
            'criterion' => '7.1',
            'severity' => 'minor',
            'message' => 'Attributs ARIA utilisés en JavaScript',
            'details' => 'Vérifier la conformité de l\'implémentation ARIA'
        );
    }
    
    // Vérifier les manipulations de focus
    if (preg_match('/\.focus\(\)|\.blur\(\)/i', $content)) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'js',
            'theme' => 12,
            'criterion' => '12.1',
            'severity' => 'major',
            'message' => 'Manipulation du focus détectée',
            'details' => 'Vérifier que la gestion du focus est cohérente et prévisible'
        );
    }
    
    return $issues;
}

/**
 * Analyse le contenu PHP pour les sorties HTML problématiques
 */
function rgaa_audit_analyze_php_html($content, $filename) {
    $issues = array();
    
    // Vérifier les images sans alt
    if (preg_match_all('/<img[^>]*>/i', $content, $matches)) {
        foreach ($matches[0] as $img_tag) {
            if (!preg_match('/alt\s*=\s*["\'].*?["\']/i', $img_tag)) {
                $issues[] = array(
                    'file' => $filename,
                    'type' => 'php',
                    'theme' => 1,
                    'criterion' => '1.1',
                    'severity' => 'critical',
                    'message' => 'Image sans attribut alt',
                    'details' => 'Chaque image doit avoir un attribut alt, même vide pour les images décoratives'
                );
            }
        }
    }
    
    // Vérifier les liens sans intitulé
    if (preg_match_all('/<a[^>]*>.*?<\/a>/is', $content, $matches)) {
        foreach ($matches[0] as $link) {
            $link_content = strip_tags($link);
            if (trim($link_content) === '' && !preg_match('/aria-label|title/i', $link)) {
                $issues[] = array(
                    'file' => $filename,
                    'type' => 'php',
                    'theme' => 6,
                    'criterion' => '6.1',
                    'severity' => 'critical',
                    'message' => 'Lien sans intitulé accessible',
                    'details' => 'Les liens doivent avoir un texte ou un aria-label'
                );
            }
        }
    }
    
    // Vérifier les formulaires sans label
    if (preg_match_all('/<input[^>]*type\s*=\s*["\'](?!hidden)[^"\']*["\']/i', $content, $matches)) {
        foreach ($matches[0] as $input) {
            if (!preg_match('/aria-label|aria-labelledby/i', $input)) {
                $issues[] = array(
                    'file' => $filename,
                    'type' => 'php',
                    'theme' => 11,
                    'criterion' => '11.1',
                    'severity' => 'critical',
                    'message' => 'Champ de formulaire sans étiquette',
                    'details' => 'Chaque champ doit avoir un label associé ou un aria-label'
                );
            }
        }
    }
    
    // Vérifier les boutons vides
    if (preg_match_all('/<button[^>]*>.*?<\/button>/is', $content, $matches)) {
        foreach ($matches[0] as $button) {
            $button_content = strip_tags($button);
            if (trim($button_content) === '' && !preg_match('/aria-label/i', $button)) {
                $issues[] = array(
                    'file' => $filename,
                    'type' => 'php',
                    'theme' => 7,
                    'criterion' => '7.1',
                    'severity' => 'critical',
                    'message' => 'Bouton sans intitulé accessible',
                    'details' => 'Les boutons doivent avoir un texte ou un aria-label'
                );
            }
        }
    }
    
    // Vérifier la hiérarchie des titres
    if (preg_match_all('/<h([1-6])[^>]*>/i', $content, $matches)) {
        $issues[] = array(
            'file' => $filename,
            'type' => 'php',
            'theme' => 9,
            'criterion' => '9.1',
            'severity' => 'minor',
            'message' => 'Titres de niveaux trouvés',
            'details' => 'Vérifier que la hiérarchie des titres est cohérente'
        );
    }
    
    return $issues;
}

// ============= API REST POUR L'ÉVALUATION DES PLUGINS =============

add_action('rest_api_init', function() {
    register_rest_route('rgaa-audit/v1', '/plugins', array(
        'methods' => 'GET',
        'callback' => 'rgaa_audit_api_get_plugins',
        'permission_callback' => function() {
            return current_user_can('manage_options');
        }
    ));
    
    register_rest_route('rgaa-audit/v1', '/plugins/analyze', array(
        'methods' => 'POST',
        'callback' => 'rgaa_audit_api_analyze_plugin',
        'permission_callback' => function() {
            return current_user_can('manage_options');
        }
    ));
});

function rgaa_audit_api_get_plugins() {
    $plugins = rgaa_audit_get_active_plugins();
    return rest_ensure_response(array(
        'success' => true,
        'data' => $plugins
    ));
}

function rgaa_audit_api_analyze_plugin($request) {
    $plugin_path = $request->get_param('plugin_path');
    
    if (empty($plugin_path)) {
        return new WP_Error('missing_param', 'Le paramètre plugin_path est requis', array('status' => 400));
    }
    
    $all_plugins = rgaa_audit_get_active_plugins();
    $plugin_data = null;
    
    foreach ($all_plugins as $plugin) {
        if ($plugin['path'] === $plugin_path) {
            $plugin_data = $plugin;
            break;
        }
    }
    
    if (!$plugin_data) {
        return new WP_Error('plugin_not_found', 'Plugin non trouvé', array('status' => 404));
    }
    
    $analysis = rgaa_audit_analyze_plugin($plugin_data);
    
    return rest_ensure_response(array(
        'success' => true,
        'data' => $analysis
    ));
}

// ============= RESTE DU CODE ORIGINAL =============

add_action('admin_menu', function(){
    add_menu_page(
        __('Audit RGAA','rgaa-audit'),
        __('Audit RGAA','rgaa-audit'),
        'manage_options',
        'rgaa-audit',
        'rgaa_audit_render_main',
        'dashicons-visibility',
        58
    );
    add_submenu_page('rgaa-audit', __('Audit RGAA','rgaa-audit'), __('Tableau de bord','rgaa-audit'), 'manage_options', 'rgaa-audit', 'rgaa_audit_render_main');
    add_submenu_page('rgaa-audit', __('Configuration','rgaa-audit'), __('Configuration','rgaa-audit'), 'manage_options', 'rgaa-audit-settings', 'rgaa_audit_render_settings');
}, 20);

function rgaa_audit_render_main(){
    $nonce = wp_create_nonce('rgaa_audit');
    echo '<div class="wrap"><h1>'.esc_html__('Audit RGAA','rgaa-audit').'</h1>';
    echo '<div id="rgaa-root" data-nonce="'.esc_attr($nonce).'"></div>';
    echo '</div>';
}

function rgaa_audit_render_settings(){
    $opt = rgaa_audit_get_settings();
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Configuration Audit RGAA','rgaa-audit'); ?></h1>
        <form method="post" action="options.php">
            <?php settings_fields('rgaa_audit_group'); ?>
            <h2>Filtres — Statuts</h2>
            <fieldset>
                <?php 
                $statuses = array('fail'=>'fail','manual'=>'manual','pass'=>'pass','wip'=>'en cours');
                foreach($statuses as $key=>$label): 
                    $checked = in_array($key, $opt['statuses'], true) ? 'checked' : '';
                ?>
                <label style="display:inline-block;margin-right:12px">
                    <input type="checkbox" name="<?php echo RGAA_AUDIT_OPT; ?>[statuses][]" value="<?php echo esc_attr($key); ?>" <?php echo $checked; ?> />
                    <?php echo esc_html($label); ?>
                </label>
                <?php endforeach; ?>
            </fieldset>
            <h2>Filtres — Catégories</h2>
            <fieldset>
                <?php 
                $names = array(1=>'Images',2=>'Cadres',3=>'Couleurs',4=>'Multimédia',5=>'Tableaux',6=>'Liens',7=>'Scripts',8=>'Éléments obligatoires',9=>'Structuration de l\'information',10=>'Présentation de l\'information',11=>'Formulaires',12=>'Navigation',13=>'Consultation');
                for($i=1;$i<=13;$i++):
                    $checked = in_array($i, $opt['themes'], true) ? 'checked' : '';
                ?>
                <label style="display:inline-block;width:320px;margin:4px 12px 4px 0">
                    <input type="checkbox" name="<?php echo RGAA_AUDIT_OPT; ?>[themes][]" value="<?php echo esc_attr($i); ?>" <?php echo $checked; ?> />
                    <?php echo esc_html($i.'. '.$names[$i]); ?>
                </label>
                <?php endfor; ?>
            </fieldset>
            <?php submit_button(__('Enregistrer')); ?>
        </form>
    </div>
    <?php
}

add_action('admin_init', function(){
    register_setting('rgaa_audit_group', RGAA_AUDIT_OPT, array(
        'type' => 'array',
        'sanitize_callback' => 'rgaa_audit_sanitize',
        'default' => rgaa_audit_default_settings()
    ));
});

add_action('admin_bar_menu', function($wp_admin_bar){
    if (!current_user_can('manage_options')) return;
    $wp_admin_bar->add_node(array(
        'id'    => 'rgaa-audit-top',
        'title' => 'Audit RGAA',
        'href'  => admin_url('admin.php?page=rgaa-audit'),
    ));
}, 100);

add_action('admin_enqueue_scripts', function($hook){
    if ($hook !== 'toplevel_page_rgaa-audit') return;
    wp_enqueue_style('rgaa-admin', plugins_url('rgaa-admin.css', __FILE__), [], '0.7.0');
    wp_enqueue_script('rgaa-admin', plugins_url('rgaa-admin.js', __FILE__), [], '0.7.0', true);
    $opt = rgaa_audit_get_settings();
    wp_localize_script('rgaa-admin', 'RGAA_AUDIT_SETTINGS', array(
        'statuses' => $opt['statuses'],
        'themes'   => $opt['themes'],
        'home'     => home_url('/'),
        'apiUrl'   => rest_url('rgaa-audit/v1'),
        'nonce'    => wp_create_nonce('wp_rest')
    ));
});