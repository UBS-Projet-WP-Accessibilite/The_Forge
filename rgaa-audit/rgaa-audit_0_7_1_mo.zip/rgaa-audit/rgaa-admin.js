(function(){
  const root=document.getElementById('rgaa-root'); 
  if(!root) {
    console.error('RGAA: Element #rgaa-root not found');
    return;
  }
  
  console.log('RGAA: Plugin loading...');
  
  const CFG=typeof RGAA_AUDIT_SETTINGS!=='undefined'?RGAA_AUDIT_SETTINGS:{statuses:['fail','manual','pass','wip'],themes:[1,2,3,4,5,6,7,8,9,10,11,12,13],home:'/',apiUrl:'',nonce:''};
  const STATUS_LABEL={fail:'fail',manual:'manual',pass:'pass',wip:'en cours'};
  const SEVERITY_LABEL={critical:'Critique',major:'Majeur',minor:'Mineur'};
  const THEMES=[{id:1,name:'Images',tests:['1.1','1.2','1.3']},{id:2,name:'Cadres',tests:['2.1','2.2']},{id:3,name:'Couleurs',tests:['3.1','3.2']},{id:4,name:'Multimédia',tests:['4.1','4.2']},{id:5,name:'Tableaux',tests:['5.1','5.2','5.3']},{id:6,name:'Liens',tests:['6.1','6.2']},{id:7,name:'Scripts',tests:['7.1','7.2','7.3']},{id:8,name:'Éléments obligatoires',tests:['8.1','8.2']},{id:9,name:'Structuration de l\'information',tests:['9.1','9.2','9.3']},{id:10,name:'Présentation de l\'information',tests:['10.1','10.2']},{id:11,name:'Formulaires',tests:['11.1','11.2','11.3']},{id:12,name:'Navigation',tests:['12.1','12.2','12.3']},{id:13,name:'Consultation',tests:['13.1','13.2']}];
  const THEMES_MAP=new Map(THEMES.map(t=>[String(t.id),t]));

  // Vérifier si l'API est disponible
  const hasAPI = CFG.apiUrl && CFG.nonce;
  console.log('RGAA: API available:', hasAPI);

  // Fonctions helpers
  const byId=(s)=>document.getElementById(s);
  const $$=(s,d=document)=>[...d.querySelectorAll(s)];

  // Variables globales pour l'audit des pages
  let issues=[],queue=[],running=false,stopFlag=false,RGAA_COUNTER=0;
  const mapTypeToThemeId=t=>({images:1,cadres:2,contrast:3,multimedia:4,tableaux:5,liens:6,aria:7,mandatory:8,structure:9,presentation:10,forms:11,nav:12,consult:13})[t]||null;
  const ARIA_MAP={button:{requiresName:true,allowed:['aria-pressed','aria-expanded','aria-label','aria-labelledby','aria-describedby']},checkbox:{requiresName:true,allowed:['aria-checked','aria-label','aria-labelledby','aria-describedby']},link:{requiresName:true,allowed:['aria-label','aria-labelledby','aria-describedby']},tab:{requiresName:true,allowed:['aria-selected','aria-controls','aria-label','aria-labelledby']},img:{requiresName:true,allowed:['aria-label','aria-labelledby']}};

  // État global pour les plugins (seulement si API disponible)
  let pluginsData = [];
  let pluginAnalyses = new Map();
  let currentView = 'pages';

  // Créer l'interface avec ou sans l'onglet Plugins
  let tabsHTML = '<div class="rgaa-tabs" style="margin-bottom:16px"><button id="tab-pages" class="button button-primary" data-tab="pages">Audit des Pages</button>';
  if(hasAPI) {
    tabsHTML += '<button id="tab-plugins" class="button" data-tab="plugins">Audit des Plugins</button>';
  }
  tabsHTML += '</div>';

  root.innerHTML = tabsHTML + '\
    <div id="view-pages">\
      <div class="rgaa-row">\
        <div class="rgaa-col">\
          <label>URL de la page active\
            <input id="rgaa-url" type="text" style="width:100%" placeholder="https://exemple.com/page"/>\
          </label>\
        </div>\
        <div style="display:flex;gap:8px;align-items:flex-end">\
          <button id="rgaa-home" class="button" aria-label="Aller à l\'accueil"><span class="dashicons dashicons-admin-home"></span> Accueil</button>\
          <button id="rgaa-scan" class="button button-primary">Lancer</button>\
          <button id="rgaa-export" class="button">Export JSON (page)</button>\
        </div>\
      </div>\
      <div class="rgaa-two-col">\
        <div class="rgaa-preview"><iframe id="rgaa-frame" class="rgaa-iframe" sandbox="allow-same-origin allow-scripts allow-forms"></iframe></div>\
        <div class="rgaa-panel"><div id="rgaa-panel-scroll" class="rgaa-panel-scroll">\
          <strong>Résumé (page courante)</strong>\
          <div id="rgaa-summary">En attente…</div>\
          <div style="margin-top:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">\
            <label>Statut <select id="rgaa-filter-status"></select></label>\
            <label>Catégorie <select id="rgaa-filter-theme"></select></label>\
          </div>\
          <div id="rgaa-placeholders" style="margin:8px 0; display:none"></div>\
          <table id="rgaa-issues"><thead><tr><th>#</th><th>Type</th><th>Catégorie</th><th>Règle</th><th>Statut</th><th>Message</th><th>Action</th></tr></thead><tbody></tbody></table>\
        </div></div>\
      </div>\
      <div class="rgaa-queue-wrap">\
        <strong>File d\'URLs</strong>\
        <textarea id="rgaa-urls-text" placeholder="https://exemple.com/\nhttps://exemple.com/page-2"></textarea>\
        <div style="margin-top:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">\
          <button id="rgaa-queue-add" class="button">Ajouter à la file</button>\
          <button id="rgaa-queue-sitemap" class="button">Charger WP Sitemap</button>\
          <label>Limite <input id="rgaa-sitemap-limit" type="number" min="1" max="2000" value="200" style="width:80px"></label>\
          <button id="rgaa-queue-start" class="button button-primary">Démarrer</button>\
          <button id="rgaa-queue-stop" class="button">Arrêter</button>\
          <button id="rgaa-queue-clear" class="button">Vider</button>\
          <button id="rgaa-queue-export-json" class="button">Export JSON (lot)</button>\
          <button id="rgaa-queue-export-csv" class="button">Export CSV (lot)</button>\
        </div>\
        <div class="rgaa-progress"><div id="rgaa-progress-bar" class="rgaa-progress-bar"></div></div>\
        <table id="rgaa-queue"><thead><tr><th>#</th><th>URL</th><th>Statut</th><th>Échecs</th><th>À vérifier</th><th>OK</th><th>Durée (s)</th></tr></thead><tbody></tbody></table>\
      </div>\
    </div>' + 
    (hasAPI ? '\
    <div id="view-plugins" style="display:none">\
      <div style="margin-bottom:16px">\
        <h2>Évaluation RGAA des Plugins WordPress</h2>\
        <p style="color:#666">Cette section analyse les fichiers CSS, JavaScript et PHP des plugins actifs pour détecter les problèmes d\'accessibilité potentiels.</p>\
        <div style="display:flex;gap:8px;margin-top:12px">\
          <button id="plugins-load" class="button button-primary">Charger les plugins actifs</button>\
          <button id="plugins-analyze-all" class="button">Analyser tous les plugins</button>\
          <button id="plugins-export" class="button">Export JSON</button>\
        </div>\
      </div>\
      <div id="plugins-summary" style="margin:16px 0;padding:12px;background:#f9f9f9;border:1px solid #ddd;border-radius:4px;display:none"></div>\
      <table id="plugins-table" style="width:100%;border-collapse:collapse">\
        <thead>\
          <tr>\
            <th style="border:1px solid #ddd;padding:8px;text-align:left">Plugin</th>\
            <th style="border:1px solid #ddd;padding:8px;text-align:left">Version</th>\
            <th style="border:1px solid #ddd;padding:8px;text-align:center">Score</th>\
            <th style="border:1px solid #ddd;padding:8px;text-align:center">Statut</th>\
            <th style="border:1px solid #ddd;padding:8px;text-align:center">Problèmes</th>\
            <th style="border:1px solid #ddd;padding:8px;text-align:center">Action</th>\
          </tr>\
        </thead>\
        <tbody id="plugins-tbody"></tbody>\
      </table>\
    </div>' : '');

  console.log('RGAA: DOM created');

  // Récupération des éléments après création du DOM
  const iframe=byId('rgaa-frame');
  const urlInput=byId('rgaa-url');
  const statusSelect=byId('rgaa-filter-status');
  const themeSelect=byId('rgaa-filter-theme');

  if(!iframe || !urlInput || !statusSelect || !themeSelect) {
    console.error('RGAA: Required elements not found');
    return;
  }

  // Configuration des filtres
  const allStatuses=['fail','manual','pass','wip'];
  const enabledStatuses=(CFG.statuses||allStatuses).filter(s=>allStatuses.includes(s));
  statusSelect.innerHTML='<option value="all">Tous</option>'+enabledStatuses.map(s=>`<option value="${s}">${STATUS_LABEL[s]||s}</option>`).join('');
  
  const enabledThemes=(CFG.themes||[]).filter(id=>id>=1&&id<=13);
  themeSelect.innerHTML='<option value="all">Toutes</option>'+enabledThemes.map(id=>{const t=THEMES_MAP.get(String(id));return t?`<option value="${t.id}">${t.id}. ${t.name}</option>`:''}).join('');

  // Gestion des onglets (seulement si API disponible)
  if(hasAPI) {
    document.querySelectorAll('.rgaa-tabs button').forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        switchView(tab);
      });
    });
  }

  function switchView(view) {
    currentView = view;
    const pagesView = document.getElementById('view-pages');
    const pluginsView = document.getElementById('view-plugins');
    
    if(pagesView) pagesView.style.display = view === 'pages' ? 'block' : 'none';
    if(pluginsView) pluginsView.style.display = view === 'plugins' ? 'block' : 'none';
    
    document.querySelectorAll('.rgaa-tabs button').forEach(btn => {
      btn.className = btn.dataset.tab === view ? 'button button-primary' : 'button';
    });
  }

  // ============= FONCTIONS POUR L'AUDIT DES PLUGINS (seulement si API disponible) =============

  if(hasAPI) {
    async function loadPlugins() {
      try {
        const response = await fetch(CFG.apiUrl + '/plugins', {
          headers: {'X-WP-Nonce': CFG.nonce}
        });
        if (!response.ok) throw new Error('Erreur de chargement');
        const data = await response.json();
        pluginsData = data.data || [];
        renderPluginsTable();
        updatePluginsSummary();
        return pluginsData;
      } catch (error) {
        alert('Erreur lors du chargement des plugins : ' + error.message);
        return [];
      }
    }

    async function analyzePlugin(pluginPath) {
      try {
        const response = await fetch(CFG.apiUrl + '/plugins/analyze', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': CFG.nonce
          },
          body: JSON.stringify({ plugin_path: pluginPath })
        });
        if (!response.ok) throw new Error('Erreur d\'analyse');
        const data = await response.json();
        const analysis = data.data;
        pluginAnalyses.set(pluginPath, analysis);
        renderPluginsTable();
        updatePluginsSummary();
        return analysis;
      } catch (error) {
        console.error('Erreur analyse plugin:', error);
        throw error;
      }
    }

    async function analyzeAllPlugins() {
      if (pluginsData.length === 0) {
        alert('Chargez d\'abord la liste des plugins');
        return;
      }
      const btn = document.getElementById('plugins-analyze-all');
      const originalText = btn.textContent;
      let completed = 0;
      btn.disabled = true;
      btn.textContent = 'Analyse en cours...';
      for (const plugin of pluginsData) {
        try {
          await analyzePlugin(plugin.path);
          completed++;
          btn.textContent = `Analyse ${completed}/${pluginsData.length}...`;
        } catch (error) {
          console.error(`Erreur pour ${plugin.name}:`, error);
        }
      }
      btn.disabled = false;
      btn.textContent = originalText;
      alert('Analyse terminée !');
    }

    function renderPluginsTable() {
      const tbody = document.getElementById('plugins-tbody');
      if(!tbody) return;
      tbody.innerHTML = '';
      if (pluginsData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:20px;color:#666">Aucun plugin chargé. Cliquez sur "Charger les plugins actifs"</td></tr>';
        return;
      }
      pluginsData.forEach((plugin, index) => {
        const analysis = pluginAnalyses.get(plugin.path);
        const tr = document.createElement('tr');
        tr.style.background = index % 2 === 0 ? '#fff' : '#f9f9f9';
        let scoreCell = '<td style="border:1px solid #ddd;padding:8px;text-align:center">-</td>';
        let statusCell = '<td style="border:1px solid #ddd;padding:8px;text-align:center">-</td>';
        let issuesCell = '<td style="border:1px solid #ddd;padding:8px;text-align:center">-</td>';
        let actionCell = `<td style="border:1px solid #ddd;padding:8px;text-align:center"><button class="button button-small analyze-plugin-btn" data-path="${escapeHtml(plugin.path)}">Analyser</button></td>`;
        if (analysis) {
          const scoreColor = analysis.score >= 80 ? '#4caf50' : analysis.score >= 50 ? '#ff9800' : '#f44336';
          scoreCell = `<td style="border:1px solid #ddd;padding:8px;text-align:center"><strong style="color:${scoreColor};font-size:18px">${analysis.score}</strong>/100</td>`;
          const statusBadge = analysis.status === 'pass' ? 'badge-pass' : analysis.status === 'manual' ? 'badge-manual' : 'badge-fail';
          statusCell = `<td style="border:1px solid #ddd;padding:8px;text-align:center"><span class="rgaa-badge ${statusBadge}">${STATUS_LABEL[analysis.status] || analysis.status}</span></td>`;
          issuesCell = `<td style="border:1px solid #ddd;padding:8px;text-align:center"><span style="color:#f44336;font-weight:600">${analysis.stats.critical}</span> / <span style="color:#ff9800;font-weight:600">${analysis.stats.major}</span> / <span style="color:#2196f3">${analysis.stats.minor}</span></td>`;
          actionCell = `<td style="border:1px solid #ddd;padding:8px;text-align:center"><button class="button button-small view-plugin-details" data-path="${escapeHtml(plugin.path)}">Détails</button></td>`;
        }
        tr.innerHTML = `<td style="border:1px solid #ddd;padding:8px"><strong>${escapeHtml(plugin.name)}</strong><br><small style="color:#666">${escapeHtml(plugin.author)}</small></td><td style="border:1px solid #ddd;padding:8px;text-align:center">${escapeHtml(plugin.version)}</td>${scoreCell}${statusCell}${issuesCell}${actionCell}`;
        tbody.appendChild(tr);
      });
      document.querySelectorAll('.analyze-plugin-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          const path = btn.dataset.path;
          btn.disabled = true;
          btn.textContent = 'Analyse...';
          try {
            await analyzePlugin(path);
          } catch (error) {
            alert('Erreur: ' + error.message);
          }
          btn.disabled = false;
          btn.textContent = 'Analyser';
        });
      });
      document.querySelectorAll('.view-plugin-details').forEach(btn => {
        btn.addEventListener('click', () => {
          const path = btn.dataset.path;
          showPluginDetails(path);
        });
      });
    }

    function updatePluginsSummary() {
      const summary = document.getElementById('plugins-summary');
      if(!summary) return;
      if (pluginAnalyses.size === 0) {
        summary.style.display = 'none';
        return;
      }
      summary.style.display = 'block';
      let totalScore = 0, totalCritical = 0, totalMajor = 0, totalMinor = 0, passCount = 0, manualCount = 0, failCount = 0;
      pluginAnalyses.forEach(analysis => {
        totalScore += analysis.score;
        totalCritical += analysis.stats.critical;
        totalMajor += analysis.stats.major;
        totalMinor += analysis.stats.minor;
        if (analysis.status === 'pass') passCount++;
        else if (analysis.status === 'manual') manualCount++;
        else failCount++;
      });
      const avgScore = Math.round(totalScore / pluginAnalyses.size);
      summary.innerHTML = `<h3 style="margin:0 0 12px 0">Résumé de l'analyse (${pluginAnalyses.size} plugin${pluginAnalyses.size > 1 ? 's' : ''} analysé${pluginAnalyses.size > 1 ? 's' : ''})</h3><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px"><div><div style="font-size:28px;font-weight:bold;color:${avgScore >= 80 ? '#4caf50' : avgScore >= 50 ? '#ff9800' : '#f44336'}">${avgScore}/100</div><div style="font-size:12px;color:#666">Score moyen</div></div><div><div style="font-size:20px"><span class="rgaa-badge badge-pass">${passCount}</span> <span class="rgaa-badge badge-manual">${manualCount}</span> <span class="rgaa-badge badge-fail">${failCount}</span></div><div style="font-size:12px;color:#666">Statuts</div></div><div><div style="font-size:20px"><span style="color:#f44336;font-weight:600">${totalCritical}</span> / <span style="color:#ff9800;font-weight:600">${totalMajor}</span> / <span style="color:#2196f3">${totalMinor}</span></div><div style="font-size:12px;color:#666">Problèmes (critique / majeur / mineur)</div></div></div>`;
    }

    function showPluginDetails(pluginPath) {
      const analysis = pluginAnalyses.get(pluginPath);
      if (!analysis) return;
      const plugin = pluginsData.find(p => p.path === pluginPath);
      if (!plugin) return;
      let issuesHtml = '<table style="width:100%;border-collapse:collapse;margin-top:16px"><thead><tr><th style="border:1px solid #ddd;padding:8px;text-align:left">Fichier</th><th style="border:1px solid #ddd;padding:8px">Type</th><th style="border:1px solid #ddd;padding:8px">Sévérité</th><th style="border:1px solid #ddd;padding:8px">Catégorie</th><th style="border:1px solid #ddd;padding:8px">Critère</th><th style="border:1px solid #ddd;padding:8px;text-align:left">Message</th></tr></thead><tbody>';
      if (analysis.issues.length === 0) {
        issuesHtml += '<tr><td colspan="6" style="padding:20px;text-align:center;color:#666">Aucun problème détecté</td></tr>';
      } else {
        analysis.issues.forEach(issue => {
          const severityColor = issue.severity === 'critical' ? '#f44336' : issue.severity === 'major' ? '#ff9800' : '#2196f3';
          const theme = THEMES_MAP.get(String(issue.theme));
          issuesHtml += `<tr><td style="border:1px solid #ddd;padding:8px"><code style="font-size:11px">${escapeHtml(issue.file)}</code></td><td style="border:1px solid #ddd;padding:8px;text-align:center">${escapeHtml(issue.type)}</td><td style="border:1px solid #ddd;padding:8px;text-align:center"><span style="color:${severityColor};font-weight:600">${SEVERITY_LABEL[issue.severity] || issue.severity}</span></td><td style="border:1px solid #ddd;padding:8px;font-size:11px">${theme ? theme.name : '-'}</td><td style="border:1px solid #ddd;padding:8px;text-align:center">${escapeHtml(issue.criterion)}</td><td style="border:1px solid #ddd;padding:8px">${escapeHtml(issue.message)}<br><small style="color:#666">${escapeHtml(issue.details || '')}</small></td></tr>`;
        });
      }
      issuesHtml += '</tbody></table>';
      const scoreColor = analysis.score >= 80 ? '#4caf50' : analysis.score >= 50 ? '#ff9800' : '#f44336';
      const statusBadge = analysis.status === 'pass' ? 'badge-pass' : analysis.status === 'manual' ? 'badge-manual' : 'badge-fail';
      const content = `<div style="padding:20px"><h2 style="margin:0 0 8px 0">${escapeHtml(plugin.name)} <span style="color:#666;font-size:14px;font-weight:normal">v${escapeHtml(plugin.version)}</span></h2><p style="margin:0 0 16px 0;color:#666">${escapeHtml(plugin.description)}</p><div style="display:flex;gap:24px;margin-bottom:24px;padding:16px;background:#f9f9f9;border-radius:4px"><div><div style="font-size:32px;font-weight:bold;color:${scoreColor}">${analysis.score}/100</div><div style="font-size:12px;color:#666">Score d'accessibilité</div></div><div><div style="font-size:18px"><span class="rgaa-badge ${statusBadge}">${STATUS_LABEL[analysis.status] || analysis.status}</span></div><div style="font-size:12px;color:#666;margin-top:4px">Statut global</div></div><div><div style="font-size:18px"><span style="color:#f44336;font-weight:600">${analysis.stats.critical}</span> critique${analysis.stats.critical > 1 ? 's' : ''}<br><span style="color:#ff9800;font-weight:600">${analysis.stats.major}</span> majeur${analysis.stats.major > 1 ? 's' : ''}<br><span style="color:#2196f3">${analysis.stats.minor}</span> mineur${analysis.stats.minor > 1 ? 's' : ''}</div><div style="font-size:12px;color:#666;margin-top:4px">Problèmes détectés</div></div></div><h3>Détails des problèmes</h3>${issuesHtml}</div>`;
      showModal(content, `Analyse RGAA - ${plugin.name}`);
    }

    function showModal(content, title) {
      const backdrop = document.createElement('div');
      backdrop.className = 'rgaa-modal-backdrop';
      const modal = document.createElement('div');
      modal.className = 'rgaa-modal';
      modal.style.maxWidth = '1200px';
      modal.style.width = '95vw';
      modal.innerHTML = `<header><h3 style="margin:0">${escapeHtml(title)}</h3><button class="button" id="modal-close">✕</button></header><div class="body" style="max-height:70vh;overflow:auto">${content}</div><footer><button class="button button-primary" id="modal-ok">Fermer</button></footer>`;
      document.body.appendChild(backdrop);
      document.body.appendChild(modal);
      function close() {
        backdrop.remove();
        modal.remove();
      }
      backdrop.addEventListener('click', close);
      modal.querySelector('#modal-close').addEventListener('click', close);
      modal.querySelector('#modal-ok').addEventListener('click', close);
    }

    function exportPluginsAnalysis() {
      if (pluginAnalyses.size === 0) {
        alert('Aucune analyse à exporter. Analysez d\'abord les plugins.');
        return;
      }
      const data = {
        generatedAt: new Date().toISOString(),
        summary: {
          totalPlugins: pluginAnalyses.size,
          averageScore: Math.round(Array.from(pluginAnalyses.values()).reduce((sum, a) => sum + a.score, 0) / pluginAnalyses.size)
        },
        plugins: Array.from(pluginAnalyses.values())
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'rgaa-plugins-analysis.json';
      a.click();
      URL.revokeObjectURL(a.href);
    }

    // Event listeners pour les plugins
    const plLoad = byId('plugins-load');
    const plAnalyze = byId('plugins-analyze-all');
    const plExport = byId('plugins-export');
    if(plLoad) plLoad.addEventListener('click', loadPlugins);
    if(plAnalyze) plAnalyze.addEventListener('click', analyzeAllPlugins);
    if(plExport) plExport.addEventListener('click', exportPluginsAnalysis);
  }

  // ============= FONCTIONS POUR L'AUDIT DES PAGES =============
  
  function isVisible(el){ if(!el) return false; try{ const cs=iframe.contentWindow.getComputedStyle(el); return cs.display!=='none'&&cs.visibility!=='hidden'; }catch(e){ return false; } }
  function tag(el){ return el ? `${el.tagName.toLowerCase()}${++RGAA_COUNTER}` : 'unknown'; }
  function updateUrlBar(){ try{ const h=iframe.contentWindow.location.href; if(h) urlInput.value=h; }catch(_){} }
  function syncPanelHeight(){ const panel=byId('rgaa-panel-scroll'); if(panel && iframe) panel.style.maxHeight=iframe.offsetHeight+'px'; }
  function updateSummary(){ const s=byId('rgaa-summary'); if(!s) return; const c=countsFromIssues(issues); s.textContent=`Échecs: ${c.fail} • À vérifier: ${c.manual} • OK: ${c.pass}`; }
  function setProgress(pct){ const bar=byId('rgaa-progress-bar'); if(bar) bar.style.width=(pct*100)+'%'; }
  function renderQueue(){ const tbody=byId('rgaa-queue')?.querySelector('tbody'); if(!tbody) return; tbody.innerHTML=''; const done=queue.filter(q=>q.status==='done'||q.status==='error').length; setProgress(queue.length?done/queue.length:0); queue.forEach((q,i)=>{ const tr=document.createElement('tr'); const dur=(q.durationMs/1000).toFixed(1); const cls=q.status==='done'?'status-done':q.status==='error'?'status-error':q.status==='running'?'status-running':'status-pending'; tr.innerHTML=`<td>${i+1}</td><td style="word-break:break-all">${escapeHtml(q.url)}</td><td><span class="rgaa-status ${cls}">${q.status}</span></td><td>${(q.counts?.fail)||0}</td><td>${(q.counts?.manual)||0}</td><td>${(q.counts?.pass)||0}</td><td>${dur}</td>`; tbody.appendChild(tr); }); }
  function renderPlaceholders(filterTheme){ const wrap=byId('rgaa-placeholders'); if(!wrap) return; if(filterTheme==='all'){ wrap.style.display='none'; return; } const tid=parseInt(filterTheme,10); const theme=THEMES_MAP.get(String(tid)); if(!theme||!theme.tests){ wrap.style.display='none'; return; } const covered=new Set(issues.filter(it=>String(it.themeId||'')===String(tid)).map(it=>it.rule)); const missing=theme.tests.filter(t=>!covered.has(t)); if(missing.length===0){ wrap.style.display='none'; return; } wrap.style.display='block'; wrap.innerHTML='<strong>Tests non couverts :</strong><br>'+missing.map(t=>`<span class="rgaa-chip">${t}</span>`).join(''); }
  function renderTable(){ if(!statusSelect || !themeSelect) return; const filterStatus=statusSelect.value,filterTheme=themeSelect.value; const tbody=byId('rgaa-issues')?.querySelector('tbody'); if(!tbody) return; tbody.innerHTML=''; let n=0; const filtered=issues.filter(it=>{ const okTheme=filterTheme==='all'||String(it.themeId||'')===String(filterTheme); const okStatus=filterStatus==='all'||it.status===filterStatus; return okTheme&&okStatus; }); filtered.forEach((it)=>{ const idx=issues.indexOf(it); const tr=document.createElement('tr'); tr.innerHTML=`<td>${++n}</td><td>${it.type}</td><td>${it.themeName||''}</td><td>${it.rule||''}</td><td><span class="rgaa-badge ${it.status==='fail'?'badge-fail':it.status==='manual'?'badge-manual':'badge-pass'}">${it.status}</span></td><td>${escapeHtml(it.message||'')}</td><td><a class="button" href="#rgaa=${idx}">Voir</a></td>`; tbody.appendChild(tr); }); renderPlaceholders(filterTheme); }

  function countsFromIssues(arr){ const c={fail:0,manual:0,pass:0}; arr.forEach(i=>{ c[i.status]=(c[i.status]||0)+1; }); return c; }
  function pushIssue(type,rule,status,message,selector,eid,themeId){ const tId=themeId||mapTypeToThemeId(type); const tObj=tId?THEMES_MAP.get(String(tId)):null; issues.push({type,rule,status,message,selector,eid,themeId:tId,themeName:tObj?tObj.name:''}); }

  function parseColor(v){ const ctx=(v||'').trim(); if(ctx.startsWith('rgb')){ const m=ctx.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/); if(!m) return null; return {r:+m[1],g:+m[2],b:+m[3],a:m[4]!==undefined?+m[4]:1}; } return null; }
  function relLuminance({r,g,b}){ const sr=[r,g,b].map(v=>{ v/=255; return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4);}); return 0.2126*sr[0]+0.7152*sr[1]+0.0722*sr[2]; }
  function contrastRatio(c1,c2){ const L1=relLuminance(c1),L2=relLuminance(c2); const [a,b]=L1>=L2?[L1,L2]:[L2,L1]; return (a+0.05)/(b+0.05); }
  function getEffectiveBg(el){ let e=el,s=0; while(e&&s++<20){ try{ const cs=iframe.contentWindow.getComputedStyle(e); const bg=parseColor(cs.backgroundColor||''); if(bg&&bg.a>=0.99) return bg; e=e.parentElement; }catch(err){ return null; } } return null; }
  function isLargeText(el){ try{ const cs=iframe.contentWindow.getComputedStyle(el); const sizePx=parseFloat(cs.fontSize)||0; const weight=parseInt(cs.fontWeight)||400; return sizePx>=19||(sizePx>=14&&weight>=700); }catch(e){ return false; } }
  function uniqueSelector(el){ if(!(el instanceof Element)) return ''; const doc=iframe.contentDocument; if(!doc) return ''; const parts=[]; while(el&&el.nodeType===1&&el!==doc.body){ let sel=el.nodeName.toLowerCase(); if(el.id){ sel+='#'+CSS.escape(el.id); parts.unshift(sel); break; } let sib=el,i=1; while((sib=sib.previousElementSibling)!=null){ if(sib.nodeName===el.nodeName) i++; } sel+=':nth-of-type('+i+')'; parts.unshift(sel); el=el.parentElement; } return parts.join(' > '); }
  function accessibleName(el){ if(!el) return ''; const ariaLabel=el.getAttribute('aria-label'); if(ariaLabel) return ariaLabel.trim(); const labelledby=el.getAttribute('aria-labelledby'); if(labelledby){ try{ const doc=iframe.contentDocument; if(!doc) return ''; const s=labelledby.split(/\s+/).map(id=>doc.getElementById(id)).filter(Boolean).map(n=>n.textContent.trim()).join(' '); if(s) return s; }catch(e){ return ''; } } if(el.alt) return String(el.alt).trim(); if(el.title) return String(el.title).trim(); return (el.textContent||'').trim(); }

  function ruleImageAlt(doc){ if(!doc) return; $$('img',doc).forEach(img=>{ if(!isVisible(img)) return; const alt=img.getAttribute('alt'); const sel=uniqueSelector(img); const eid=tag(img); if(alt===null){ pushIssue('images','1.1.1','fail','Image sans attribut alt',sel,eid,1); } else if(alt.trim()===''){ pushIssue('images','1.1.1','manual','alt vide. Vérifier décoratif',sel,eid,1); } else { if(/\.(jpe?g|png|gif|webp|svg)$/i.test(alt)||/IMG_\d+/i.test(alt)) pushIssue('images','1.1.1','manual','alt semble être un nom de fichier',sel,eid,1); else pushIssue('images','1.1.1','pass','alt présent',sel,eid,1); } }); }
  function ruleAria(doc){ if(!doc) return; $$('[role]',doc).forEach(el=>{ if(!isVisible(el)) return; const role=(el.getAttribute('role')||'').trim(); const meta=ARIA_MAP[role]; const sel=uniqueSelector(el); const eid=tag(el); if(!meta){ pushIssue('aria','4.1.2','manual','rôle ARIA non répertorié: '+role,sel,eid,7); return; } if(meta.requiresName){ const name=accessibleName(el); if(!name) pushIssue('aria','4.1.2','fail','Nom accessible manquant',sel,eid,7); else pushIssue('aria','4.1.2','pass','Nom accessible présent',sel,eid,7); } }); }
  function ruleContrast(doc){ if(!doc || !doc.body) return; try{ const walker=doc.createTreeWalker(doc.body,NodeFilter.SHOW_ELEMENT,{acceptNode(node){ if(!isVisible(node)) return NodeFilter.FILTER_REJECT; const txt=(node.textContent||'').trim(); if(!txt) return NodeFilter.FILTER_SKIP; if(node.children.length>0 && node.innerText && node.innerText.trim()==='') return NodeFilter.FILTER_SKIP; return NodeFilter.FILTER_ACCEPT; }}); let node; const seen=new Set(); while((node=walker.nextNode())){ if(seen.has(node)) continue; seen.add(node); try{ const cs=iframe.contentWindow.getComputedStyle(node); const fg=parseColor(cs.color||''); const bg=getEffectiveBg(node); const sel=uniqueSelector(node); const eid=tag(node); if(!fg||!bg){ pushIssue('contrast','3.2.x','manual','Contexte de couleur indéterminé',sel,eid,3); continue; } const ratio=contrastRatio(fg,bg); const large=isLargeText(node); const threshold=large?3.0:4.5; if(ratio<threshold) pushIssue('contrast','3.2.x','fail','Contraste '+ratio.toFixed(2)+' < '+threshold+':1',sel,eid,3); else pushIssue('contrast','3.2.x','pass','Contraste '+ratio.toFixed(2)+' ≥ '+threshold+':1',sel,eid,3); }catch(e){ continue; } } }catch(e){ console.error('Error in contrast check:', e); } }

  async function auditURL(url,updateUI){ issues.length=0; if(updateUI){ renderTable(); updateSummary(); } iframe.src=url; await new Promise((res,rej)=>{ const to=setTimeout(()=>rej(new Error('timeout')),20000); iframe.onload=()=>{clearTimeout(to);res();}; iframe.onerror=()=>{clearTimeout(to);rej(new Error('load error'));}; }); const doc=iframe.contentDocument; if(!doc) throw new Error('Accès document impossible.'); ruleImageAlt(doc); ruleAria(doc); ruleContrast(doc); if(updateUI){ updateSummary(); renderTable(); } syncPanelHeight(); updateUrlBar(); return issues.slice(); }

  async function runQueue(){ if(running) return; running=true; stopFlag=false; setProgress(0); renderQueue(); for(const item of queue){ if(stopFlag) break; if(item.status!=='pending') continue; item.status='running'; renderQueue(); const t0=performance.now(); try{ const list=await auditURL(item.url,true); item.issues=list; item.counts=countsFromIssues(list); item.status='done'; }catch(e){ item.status='error'; item.error=e.message; } item.durationMs=performance.now()-t0; renderQueue(); } running=false; }
  function stopQueue(){ stopFlag=true; }
  function clearQueue(){ if(running){ alert('Arrêtez d\'abord la file.'); return; } queue.length=0; renderQueue(); }
  function exportBatchJSON(){ const payload=queue.map(q=>({url:q.url,status:q.status,counts:q.counts,durationMs:q.durationMs,issues:q.issues})); const blob=new Blob([JSON.stringify({generatedAt:new Date().toISOString(),pages:payload},null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='rgaa-batch.json'; a.click(); URL.revokeObjectURL(a.href); }
  function exportBatchCSV(){ const rows=[['url','type','theme','regle','statut','message','selector','eid']]; queue.forEach(q=>{ (q.issues||[]).forEach(i=>{ rows.push([q.url,i.type,i.themeName||'',i.rule,i.status,(i.message||'').replace(/\n/g,' '),i.selector||'',i.eid||'']); }); }); const csv=rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n'); const blob=new Blob([csv],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='rgaa-batch.csv'; a.click(); URL.revokeObjectURL(a.href); }
  async function loadWPSitemap(limit){ try{ const res=await fetch('/wp-sitemap.xml'); const txt=await res.text(); const parser=new DOMParser(); const xml=parser.parseFromString(txt,'text/xml'); const locs=Array.from(xml.querySelectorAll('loc')).map(l=>l.textContent.trim()); return locs.slice(0,limit); }catch(e){ alert('Erreur lors du chargement du sitemap'); return []; } }

  // Event listeners pour les pages
  const scanBtn = byId('rgaa-scan');
  const exportBtn = byId('rgaa-export');
  const homeBtn = byId('rgaa-home');
  if(scanBtn) scanBtn.addEventListener('click',async()=>{ let target=urlInput.value.trim(); try{ const href=iframe.contentWindow.location.href; if(href) target=href; }catch(_){} if(!target){ alert('Aucune URL.'); return; } try{ await auditURL(target,true); }catch(e){ alert('Erreur: '+e.message); } });
  if(exportBtn) exportBtn.addEventListener('click',()=>{ const blob=new Blob([JSON.stringify({issues},null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='rgaa-audit.json'; a.click(); URL.revokeObjectURL(a.href); });
  if(homeBtn) homeBtn.addEventListener('click',()=>{ iframe.src=CFG.home||'/'; });

  const queueAdd = byId('rgaa-queue-add');
  const queueSitemap = byId('rgaa-queue-sitemap');
  const queueStart = byId('rgaa-queue-start');
  const queueStop = byId('rgaa-queue-stop');
  const queueClear = byId('rgaa-queue-clear');
  const queueExportJson = byId('rgaa-queue-export-json');
  const queueExportCsv = byId('rgaa-queue-export-csv');
  
  if(queueAdd) queueAdd.addEventListener('click',()=>{ const lines=byId('rgaa-urls-text').value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean); addToQueue(lines); });
  if(queueSitemap) queueSitemap.addEventListener('click',async()=>{ const limit=Math.max(1,Math.min(2000,parseInt(byId('rgaa-sitemap-limit').value)||200)); const urls=await loadWPSitemap(limit); addToQueue(urls); });
  if(queueStart) queueStart.addEventListener('click',runQueue);
  if(queueStop) queueStop.addEventListener('click',stopQueue);
  if(queueClear) queueClear.addEventListener('click',clearQueue);
  if(queueExportJson) queueExportJson.addEventListener('click',exportBatchJSON);
  if(queueExportCsv) queueExportCsv.addEventListener('click',exportBatchCSV);

  if(statusSelect) statusSelect.addEventListener('change',renderTable);
  if(themeSelect) themeSelect.addEventListener('change',renderTable);

  function addToQueue(urls){ const origin=location.origin; const exist=new Set(queue.map(q=>q.url)); urls.forEach(u=>{ try{ const url=new URL(u.trim()); if(url.origin!==origin) return; if(exist.has(url.href)) return; queue.push({url:url.href,status:'pending'}); exist.add(url.href);}catch(_){}}); renderQueue(); }
  function escapeHtml(s){ return (s||'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c])); }

  // Init
  iframe.src=CFG.home||'/'; 
  urlInput.value=CFG.home||'/';
  
  console.log('RGAA: Plugin loaded successfully!');
})();