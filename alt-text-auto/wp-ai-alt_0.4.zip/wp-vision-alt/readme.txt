Vision ALT – Générateur d’attributs ALT (Ollama + Gemini)
