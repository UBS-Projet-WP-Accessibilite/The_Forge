<?php
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', function(){
    $cap = 'manage_options';
    add_menu_page(
        'Vision ALT', 'Vision ALT', $cap, WPAI_VISION_SLUG, 'wpai_admin_settings_page',
        'dashicons-visibility', 58
    );
    add_submenu_page(WPAI_VISION_SLUG, 'Réglages', 'Réglages', $cap, WPAI_VISION_SLUG, 'wpai_admin_settings_page');
    add_submenu_page(WPAI_VISION_SLUG, 'Outils', 'Outils', $cap, WPAI_VISION_SLUG.'_tools', 'wpai_admin_tools_page');
    add_submenu_page(WPAI_VISION_SLUG, 'Aide', 'Aide', $cap, WPAI_VISION_SLUG.'_help', 'wpai_admin_help_page');
    add_submenu_page(WPAI_VISION_SLUG, 'Diagnostic', 'Diagnostic', $cap, WPAI_VISION_SLUG.'_diag', 'wpai_admin_diag_page');
});

add_action('admin_enqueue_scripts', function($hook){
    if (strpos($hook, WPAI_VISION_SLUG) === false) return;
    wp_enqueue_style('wpai_admin', WPAI_VISION_URL.'assets/admin.css', [], WPAI_VISION_VER);
    wp_enqueue_script('wpai_admin', WPAI_VISION_URL.'assets/admin.js', ['jquery'], WPAI_VISION_VER, true);
    wp_localize_script('wpai_admin', 'WPAI', [
        'ajax'  => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('wpai_nonce'),
        'settings'=> wpai_settings(),
    ]);
});

function wpai_admin_settings_page(){ include WPAI_VISION_DIR.'admin/views/settings.php'; }
function wpai_admin_tools_page(){ include WPAI_VISION_DIR.'admin/views/tools.php'; }
function wpai_admin_help_page(){ include WPAI_VISION_DIR.'admin/views/help.php'; }
function wpai_admin_diag_page(){ include WPAI_VISION_DIR.'admin/views/diagnostic.php'; }
