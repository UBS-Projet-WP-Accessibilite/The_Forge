<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap wpai-wrap">
  <h1>Vision ALT — Diagnostic</h1>
  <div class="wpai-card">
    <h2>Test lecture fichier</h2>
    <p>Entrer l’ID d’une image pour vérifier que WordPress peut lire le fichier localement.</p>
    <p>
      <input type="number" id="diag_id" placeholder="ID de l’image">
      <button class="button" id="diag_test">Tester</button>
      <span id="diag_out"></span>
    </p>
  </div>
</div>
