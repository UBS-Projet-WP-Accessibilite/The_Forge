<?php if (!defined('ABSPATH')) { exit; } $s = wpai_settings(); ?>
<div class="wrap wpai-wrap">
  <h1>Vision ALT — Réglages</h1>
  <div class="wpai-grid">
    <div class="wpai-card">
      <h2>Connexion</h2>
      <p>Configurer les fournisseurs utilisés pour générer l’attribut <code>alt</code> à partir d’images.</p>

      <label><input type="checkbox" id="use_ollama" <?php checked(!empty($s['use_ollama'])); ?>> Utiliser Ollama (local)</label>
      <div class="wpai-row">
        <label>URL de base Ollama</label>
        <input type="text" id="base_url" value="<?php echo esc_attr($s['base_url']); ?>" placeholder="http://localhost:11434">
      </div>
      <div class="wpai-row">
        <label>Modèle</label>
        <input type="text" id="model" value="<?php echo esc_attr($s['model']); ?>" placeholder="moondream:latest">
        <button class="button" id="detect_models">Détection automatique</button>
      </div>
      <div class="wpai-row">
        <button class="button button-secondary" id="test_conn">Tester connexion</button>
        <span id="conn_result"></span>
      </div>

      <hr>

      <label><input type="checkbox" id="use_gemini" <?php checked(!empty($s['use_gemini'])); ?>> Utiliser Gemini Vision</label>
      <div class="wpai-row">
        <label>Clé API Gemini</label>
        <input type="password" id="gemini_api_key" value="<?php echo esc_attr($s['gemini_api_key']); ?>" placeholder="AIza...">
      </div>
      <p class="description">Gemini Vision impose des quotas par projet Google Cloud. Le plugin applique aussi un quota logiciel (ci-dessous).</p>

      <hr>
      <h2>Qualité & langue</h2>
      <div class="wpai-row">
        <label>Niveau de détail</label>
        <select id="detail_level">
          <option value="basic" <?php selected($s['detail_level'],'basic'); ?>>Basique</option>
          <option value="full" <?php selected($s['detail_level'],'full'); ?>>Complet</option>
          <option value="seo" <?php selected($s['detail_level'],'seo'); ?>>Riche SEO</option>
        </select>
      </div>
      <div class="wpai-row">
        <label>Température</label>
        <input type="number" step="0.05" min="0" max="1" id="temperature" value="<?php echo esc_attr($s['temperature']); ?>">
      </div>
      <div class="wpai-row">
        <label>Longueur cible (caractères)</label>
        <input type="number" min="20" max="300" id="max_chars" value="<?php echo esc_attr($s['max_chars']); ?>">
      </div>
      <div class="wpai-row">
        <label>Langue</label>
        <input type="text" id="language" value="<?php echo esc_attr($s['language']); ?>" placeholder="fr">
      </div>
      <div class="wpai-row">
        <label>Contexte</label>
        <label><input type="checkbox" id="ctx_filename" <?php checked(!empty($s['use_context']['filename'])); ?>> Nom de fichier</label>
        <label><input type="checkbox" id="ctx_title" <?php checked(!empty($s['use_context']['title'])); ?>> Titre du média</label>
        <label><input type="checkbox" id="ctx_tax" <?php checked(!empty($s['use_context']['taxonomies'])); ?>> Taxonomies</label>
        <label><input type="checkbox" id="ctx_seo" <?php checked(!empty($s['use_context']['seo'])); ?>> Indices SEO</label>
      </div>

      <hr>
      <h2>Quotas & Debug</h2>
      <div class="wpai-row">
        <label>Quota quotidien (générations)</label>
        <input type="number" min="0" id="daily_quota" value="<?php echo esc_attr($s['daily_quota']); ?>">
      </div>
      <label><input type="checkbox" id="debug" <?php checked(!empty($s['debug'])); ?>> Activer le journal détaillé</label>

      <p><button class="button button-primary" id="save_settings">Enregistrer</button>
         <span id="save_ok"></span></p>
    </div>

    <div class="wpai-card">
      <h2>Astuce LocalWP</h2>
      <p>Si WordPress tourne dans un conteneur (<strong>LocalWP</strong>), l’URL <code>http://localhost:11434</code> fonctionne la plupart du temps. Sinon, essayez <code>http://127.0.0.1:11434</code>. La résolution <code>host.docker.internal</code> peut ne pas exister sous Windows/Linux.</p>
      <p>Vous pouvez tester et détecter les modèles avec les boutons ci-dessus.</p>
    </div>
  </div>
</div>
