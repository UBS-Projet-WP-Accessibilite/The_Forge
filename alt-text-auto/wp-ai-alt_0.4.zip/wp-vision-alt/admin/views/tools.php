<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap wpai-wrap">
  <h1>Vision ALT — Outils</h1>
  <div class="wpai-grid">
    <div class="wpai-card">
      <h2>Scanner & générer</h2>
      <p>Rechercher les images sans attribut <code>alt</code>, puis lancer une génération en masse.</p>
      <p>
        <button class="button" id="scan_images">Scanner les images sans ALT</button>
        <span id="scan_count"></span>
      </p>
      <div id="scan_results"></div>
      <p>
        <button class="button button-primary" id="generate_all" disabled>Générer pour toutes</button>
      </p>
    </div>

    <div class="wpai-card">
      <h2>Journal (Debug)</h2>
      <p>Affiche chaque étape : connexion API, erreurs détaillées, encodage, création d’alt, etc.</p>
      <p>
        <button class="button" id="refresh_logs">Rafraîchir</button>
        <button class="button" id="clear_logs">Vider</button>
      </p>
      <div id="logs" class="wpai-logs"></div>
    </div>
  </div>
</div>
