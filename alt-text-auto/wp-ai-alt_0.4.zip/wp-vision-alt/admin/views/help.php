<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap wpai-wrap">
  <h1>Vision ALT — Aide</h1>

  <div class="wpai-card">
    <h2>Ce que fait l’extension</h2>
    <ul>
      <li>Génère des textes alternatifs (alt) à partir des images en local (Ollama: LLaVA, Moondream) ou via Gemini Vision.</li>
      <li>Traitement de masse et détection des images sans alt.</li>
      <li>Journal détaillé (mode Debug) pour faciliter l’installation et le débogage.</li>
      <li>Réglages de qualité : niveau de détail, longueur, langue, température.</li>
    </ul>
  </div>

  <div class="wpai-card">
    <h2>Installation rapide d’Ollama (local)</h2>
    <ol>
      <li>Installez Ollama : <a href="https://ollama.com" target="_blank" rel="noopener">ollama.com</a>.</li>
      <li>Lancez Ollama puis téléchargez un modèle vision : <code>ollama run moondream</code> ou <code>ollama run llava</code>.</li>
      <li>Confirmez que l’API répond : <code>curl http://localhost:11434/api/version</code> doit renvoyer une version.</li>
      <li>Dans <strong>Réglages</strong> de l’extension : URL <code>http://localhost:11434</code>, modèle <code>moondream:latest</code> ou celui que vous avez.</li>
      <li>Cliquer sur <strong>Tester connexion</strong> et <strong>Détection automatique</strong> (pour lister les modèles disponibles).</li>
    </ol>
    <p class="description">Sous LocalWP/containers, préférez <code>http://127.0.0.1:11434</code> si <code>localhost</code> ne répond pas.</p>
  </div>

  <div class="wpai-card">
    <h2>Ajout de Gemini Vision (optionnel)</h2>
    <ol>
      <li>Créez une clé API sur Google AI Studio.</li>
      <li>Activez “Utiliser Gemini” et collez la clé dans les Réglages.</li>
      <li>Le quota Google s’applique côté Google Cloud ; l’extension applique aussi un quota quotidien logiciel.</li>
    </ol>
  </div>

  <div class="wpai-card">
    <h2>Ergonomie — idées à intégrer</h2>
    <ul>
      <li>Bouton “Scanner” dans la médiathèque pour lister les images sans alt.</li>
      <li>Traitement de masse avec barre de progression et logs en direct.</li>
      <li>Templates de prompts (Basique, Complet, Riche SEO) et réglages de température/longueur.</li>
      <li>Boutons “Tester connexion” et “Détecter modèles”.</li>
    </ul>
  </div>

  <div class="wpai-card">
    <h2>FAQ rapide</h2>
    <details>
      <summary>“Erreur: illegal base64 data…”</summary>
      <p>Corrigé par la lecture locale robuste + redimensionnement. Vérifiez les droits en écriture sur <code>wp-content/uploads/</code>.</p>
    </details>
    <details>
      <summary>Pourquoi certaines descriptions sont trop simples ?</summary>
      <p>Augmentez le “Niveau de détail” et la longueur cible, et baissez légèrement la température.</p>
    </details>
  </div>
</div>
