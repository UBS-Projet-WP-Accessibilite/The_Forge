(function($){
  function saveSettings(){
    const s = {
      use_ollama: $('#use_ollama').is(':checked')?1:0,
      base_url: $('#base_url').val().trim(),
      model: $('#model').val().trim(),
      use_gemini: $('#use_gemini').is(':checked')?1:0,
      gemini_api_key: $('#gemini_api_key').val().trim(),
      detail_level: $('#detail_level').val(),
      temperature: parseFloat($('#temperature').val() || '0.2'),
      max_chars: parseInt($('#max_chars').val() || '160'),
      language: $('#language').val().trim(),
      use_context: {
        filename: $('#ctx_filename').is(':checked')?1:0,
        title: $('#ctx_title').is(':checked')?1:0,
        taxonomies: $('#ctx_tax').is(':checked')?1:0,
        seo: $('#ctx_seo').is(':checked')?1:0
      },
      daily_quota: parseInt($('#daily_quota').val() || '0'),
      debug: $('#debug').is(':checked')?1:0
    };
    return $.post(WPAI.ajax, { action:'wpai_save_settings', nonce:WPAI.nonce, settings: JSON.stringify(s) });
  }

  $(document).on('click', '#save_settings', function(e){
    e.preventDefault();
    saveSettings().done(function(res){
      $('#save_ok').text('✔ Enregistré').fadeIn().delay(1200).fadeOut();
    });
  });

  $(document).on('click', '#detect_models', function(e){
    e.preventDefault();
    $('#detect_models').prop('disabled', true).text('Détection…');
    saveSettings().always(function(){
      $.post(WPAI.ajax, { action:'wpai_detect_models', nonce:WPAI.nonce })
      .done(function(res){
        if (res.success){
          const m = res.data.models || [];
          alert('Ollama '+(res.data.version||'')+'\nModèles détectés:\n- '+ m.join('\n- '));
          if (m.length && !$('#model').val().trim()){
            $('#model').val(m[0]);
          }
        } else {
          alert('Échec détection: '+ (res.data && res.data.error ? res.data.error : 'inconnu'));
        }
      })
      .always(function(){ $('#detect_models').prop('disabled', false).text('Détection automatique'); });
    });
  });

  $(document).on('click', '#test_conn', function(e){
    e.preventDefault();
    const base = $('#base_url').val().trim();
    $('#conn_result').text('Test…');
    $.post(WPAI.ajax, { action:'wpai_test_connection', nonce:WPAI.nonce, base })
      .done(function(res){
        if (res.success){
          $('#conn_result').text('Détecté '+ (res.data.version || ''));
        } else {
          $('#conn_result').text('Erreur: '+ (res.data && res.data.error ? res.data.error : 'inconnue'));
        }
      });
  });

  // Tools: scan
  $(document).on('click', '#scan_images', function(e){
    e.preventDefault();
    $('#scan_results').empty();
    $('#scan_count').text('Scan en cours…');
    $.post(WPAI.ajax, { action:'wpai_scan_images', nonce:WPAI.nonce })
      .done(function(res){
        if (!res.success){ $('#scan_count').text('Erreur de scan'); return; }
        const ids = res.data.ids || [];
        $('#scan_count').text('Trouvé: '+res.data.count+' image(s)');
        if (ids.length){
          ids.forEach(id => {
            const url = ajaxurl.replace('admin-ajax.php','') + 'media/' + id; // approx
            const img = wp.media.attachment(id);
            let thumb = '';
            if (img && img.attributes && img.attributes.sizes && img.attributes.sizes.thumbnail){
              thumb = img.attributes.sizes.thumbnail.url;
            }
            $('#scan_results').append(
              $('<div class="item">').append(
                $('<div class="id">').text('#'+id),
                $('<div class="thumb">').append( thumb ? $('<img>').attr('src', thumb) : $('<span>').text('img') ),
                $('<button class="button gen_one">').attr('data-id', id).text('Générer'),
                $('<span class="status">')
              )
            );
          });
          $('#generate_all').prop('disabled', false).data('ids', ids);
        } else {
          $('#scan_results').html('<p>Toutes les images semblent avoir un alt.</p>');
        }
      });
  });

  // generate one
  $(document).on('click', '.gen_one', function(e){
    e.preventDefault();
    const btn = $(this);
    const id = parseInt(btn.data('id'));
    const row = btn.closest('.item');
    row.find('.status').text('…');
    $.post(WPAI.ajax, { action:'wpai_generate_alt', nonce:WPAI.nonce, id })
      .done(function(res){
        if (res.success){
          row.find('.status').text('OK');
        } else {
          row.find('.status').text('Erreur: '+ (res.data && res.data.error ? res.data.error : ''));
        }
      });
  });

  // generate all
  $(document).on('click', '#generate_all', async function(e){
    e.preventDefault();
    const ids = $(this).data('ids') || [];
    for (let i=0;i<ids.length;i++){
      const id = ids[i];
      const row = $('#scan_results .item').filter(function(){ return $(this).find('.gen_one').data('id')==id; });
      row.find('.status').text('…');
      try {
        const res = await $.post(WPAI.ajax, { action:'wpai_generate_alt', nonce:WPAI.nonce, id });
        if (res.success){ row.find('.status').text('OK'); } else { row.find('.status').text('Erreur'); }
      } catch(e){ row.find('.status').text('Erreur'); }
    }
  });

  // logs
  function renderLogs(list){
    const wrap = $('#logs').empty();
    (list||[]).slice(-500).forEach(l => {
      const line = $('<div class="l">');
      line.append($('<span class="t">').text('['+(l.d||'')+' '+(l.t||'')+'] '));
      line.append(document.createTextNode(l.m || ''));
      if (l.c && Object.keys(l.c).length){
        line.append(document.createTextNode(' | ' + JSON.stringify(l.c)));
      }
      wrap.append(line);
    });
  }
  function refreshLogs(){
    $.post(WPAI.ajax, { action:'wpai_get_logs', nonce:WPAI.nonce })
      .done(function(res){
        if (res.success){ renderLogs(res.data.logs); }
      });
  }
  $(document).on('click', '#refresh_logs', function(e){ e.preventDefault(); refreshLogs(); });
  $(document).on('click', '#clear_logs', function(e){ e.preventDefault(); $.post(WPAI.ajax, { action:'wpai_clear_logs', nonce:WPAI.nonce }).always(refreshLogs); });
  // initial load if on tools page
  if ($('#logs').length) refreshLogs();

  // diag
  $(document).on('click', '#diag_test', function(e){
    e.preventDefault();
    const id = parseInt($('#diag_id').val()||'0');
    if (!id) return;
    $('#diag_out').text('Test…');
    $.post(WPAI.ajax, { action:'wpai_test_file_read', nonce:WPAI.nonce, id })
      .done(function(res){
        if (res.success){ $('#diag_out').text('OK, octets: '+res.data.size); }
        else { $('#diag_out').text('Erreur: '+(res.data && res.data.error ? res.data.error : '')); }
      });
  });

})(jQuery);
