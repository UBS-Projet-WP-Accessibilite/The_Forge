<?php
if (!defined('ABSPATH')) { exit; }

function wpai_log($message, $context = []){
    $settings = get_option('wpai_vision_settings', []);
    if (empty($settings['debug'])) return;
    $logs = get_option('wpai_vision_logs', []);
    $logs[] = [
        't' => current_time('H:i:s'),
        'd' => current_time('Y-m-d'),
        'm' => (string)$message,
        'c' => $context
    ];
    // cap to last 2000 entries
    if (count($logs) > 2000){
        $logs = array_slice($logs, -2000);
    }
    update_option('wpai_vision_logs', $logs, false);
}

function wpai_logs_get(){
    return get_option('wpai_vision_logs', []);
}
function wpai_logs_clear(){
    update_option('wpai_vision_logs', [], false);
}
