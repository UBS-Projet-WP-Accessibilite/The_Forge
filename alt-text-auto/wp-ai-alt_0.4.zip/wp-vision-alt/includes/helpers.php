<?php
if (!defined('ABSPATH')) { exit; }

function wpai_settings(){
    $s = get_option('wpai_vision_settings', []);
    return wp_parse_args($s, [
        'base_url'        => 'http://localhost:11434',
        'model'           => 'moondream:latest',
        'use_ollama'      => 1,
        'use_gemini'      => 0,
        'gemini_api_key'  => '',
        'detail_level'    => 'full',
        'temperature'     => 0.2,
        'max_chars'       => 160,
        'language'        => 'fr',
        'use_context'     => ['filename'=>1,'title'=>1,'taxonomies'=>1,'seo'=>0],
        'daily_quota'     => 500,
        'debug'           => 1,
    ]);
}

function wpai_update_settings($arr){
    $s = wpai_settings();
    $s = array_replace_recursive($s, $arr);
    update_option('wpai_vision_settings', $s, false);
}

function wpai_quota_check_and_inc($count = 1){
    $q = get_option('wpai_vision_quota', ['date'=>date('Y-m-d'),'used'=>0]);
    $today = date('Y-m-d');
    if ($q['date'] !== $today){
        $q = ['date'=>$today, 'used'=>0];
    }
    $settings = wpai_settings();
    $limit = intval($settings['daily_quota']);
    if ($limit > 0 && ($q['used'] + $count) > $limit){
        return new WP_Error('quota_exceeded', 'Quota quotidien atteint.');
    }
    $q['used'] += $count;
    update_option('wpai_vision_quota', $q, false);
    return $q;
}

function wpai_trim_chars($text, $max){
    $text = trim(preg_replace('/\s+/', ' ', $text));
    if ($max <= 0 || mb_strlen($text) <= $max) return $text;
    $cut = mb_substr($text, 0, $max);
    // cut on last space
    $sp = mb_strrpos($cut, ' ');
    if ($sp !== false && $sp > 20){
        $cut = mb_substr($cut, 0, $sp);
    }
    return rtrim($cut, ' ,;.:!-').'…';
}

function wpai_prompt_template($level, $lang='fr', $keywords='', $site_context=''){
    switch($level){
        case 'basic':
            return "Décris l’image pour un attribut alt. 1 phrase. Langue: {$lang}. Pas de “image de”.";
        case 'seo':
            $kw = $keywords ? " Inclure un mot-clé pertinent si adapté: {$keywords}." : "";
            $ctx= $site_context ? " Contexte du site: {$site_context}." : "";
            return "Tu es un assistant accessibilité. Décris précisément le sujet, l’action, le décor et les éléments saillants. 1–2 phrases (140–160 caractères). Langue: {$lang}. Évite “photo”/“image”.{$kw}{$ctx}";
        case 'full':
        default:
            return "Tu es un assistant accessibilité. Décris précisément le sujet, l’action, le décor, les éléments saillants, couleurs et nombre d’objets. 1–2 phrases. Langue: {$lang}. Évite “photo”/“image”.";
    }
}

function wpai_gather_context($att_id){
    $ctx = [];
    $file = get_post_meta($att_id, '_wp_attached_file', true);
    if ($file) $ctx[] = 'fichier: '.wp_basename($file);

    $post = get_post($att_id);
    if ($post){
        $title = get_the_title($att_id);
        if ($title) $ctx[] = 'titre média: '.$title;
        // Parents (posts where used) are not trivial; we add tax of attachment if any
        $taxes = get_object_taxonomies('attachment', 'names');
        foreach($taxes as $tx){
            $terms = wp_get_object_terms($att_id, $tx, ['fields'=>'names']);
            if (!is_wp_error($terms) && $terms){
                $ctx[] = $tx.': '.implode(', ', $terms);
            }
        }
    }
    // SEO plugins hints
    if (function_exists('rank_math')){
        $ctx[] = 'SEO: RankMath actif';
    } elseif (defined('WPSEO_VERSION')) {
        $ctx[] = 'SEO: Yoast actif';
    }
    return implode(' | ', $ctx);
}
