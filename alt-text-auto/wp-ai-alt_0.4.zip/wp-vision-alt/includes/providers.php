<?php
if (!defined('ABSPATH')) { exit; }

function wpai_provider_ollama_generate($att_id){
    $s = wpai_settings();
    $quota = wpai_quota_check_and_inc(1);
    if (is_wp_error($quota)) return $quota;

    $bytes = wpai_bytes_for_model($att_id);
    if (is_wp_error($bytes)){
        wpai_log('Erreur: encodage base64 impossible');
        return $bytes;
    }
    $b64 = base64_encode($bytes);
    $mime = get_post_mime_type($att_id);
    $lang = $s['language'];
    $keywords = ''; // TODO: read from SEO plugin if present
    $ctx = '';
    if (!empty($s['use_context'])){
        $ctx = wpai_gather_context($att_id);
    }
    $level = $s['detail_level'];
    $prompt = wpai_prompt_template($level, $lang, $keywords, $ctx);

    $body = [
        'model'   => $s['model'],
        'prompt'  => $prompt,
        'images'  => [$b64],
        'stream'  => false,
        'options' => [
            'temperature' => floatval($s['temperature']),
            'num_predict' => $level === 'seo' ? 160 : ($level === 'basic' ? 64 : 96),
            'top_p'       => 0.9
        ]
    ];
    $url = rtrim($s['base_url'],'/').'/api/generate';
    wpai_log('Ollama payload prêt (base64)', ['url'=>$url, 'model'=>$s['model']]);

    $res = wp_remote_post($url, [
        'timeout'=> 120,
        'headers'=> ['Content-Type'=>'application/json'],
        'body'   => wp_json_encode($body),
    ]);
    if (is_wp_error($res)){
        wpai_log('Erreur HTTP', ['code'=>$res->get_error_code(),'msg'=>$res->get_error_message()]);
        return $res;
    }
    $code = wp_remote_retrieve_response_code($res);
    $raw  = wp_remote_retrieve_body($res);
    if ($code !== 200){
        wpai_log("Erreur HTTP $code", ['body'=>$raw]);
        return new WP_Error('http_'.$code, $raw);
    }
    $data = json_decode($raw, true);
    $text = is_array($data) && isset($data['response']) ? trim($data['response']) : '';
    if (!$text){
        wpai_log('Réponse vide', ['raw'=>$raw]);
        return new WP_Error('empty_response', 'Réponse vide du modèle.');
    }
    $text = wpai_trim_chars($text, intval($s['max_chars']));
    return $text;
}

function wpai_provider_gemini_generate($att_id){
    $s = wpai_settings();
    $quota = wpai_quota_check_and_inc(1);
    if (is_wp_error($quota)) return $quota;

    $api_key = trim($s['gemini_api_key']);
    if (!$api_key){
        return new WP_Error('no_gemini_key', 'Clé API Gemini manquante.');
    }
    $bytes = wpai_bytes_for_model($att_id);
    if (is_wp_error($bytes)) return $bytes;
    $b64 = base64_encode($bytes);
    $mime = get_post_mime_type($att_id);
    $lang = $s['language'];
    $keywords = '';
    $ctx = '';
    if (!empty($s['use_context'])){
        $ctx = wpai_gather_context($att_id);
    }
    $level = $s['detail_level'];
    $prompt = wpai_prompt_template($level, $lang, $keywords, $ctx);

    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key='.rawurlencode($api_key);
    $payload = [
        'generationConfig'=> [
            'temperature' => floatval($s['temperature']),
            'topP'        => 0.9,
            'maxOutputTokens' => $level === 'seo' ? 160 : ($level === 'basic' ? 64 : 96),
        ],
        'contents'=>[
            [
                'role'=>'user',
                'parts'=>[
                    ['text'=>$prompt],
                    ['inline_data'=>['mime_type'=>$mime ?: 'image/jpeg','data'=>$b64]]
                ]
            ]
        ]
    ];
    wpai_log('Gemini payload prêt (base64)');

    $res = wp_remote_post($url, [
        'timeout'=> 120,
        'headers'=> ['Content-Type'=>'application/json'],
        'body'   => wp_json_encode($payload),
    ]);
    if (is_wp_error($res)) return $res;
    $code = wp_remote_retrieve_response_code($res);
    $raw  = wp_remote_retrieve_body($res);
    if ($code !== 200){
        wpai_log("Erreur HTTP $code", ['body'=>$raw]);
        return new WP_Error('http_'.$code, $raw);
    }
    $data = json_decode($raw, true);
    $text = '';
    if (isset($data['candidates'][0]['content']['parts'][0]['text'])){
        $text = trim($data['candidates'][0]['content']['parts'][0]['text']);
    }
    if (!$text){
        wpai_log('Réponse vide Gemini', ['raw'=>$raw]);
        return new WP_Error('empty_response', 'Réponse vide du modèle.');
    }
    $text = wpai_trim_chars($text, intval($s['max_chars']));
    return $text;
}
