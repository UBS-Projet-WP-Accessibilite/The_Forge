<?php
if (!defined('ABSPATH')) { exit; }

add_action('wp_ajax_wpai_detect_models', function(){
    check_ajax_referer('wpai_nonce', 'nonce');
    $s = wpai_settings();
    $url = rtrim($s['base_url'],'/').'/api/tags';
    $ver = rtrim($s['base_url'],'/').'/api/version';
    $models = [];
    $version = null;

    $r1 = wp_remote_get($ver, ['timeout'=>10]);
    if (!is_wp_error($r1) && wp_remote_retrieve_response_code($r1)==200){
        $j = json_decode(wp_remote_retrieve_body($r1), true);
        if (isset($j['version'])) $version = $j['version'];
    }

    $r = wp_remote_get($url, ['timeout'=>10]);
    if (!is_wp_error($r) && wp_remote_retrieve_response_code($r)==200){
        $j = json_decode(wp_remote_retrieve_body($r), true);
        if (is_array($j) && isset($j['models'])){
            foreach($j['models'] as $m){ if (!empty($m['name'])) $models[] = $m['name']; }
        } elseif (is_array($j)){
            foreach($j as $m){ if (is_array($m) && !empty($m['name'])) $models[] = $m['name']; }
        }
    }

    wp_send_json_success(['version'=>$version, 'models'=>$models]);
});

add_action('wp_ajax_wpai_test_connection', function(){
    check_ajax_referer('wpai_nonce', 'nonce');
    $base = isset($_POST['base']) ? sanitize_text_field(wp_unslash($_POST['base'])) : '';
    if (!$base) { $base = wpai_settings()['base_url']; }
    $ver = rtrim($base,'/').'/api/version';
    $r = wp_remote_get($ver, ['timeout'=>10]);
    if (is_wp_error($r)){
        wp_send_json_error(['error'=>$r->get_error_message()]);
    }
    $code = wp_remote_retrieve_response_code($r);
    $body = wp_remote_retrieve_body($r);
    if ($code !== 200){
        wp_send_json_error(['error'=>"HTTP $code: $body"]);
    }
    $j = json_decode($body, true);
    wp_send_json_success(['ok'=>true, 'version'=> isset($j['version'])?$j['version']:null ]);
});

add_action('wp_ajax_wpai_save_settings', function(){
    check_ajax_referer('wpai_nonce', 'nonce');
    $payload = isset($_POST['settings']) ? (array) json_decode(stripslashes($_POST['settings']), true) : [];
    wpai_update_settings($payload);
    wp_send_json_success(['saved'=>true]);
});

add_action('wp_ajax_wpai_scan_images', function(){
    check_ajax_referer('wpai_nonce', 'nonce');
    $ids = wpai_scan_images_without_alt(500);
    wpai_log('Scan', ['count'=>count($ids)]);
    wp_send_json_success(['ids'=>$ids, 'count'=>count($ids)]);
});

add_action('wp_ajax_wpai_generate_alt', function(){
    check_ajax_referer('wpai_nonce', 'nonce');
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if (!$id) wp_send_json_error(['error'=>'Missing ID']);
    $s = wpai_settings();
    wpai_log('Génération demandée', ['id'=>$id, 'url'=>wp_get_attachment_url($id)]);

    $text = null;
    if (!empty($s['use_gemini'])){
        $text = wpai_provider_gemini_generate($id);
        if (is_wp_error($text)){
            // fallback Ollama si activé
            if (!empty($s['use_ollama'])){
                $text2 = wpai_provider_ollama_generate($id);
                if (!is_wp_error($text2)) $text = $text2;
            }
        }
    } else {
        $text = wpai_provider_ollama_generate($id);
    }

    if (is_wp_error($text)){
        wp_send_json_error(['error'=>$text->get_error_message()]);
    }
    update_post_meta($id, '_wp_attachment_image_alt', sanitize_text_field($text));
    wpai_log('OK: ALT enregistré', ['id'=>$id]);
    wp_send_json_success(['alt'=>$text]);
});

add_action('wp_ajax_wpai_get_logs', function(){
    check_ajax_referer('wpai_nonce', 'nonce');
    $logs = wpai_logs_get();
    wp_send_json_success(['logs'=>$logs]);
});
add_action('wp_ajax_wpai_clear_logs', function(){
    check_ajax_referer('wpai_nonce', 'nonce');
    wpai_logs_clear();
    wp_send_json_success(['cleared'=>true]);
});

add_action('wp_ajax_wpai_test_file_read', function(){
    check_ajax_referer('wpai_nonce', 'nonce');
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if (!$id) wp_send_json_error(['error'=>'Missing ID']);
    $r = wpai_get_image_bytes($id);
    if (is_wp_error($r)){
        wp_send_json_error(['ok'=>false, 'error'=>$r->get_error_message()]);
    } else {
        wp_send_json_success(['ok'=>true, 'size'=>strlen($r)]);
    }
});
