<?php
if (!defined('ABSPATH')) { exit; }

function wpai_get_image_bytes($att_id){
    // 1. chemin original si dispo
    if (function_exists('wp_get_original_image_path')){
        $p = wp_get_original_image_path($att_id);
        if ($p && is_readable($p)) { wpai_log('Lecture original', ['path'=>$p]); return file_get_contents($p); }
    }
    // 2. chemin actuel
    $p = get_attached_file($att_id);
    if ($p && is_readable($p)) { wpai_log('Lecture attached_file', ['path'=>$p]); return file_get_contents($p); }

    // 3. reconstituer via meta
    $rel = get_post_meta($att_id, '_wp_attached_file', true);
    if ($rel){
        $up = wp_get_upload_dir();
        $p = trailingslashit($up['basedir']).$rel;
        if ($p && is_readable($p)) { wpai_log('Lecture via meta', ['path'=>$p]); return file_get_contents($p); }
    }

    // 4. télécharger l'URL
    $url = wp_get_attachment_url($att_id);
    if ($url){
        require_once ABSPATH.'wp-admin/includes/file.php';
        $tmp = download_url($url, 30);
        if (!is_wp_error($tmp) && is_readable($tmp)){
            $bytes = file_get_contents($tmp);
            @unlink($tmp);
            wpai_log('Lecture via download_url', ['url'=>$url]);
            return $bytes;
        }
        wpai_log('Echec download_url', ['err'=>is_wp_error($tmp)?$tmp->get_error_message():'']);
    }
    return new WP_Error('wpai_read_fail', 'Lecture image impossible');
}

function wpai_bytes_for_model($att_id, $max_w=1024){
    $bytes = wpai_get_image_bytes($att_id);
    if (is_wp_error($bytes)) return $bytes;

    $ext = pathinfo(get_attached_file($att_id), PATHINFO_EXTENSION);
    if (!$ext) $ext = 'jpg';
    $tmp = wp_tempnam('wpai_'.$att_id.'.'.$ext);
    file_put_contents($tmp, $bytes);

    $ed = wp_get_image_editor($tmp);
    if (!is_wp_error($ed)){
        $size = $ed->get_size();
        if (!empty($size['width']) && $size['width'] > $max_w){
            $ed->resize($max_w, null);
            $ed->save($tmp);
            wpai_log('Redimensionné', ['w'=>$max_w]);
        }
    }
    $out = file_get_contents($tmp);
    @unlink($tmp);
    return $out;
}

function wpai_scan_images_without_alt($limit = 200){
    $mimes = ['image/jpeg','image/png','image/gif','image/webp','image/bmp','image/tiff'];
    $q = new WP_Query([
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'posts_per_page' => $limit,
        'post_mime_type' => $mimes,
        'meta_query'     => [
            'relation' => 'OR',
            ['key'=>'_wp_attachment_image_alt','compare'=>'NOT EXISTS'],
            ['key'=>'_wp_attachment_image_alt','value'=>'','compare'=>'='],
        ],
        'orderby'        => 'date',
        'order'          => 'DESC',
        'fields'         => 'ids',
    ]);
    return $q->posts;
}
