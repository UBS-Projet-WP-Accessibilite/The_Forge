<?php
/**
 * Plugin Name: Vision ALT — Générateur d’attributs ALT (Ollama + Gemini)
 * Description: Génère automatiquement des textes alternatifs (alt) pour vos images avec Ollama (LLaVA, Moondream) ou Gemini Vision. Aide intégrée, réglages, traitement de masse, journal détaillé.
 * Version: 0.9.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: ChatGPT
 * Text Domain: wpai-vision
 */

if (!defined('ABSPATH')) { exit; }

define('WPAI_VISION_VER', '0.9.0');
define('WPAI_VISION_SLUG', 'wpai-vision');
define('WPAI_VISION_DIR', plugin_dir_path(__FILE__));
define('WPAI_VISION_URL', plugin_dir_url(__FILE__));

require_once WPAI_VISION_DIR . 'includes/log.php';
require_once WPAI_VISION_DIR . 'includes/helpers.php';
require_once WPAI_VISION_DIR . 'includes/media.php';
require_once WPAI_VISION_DIR . 'includes/providers.php';
require_once WPAI_VISION_DIR . 'includes/ajax.php';
require_once WPAI_VISION_DIR . 'admin/admin-pages.php';

/**
 * Activation: initialise options.
 */
register_activation_hook(__FILE__, function(){
    $defaults = [
        'base_url'        => 'http://localhost:11434',
        'model'           => 'moondream:latest',
        'use_ollama'      => 1,
        'use_gemini'      => 0,
        'gemini_api_key'  => '',
        'detail_level'    => 'full',
        'temperature'     => 0.2,
        'max_chars'       => 160,
        'language'        => 'fr',
        'use_context'     => ['filename'=>1,'title'=>1,'taxonomies'=>1,'seo'=>0],
        'daily_quota'     => 500,
        'debug'           => 1,
    ];
    add_option('wpai_vision_settings', $defaults, '', false);
    add_option('wpai_vision_quota', ['date'=>date('Y-m-d'),'used'=>0], '', false);
    add_option('wpai_vision_logs', [], '', false);
});
