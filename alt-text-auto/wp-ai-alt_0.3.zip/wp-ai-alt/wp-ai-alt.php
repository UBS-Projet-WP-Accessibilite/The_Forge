<?php
/**
 * Plugin Name: WP AI Alt
 * Description: Génère des textes alternatifs via Ollama ou Gemini Vision. Inclut outils, réglages et aide.
 * Version: 1.1.0
 * Author: ChatGPT
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) { exit; }

require_once __DIR__ . '/includes/class-wp-ai-alt.php';

function wp_ai_alt() {
    static $instance = null;
    if ($instance === null) {
        $instance = new WP_AI_Alt();
    }
    return $instance;
}
add_action('plugins_loaded', 'wp_ai_alt');
