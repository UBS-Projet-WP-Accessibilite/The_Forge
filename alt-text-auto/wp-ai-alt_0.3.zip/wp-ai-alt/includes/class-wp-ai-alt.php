<?php
if (!defined('ABSPATH')) { exit; }

class WP_AI_Alt {
    const OPT = 'wp_ai_alt_settings';
    const LOG_OPTION = 'wp_ai_alt_log_';
    public function __construct() {
        add_action('admin_menu', [$this,'menu']);
        add_action('admin_enqueue_scripts', [$this,'assets']);
        add_action('wp_ajax_wp_ai_alt_test', [$this,'ajax_test']);
        add_action('wp_ajax_wp_ai_alt_detect', [$this,'ajax_detect']);
        add_action('wp_ajax_wp_ai_alt_scan', [$this,'ajax_scan']);
        add_action('wp_ajax_wp_ai_alt_generate', [$this,'ajax_generate']);
        add_action('wp_ajax_wp_ai_alt_logs', [$this,'ajax_logs']);
    }

    private function get_settings() {
        $defaults = [
            'engine' => 'ollama', // ollama|gemini
            'base'   => 'http://localhost:11434',
            'model'  => 'moondream:latest',
            'gemini_key' => '',
            'resize' => 1024,
            'debug'  => true,
            'quota'  => ['limit' => 0, 'used' => 0],
        ];
        return wp_parse_args(get_option(self::OPT, []), $defaults);
    }

    public function assets($hook) {
        if (strpos($hook, 'wp-ai-alt') === false) return;
        wp_enqueue_style('wp-ai-alt-admin', plugins_url('../assets/css/admin.css', __FILE__), [], '1.1.0');
        wp_enqueue_script('wp-ai-alt-admin', plugins_url('../assets/js/admin.js', __FILE__), ['jquery'], '1.1.0', true);
        wp_localize_script('wp-ai-alt-admin','WPAIALT',[
            'ajax' => admin_url('admin-ajax.php'),
            'nonce'=> wp_create_nonce('wp_ai_alt_nonce'),
        ]);
    }

    public function menu() {
        $cap = 'upload_files';
        $slug_tools = 'wp-ai-alt';
        add_menu_page('WP AI Alt — Outils','WP AI Alt',$cap,$slug_tools,[$this,'page_tools'],'dashicons-visibility',62);
        add_submenu_page($slug_tools,'Outils','Outils',$cap,$slug_tools,[$this,'page_tools']);
        add_submenu_page($slug_tools,'Réglages','Réglages',$cap,'wp-ai-alt-settings',[$this,'page_settings']);
        add_submenu_page($slug_tools,'Aide','Aide',$cap,'wp-ai-alt-help',[$this,'page_help']);
    }

    private function log_id() {
        return get_current_user_id() ?: 'guest';
    }
    private function log_key() {
        return self::LOG_OPTION . $this->log_id();
    }
    private function log($msg) {
        $s = $this->get_settings();
        if (!$s['debug']) return;
        $key = $this->log_key();
        $logs = get_option($key, []);
        $logs[] = '['. current_time('H:i:s') .'] '. $msg;
        update_option($key, $logs, false);
    }
    private function clear_logs() { delete_option($this->log_key()); }
    public function ajax_logs() {
        check_ajax_referer('wp_ai_alt_nonce');
        $logs = get_option($this->log_key(), []);
        wp_send_json(['logs'=>$logs]);
    }

    /*** Pages ***/
    public function page_tools() {
        $s = $this->get_settings();
        ?>
        <div class="wrap wp-ai-alt-wrap">
          <h1>WP AI Alt — Outils</h1>
          <p>Générez en masse les ALT pour les images sans texte alternatif.</p>
          <div class="wp-ai-alt-grid">
            <div class="card">
              <h2>1) Scanner</h2>
              <p>Recherche des images sans ALT dans la Médiathèque.</p>
              <button class="button button-primary" id="wpai-scan">Scanner</button>
              <div id="wpai-scan-result" class="muted"></div>
            </div>
            <div class="card">
              <h2>2) Générer</h2>
              <p>Crée les ALT avec le moteur sélectionné.</p>
              <button class="button button-primary" id="wpai-generate" disabled>Générer pour toutes</button>
              <div id="wpai-generate-progress" class="muted"></div>
            </div>
            <div class="card">
              <h2>Journal (debug)</h2>
              <p>Affiche chaque étape: connexion API, images traitées, erreurs.</p>
              <div id="wpai-log" class="log"></div>
              <button class="button" id="wpai-log-refresh">Rafraîchir</button>
            </div>
          </div>
        </div>
        <?php
    }

    public function page_settings() {
        $s = $this->get_settings();
        ?>
        <div class="wrap wp-ai-alt-wrap">
          <h1>WP AI Alt — Réglages</h1>
          <div class="wp-ai-alt-grid">
            <div class="card">
              <h2>Moteur</h2>
              <table class="form-table">
                <tr><th>Choix</th><td>
                  <label><input type="radio" name="engine" value="ollama" <?php checked($s['engine'],'ollama'); ?>> Ollama (local)</label><br>
                  <label><input type="radio" name="engine" value="gemini" <?php checked($s['engine'],'gemini'); ?>> Gemini Vision (hébergé)</label>
                </td></tr>
              </table>
            </div>
            <div class="card">
              <h2>Ollama (local)</h2>
              <table class="form-table">
                <tr><th>URL de base</th><td>
                    <input type="text" id="base" value="<?php echo esc_attr($s['base']);?>" class="regular-text" placeholder="http://localhost:11434">
                    <button class="button" id="probe">Détecter automatiquement</button>
                </td></tr>
                <tr><th>Modèle</th><td>
                    <input type="text" id="model" value="<?php echo esc_attr($s['model']);?>" class="regular-text" placeholder="moondream:latest">
                    <button class="button" id="detect">Lister modèles</button>
                    <div id="models" class="muted"></div>
                </td></tr>
                <tr><th>Test</th><td>
                    <button class="button" id="test-ollama">Tester connexion</button>
                    <div id="test-result" class="muted"></div>
                </td></tr>
              </table>
              <details class="muted"><summary>LocalWP</summary>
                <p>Si WordPress tourne dans un conteneur, <code>localhost</code> peut être différent. Cliquez “Détecter automatiquement”. Le plugin essaie successivement:
                <code>http://localhost:11434</code>, <code>http://127.0.0.1:11434</code>, <code>http://host.docker.internal:11434</code>, <code>http://gateway.docker.internal:11434</code>. Utilisez la première adresse qui répond.</p>
              </details>
            </div>
            <div class="card">
              <h2>Gemini Vision</h2>
              <table class="form-table">
                <tr><th>API key</th><td><input type="password" id="gemini_key" value="<?php echo esc_attr($s['gemini_key']);?>" class="regular-text" placeholder="AI..."></td></tr>
                <tr><th>Test</th><td><button class="button" id="test-gemini">Tester clé</button> <span id="test-gemini-result" class="muted"></span></td></tr>
              </table>
            </div>
            <div class="card">
              <h2>Qualité et limites</h2>
              <table class="form-table">
                <tr><th>Redimensionner avant envoi</th><td><input type="number" id="resize" value="<?php echo intval($s['resize']);?>" min="256" max="2048"> px (largeur max)</td></tr>
                <tr><th>Debug</th><td><label><input type="checkbox" id="debug" <?php checked($s['debug']);?>> Activer les logs</label></td></tr>
              </table>
              <button class="button button-primary" id="save">Enregistrer</button>
              <span id="save-result" class="muted"></span>
            </div>
          </div>
        </div>
        <?php
    }

    public function page_help() {
        ?>
        <div class="wrap wp-ai-alt-wrap">
          <h1>WP AI Alt — Aide</h1>
          <div class="help-grid">
            <div class="help-card">
              <h2>0) Objectif</h2>
              <p>Générer automatiquement des textes alternatifs utiles pour l’accessibilité et le SEO.</p>
            </div>
            <div class="help-card">
              <h2>1) Prérequis</h2>
              <ul>
                <li>WordPress 6.x et PHP 8+</li>
                <li>Un moteur: <strong>Ollama</strong> local ou <strong>Gemini Vision</strong> hébergé.</li>
              </ul>
            </div>
            <div class="help-card">
              <h2>2) Installation rapide</h2>
              <p><strong>Ollama</strong>: installez, puis lancez <code>ollama run moondream</code>. Vérifiez: <code>http://localhost:11434/api/version</code>. 
                 <strong>LocalWP</strong>: si échec, utilisez le bouton “Détecter automatiquement”.</p>
              <p><strong>Gemini</strong>: créez une clé API Google AI Studio. Collez-la dans Réglages.</p>
            </div>
            <div class="help-card">
              <h2>3) Utilisation</h2>
              <ol>
                <li>Ouvrez <em>WP AI Alt → Outils</em>.</li>
                <li>Scannez. Vérifiez la liste d’images détectées.</li>
                <li>Lancez la génération en masse. Suivez le journal.</li>
              </ol>
            </div>
            <div class="help-card">
              <h2>4) Ergonomie, idées à intégrer</h2>
              <ul>
                <li>Prévisualisation d’un ALT avant validation.</li>
                <li>Règles de style: langue, longueur, ton.</li>
                <li>Retenter automatiquement en cas d’échec réseau.</li>
              </ul>
            </div>
            <div class="help-card">
              <h2>5) Dépannage</h2>
              <ul>
                <li><em>illegal base64 data</em>: l’image n’a pas été encodée. Mettez à jour le plugin. Le moteur exige du base64.</li>
                <li>Détection modèle vide: vérifiez <em>/api/tags</em> sur l’URL Ollama.</li>
              </ul>
            </div>
          </div>
        </div>
        <?php
    }

    /*** AJAX ***/
    private function read_json() {
        $body = file_get_contents('php://input');
        $data = json_decode($body,true);
        return is_array($data) ? $data : [];
    }

    public function ajax_test() {
        check_ajax_referer('wp_ai_alt_nonce');
        $data = $this->read_json();
        $what = $data['what'] ?? 'ollama';
        $s = $this->get_settings();
        if ($what==='gemini') {
            $ok = $this->gemini_health($s['gemini_key']);
            wp_send_json($ok);
        } else {
            $ok = $this->ollama_health($data['base'] ?? $s['base']);
            wp_send_json($ok);
        }
    }

    public function ajax_detect() {
        check_ajax_referer('wp_ai_alt_nonce');
        $data = $this->read_json();
        $candidates = $data['probe'] ?? [
            'http://localhost:11434',
            'http://127.0.0.1:11434',
            'http://host.docker.internal:11434',
            'http://gateway.docker.internal:11434'
        ];
        $found = null; $models = [];
        foreach ($candidates as $base) {
            $h = $this->ollama_health($base);
            if (!empty($h['ok'])) { $found = $base;
                $models = $this->ollama_models($base);
                break;
            }
        }
        if ($found) {
            $s = $this->get_settings(); $s['base']=$found; update_option(self::OPT,$s);
            wp_send_json(['ok'=>true,'base'=>$found,'models'=>$models]);
        }
        wp_send_json(['ok'=>false]);
    }

    public function ajax_scan() {
        check_ajax_referer('wp_ai_alt_nonce');
        $args = [
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1,
            'post_mime_type' => 'image',
            'meta_query' => [
                'relation' => 'OR',
                [
                    'key' => '_wp_attachment_image_alt',
                    'compare' => 'NOT EXISTS'
                ],
                [
                    'key' => '_wp_attachment_image_alt',
                    'value' => '',
                    'compare' => '='
                ]
            ]
        ];
        $q = new WP_Query($args);
        $ids = wp_list_pluck($q->posts,'ID');
        $this->clear_logs();
        $this->log('Scan: '. count($ids) .' images sans ALT potentielles.');
        wp_send_json(['count'=>count($ids),'ids'=>$ids]);
    }

    public function ajax_generate() {
        check_ajax_referer('wp_ai_alt_nonce');
        $data = $this->read_json();
        $ids = array_map('intval', $data['ids'] ?? []);
        if (!$ids) wp_send_json_error('no ids');
        $s = $this->get_settings();
        $ok=0; $ko=0; $results=[];
        foreach ($ids as $id) {
            $r = $this->generate_for_attachment($id, $s);
            $results[] = $r;
            if (!empty($r['ok'])) $ok++; else $ko++;
        }
        wp_send_json(['ok'=>$ok,'ko'=>$ko,'results'=>$results]);
    }

    /*** Engine calls ***/
    private function image_to_base64($attachment_id, $maxw) {
        $path = get_attached_file($attachment_id);
        if (!file_exists($path)) {
            $this->log("Image introuvable: ID $attachment_id");
            return null;
        }
        // Resize to max width
        $editor = wp_get_image_editor($path);
        if (!is_wp_error($editor)) {
            $size = $editor->get_size();
            if ($size['width'] > $maxw) {
                $editor->resize($maxw, null);
                $tmp = wp_tempnam(basename($path));
                $editor->save($tmp);
                $path = $tmp;
            }
        }
        $data = file_get_contents($path);
        if ($data===false) return null;
        return base64_encode($data);
    }

    private function ollama_health($base) {
        $r = wp_remote_get(rtrim($base,'/').'/api/version',['timeout'=>5]);
        if (is_wp_error($r)) return ['ok'=>false,'error'=>$r->get_error_message()];
        $ver = json_decode(wp_remote_retrieve_body($r),true);
        if (!is_array($ver)) return ['ok'=>false];
        return ['ok'=>true,'version'=>$ver['version'] ?? '?'];
    }
    private function ollama_models($base) {
        $r = wp_remote_get(rtrim($base,'/').'/api/tags',['timeout'=>5]);
        if (is_wp_error($r)) return [];
        $b = json_decode(wp_remote_retrieve_body($r),true);
        if (!is_array($b)) return [];
        $out=[];
        foreach(($b['models'] ?? []) as $m){ if(!empty($m['name'])) $out[]=$m['name']; }
        return $out;
    }

    private function ollama_generate_alt($base, $model, $b64, $lang='fr') {
        $prompt = "Décris l'image en une phrase claire en $lang pour l'attribut ALT. Pas de ponctuation finale excessive. 15 mots maximum.";
        $payload = [
            'model' => $model,
            'prompt'=> $prompt,
            'images'=> [$b64],
            'stream'=> false
        ];
        $r = wp_remote_post(rtrim($base,'/').'/api/generate',[
            'timeout'=>60,
            'headers'=>['Content-Type'=>'application/json'],
            'body'=> wp_json_encode($payload),
        ]);
        if (is_wp_error($r)) return ['ok'=>false,'error'=>$r->get_error_message()];
        $code = wp_remote_retrieve_response_code($r);
        $body = wp_remote_retrieve_body($r);
        if ($code !== 200) return ['ok'=>false,'error'=>"HTTP $code: $body"];
        $j = json_decode($body,true);
        $res = $j['response'] ?? '';
        return ['ok'=> strlen(trim($res))>0, 'alt'=> trim($res), 'raw'=>$j];
    }

    private function gemini_health($key) {
        if (!$key) return ['ok'=>false,'error'=>'clé manquante'];
        // Simple content that should not bill. If 429, quota épuisé.
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:countTokens?key='.rawurlencode($key);
        $payload = ['contents'=>[['parts'=>[['text'=>'healthcheck']]]]];
        $r = wp_remote_post($url,[
            'timeout'=>10,
            'headers'=>['Content-Type'=>'application/json'],
            'body'=> wp_json_encode($payload),
        ]);
        if (is_wp_error($r)) return ['ok'=>false,'error'=>$r->get_error_message()];
        $code = wp_remote_retrieve_response_code($r);
        if ($code==200) return ['ok'=>true,'quota'=>'OK'];
        if ($code==429) return ['ok'=>false,'error'=>'quota dépassé (429)'];
        return ['ok'=>false,'error'=>"HTTP $code"];
    }

    private function gemini_generate_alt($key, $b64, $lang='fr') {
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key='.rawurlencode($key);
        $prompt = "Décris l'image en une phrase claire en $lang pour l'attribut ALT. 15 mots maximum.";
        $payload = [
            'contents'=>[
                ['parts'=>[['text'=>$prompt],['inline_data'=>['mime_type'=>'image/jpeg','data'=>$b64]]]]
            ]
        ];
        $r = wp_remote_post($url,[
            'timeout'=>60,
            'headers'=>['Content-Type'=>'application/json'],
            'body'=> wp_json_encode($payload),
        ]);
        if (is_wp_error($r)) return ['ok'=>false,'error'=>$r->get_error_message()];
        $code = wp_remote_retrieve_response_code($r);
        $body = wp_remote_retrieve_body($r);
        if ($code !== 200) return ['ok'=>false,'error'=>"HTTP $code: $body"];
        $j = json_decode($body,true);
        $txt = $j['candidates'][0]['content']['parts'][0]['text'] ?? '';
        return ['ok'=> strlen(trim($txt))>0, 'alt'=> trim($txt), 'raw'=>$j];
    }

    private function generate_for_attachment($id, $s) {
        $url = wp_get_attachment_url($id);
        $this->log("Génération demandée pour ID $id ($url)");
        $b64 = $this->image_to_base64($id, intval($s['resize']));
        if (!$b64) { $this->log("Erreur: encodage base64 impossible"); return ['id'=>$id,'ok'=>false,'error'=>'base64']; }
        if ($s['engine']==='gemini') {
            $this->log("Gemini: envoi");
            $r = $this->gemini_generate_alt($s['gemini_key'], $b64);
        } else {
            $this->log("Ollama payload prêt (base64)");
            $r = $this->ollama_generate_alt($s['base'], $s['model'], $b64);
        }
        if (!empty($r['ok'])) {
            update_post_meta($id, '_wp_attachment_image_alt', $r['alt']);
            $this->log("OK: ALT enregistré");
            return ['id'=>$id,'ok'=>true,'alt'=>$r['alt']];
        } else {
            $this->log("Erreur: ".$r['error']);
            return ['id'=>$id,'ok'=>false,'error'=>$r['error']];
        }
    }
}
