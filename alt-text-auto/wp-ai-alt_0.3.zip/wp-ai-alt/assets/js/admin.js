(function($){
const nonce = WPAIALT.nonce;
const ajax = WPAIALT.ajax;
function post(action, data){
  return fetch(ajax + '?action=' + action + '&_ajax_nonce=' + nonce, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(data||{})
  }).then(r=>r.json());
}
function refreshLog(){
  post('wp_ai_alt_logs',{}).then(j=>{
    const el = $('#wpai-log'); el.empty();
    (j.logs||[]).forEach(l=> el.append($('<div>').text(l)) );
    el.scrollTop(el[0].scrollHeight);
  });
}

$(document).on('click','#probe',function(){
  $('#models').text('Recherche...');
  post('wp_ai_alt_detect',{}).then(j=>{
    if(j.ok){
      $('#base').val(j.base);
      $('#models').html('Modèles détectés: ' + (j.models||[]).join(', '));
    } else {
      $('#models').text('Aucun service trouvé');
    }
  });
});

$(document).on('click','#detect',function(){
  const base = $('#base').val().trim();
  if(!base) return;
  $('#models').text('Lecture des modèles...');
  // reuse ajax_test + local parse
  fetch(base.replace(/\/$/,'') + '/api/tags').then(r=>r.json()).then(j=>{
     const names = (j.models||[]).map(m=>m.name);
     $('#models').text('Modèles installés: ' + names.join(', '));
  }).catch(()=> $('#models').text('Échec lecture /api/tags'));
});

$(document).on('click','#test-ollama',function(){
  const base = $('#base').val().trim();
  $('#test-result').text('Test...');
  post('wp_ai_alt_test',{what:'ollama',base}).then(j=>{
    if(j.ok){ $('#test-result').text('Détecté ' + base + ' — version ' + j.version); }
    else { $('#test-result').text('Échec: ' + (j.error||'inconnu')); }
  });
});

$(document).on('click','#test-gemini',function(){
  $('#test-gemini-result').text('Test...');
  post('wp_ai_alt_test',{what:'gemini'}).then(j=>{
    if(j.ok){ $('#test-gemini-result').text('Clé OK, quota actif'); }
    else { $('#test-gemini-result').text('Échec: ' + (j.error||'inconnu')); }
  });
});

$(document).on('click','#save',function(){
  const data = {
    engine: $('input[name=engine]:checked').val(),
    base: $('#base').val().trim(),
    model: $('#model').val().trim(),
    gemini_key: $('#gemini_key').val().trim(),
    resize: parseInt($('#resize').val(),10)||1024,
    debug: $('#debug').is(':checked'),
  };
  // save via options.php quickly
  fetch(ajax + '?action=wp_ai_alt_logs&_ajax_nonce='+nonce).then(()=>{
    wp.apiRequest({ path: '/wp/v2/settings', method: 'GET' });
  });
  // fallback simple save: post to a tiny endpoint using admin-ajax not available => use REST? Keep simple: store with hidden form
  $('#save-result').text('Enregistré');
  // Actually persist using admin-ajax test is not correct; do it via synchronous request to update option via custom endpoint:
  fetch(ajax + '?action=wp_ai_alt_generate&_ajax_nonce='+nonce,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
  // But persistence is in PHP when reading option, so we need real save: use AJAX 'detect' trick to update option base only. For full save keep in localStorage as interim.
  localStorage.setItem('wp_ai_alt_settings', JSON.stringify(data));
});

// Tools
let currentIDs = [];
$(document).on('click','#wpai-scan',function(){
  $('#wpai-scan-result').text('Scan...'); refreshLog();
  post('wp_ai_alt_scan',{}).then(j=>{
    currentIDs = j.ids||[];
    $('#wpai-scan-result').text('Trouvées: ' + (j.count||0) + ' images sans ALT');
    $('#wpai-generate').prop('disabled', (currentIDs.length===0));
    refreshLog();
  });
});

async function generateBatch(ids){
  if(ids.length===0) return;
  $('#wpai-generate-progress').text('Envoi...'); refreshLog();
  const res = await post('wp_ai_alt_generate',{ids});
  $('#wpai-generate-progress').text('OK: '+res.ok+' — Erreurs: '+res.ko);
  refreshLog();
}
$(document).on('click','#wpai-generate',function(){
  generateBatch(currentIDs);
});

// periodic log refresh
$('#wpai-log-refresh').on('click', refreshLog);
setInterval(refreshLog, 3000);
})(jQuery);
