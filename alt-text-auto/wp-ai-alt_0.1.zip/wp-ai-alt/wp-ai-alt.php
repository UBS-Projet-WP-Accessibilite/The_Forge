<?php
/**
 * Plugin Name: WP AI Alt
 * Description: Génération d'attributs ALT pour les images via Ollama (local) ou un provider Vision hébergé. Inclut pages Réglages, Outils et Aide.
 * Version: 1.1.0
 * Author: ChatGPT
 * License: GPLv2 or later
 */
if (!defined('ABSPATH')) { exit; }
define('WPAIALT_VERSION', '1.1.0');
define('WPAIALT_SLUG', 'wp-ai-alt');
define('WPAIALT_DIR', plugin_dir_path(__FILE__));
define('WPAIALT_URL', plugin_dir_url(__FILE__));
require_once WPAIALT_DIR . 'includes/class-wpai-alt.php';
require_once WPAIALT_DIR . 'includes/class-wpai-alt-generator.php';
require_once WPAIALT_DIR . 'includes/class-wpai-alt-admin.php';
add_action('plugins_loaded', function() { \WPAIAlt\Plugin::instance(); });
