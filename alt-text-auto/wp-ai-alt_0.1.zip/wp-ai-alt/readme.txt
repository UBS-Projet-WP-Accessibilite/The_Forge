=== WP AI Alt ===
Contributors: chatgpt
Tags: alt text, accessibility, images, ai, ollama, openai, vision
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 8.0
Stable tag: 1.1.0
License: GPLv2 or later

Generate image ALT attributes using locally hosted Ollama vision models or a hosted OpenAI-compatible Vision API. Includes settings, tools, and a help page. The top-level admin menu uses the eye icon and opens Settings.
