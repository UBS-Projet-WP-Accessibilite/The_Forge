jQuery(function($){
  $(document).on('click', '.wpai-alt-generate, .wpai-alt-row', function(e){
    e.preventDefault();
    const id = $(this).data('id');
    const $btn = $(this);
    $btn.prop('disabled', true).text('Génération...');
    $.post(WPAIALT.ajax, {action:'wpai_alt_generate', attachment_id:id, nonce:WPAIALT.nonce}, function(r){
      if(r.success){
        $btn.text('ALT ajouté');
        const alt = r.data.alt || '';
        $('input[name="attachments['+id+'][image_alt]"]').val(alt);
        alert('ALT généré: ' + alt);
      } else {
        alert('Erreur: ' + (r.data && r.data.message ? r.data.message : 'inconnue'));
        $btn.prop('disabled', false).text('Générer alt');
      }
    });
  });
  $('#wpai-test-ollama').on('click', function(){
    const base = $('#ollama_url').val();
    const $out = $('#wpai-ollama-test-out').empty();
    $out.text('Test en cours...');
    $.post(WPAIALT.ajax, {action:'wpai_alt_test_ollama', base:base, nonce:WPAIALT.nonce}, function(r){
      if(r.success){
        const v = r.data.version || '(version inconnue)';
        $out.html('<span class="wpai-badge">OK</span> Version: '+v+'<br>Modèles: '+ (r.data.models || []).join(', '));
      } else {
        $out.html('<span class="wpai-badge">Erreur</span> ' + (r.data && r.data.message ? r.data.message : ''));
      }
    });
  });
  $('#wpai-detect-ollama').on('click', function(){
    const $out = $('#wpai-ollama-test-out').empty();
    $out.text('Détection...');
    $.post(WPAIALT.ajax, {action:'wpai_alt_detect_ollama', nonce:WPAIALT.nonce}, function(r){
      if(r.success){
        if(r.data.candidates && r.data.candidates.length){
          const c = r.data.candidates[0];
          $('#ollama_url').val(c.base);
          $out.html('<span class="wpai-badge">Détecté</span> '+c.base+' — version '+(c.version||'')+'<br>Modèles: '+(c.models||[]).join(', '));
        } else {
          $out.html('<span class="wpai-badge">Aucun Ollama détecté</span>');
        }
      } else {
        $out.html('<span class="wpai-badge">Erreur</span>');
      }
    });
  });
  $('#wpai-test-openai').on('click', function(){
    const endpoint = $('#openai_endpoint').val();
    const key = $('#openai_api_key').val();
    const model = $('#openai_model').val();
    const $out = $('#wpai-openai-test-out').empty();
    $out.text('Test en cours...');
    $.post(WPAIALT.ajax, {action:'wpai_alt_test_openai', endpoint:endpoint, key:key, model:model, nonce:WPAIALT.nonce}, function(r){
      if(r.success){
        $out.html('<span class="wpai-badge">OK</span> Connexion API valide');
      } else {
        $out.html('<span class="wpai-badge">Erreur</span> ' + (r.data && r.data.message ? r.data.message : ''));
      }
    });
  });
});