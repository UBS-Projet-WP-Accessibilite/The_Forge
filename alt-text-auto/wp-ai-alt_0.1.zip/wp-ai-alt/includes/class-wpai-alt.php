<?php
namespace WPAIAlt;
if (!defined('ABSPATH')) { exit; }
final class Plugin {
    private static $instance = null;
    public $generator;
    public static function instance() {
        if (self::$instance === null) { self::$instance = new self(); }
        return self::$instance;
    }
    private function __construct() {
        $this->generator = new Generator();
        new Admin($this->generator);
        add_filter('media_row_actions', [$this, 'row_action_generate'], 10, 2);
        add_filter('attachment_fields_to_edit', [$this, 'attachment_meta_button'], 10, 2);
        add_action('add_meta_boxes_attachment', [$this, 'add_sidebox']);
    }
    public function row_action_generate($actions, $post) {
        if ($post->post_type === 'attachment' && strpos($post->post_mime_type, 'image/') === 0) {
            $actions['wpai_alt'] = '<a href="#" class="wpai-alt-row" data-id="' . esc_attr($post->ID) . '">' . esc_html__('Générer alt (WP AI Alt)', 'wp-ai-alt') . '</a>';
        }
        return $actions;
    }
    public function attachment_meta_button($form_fields, $post) {
        if (strpos($post->post_mime_type, 'image/') !== 0) { return $form_fields; }
        $button = '<button type="button" class="button wpai-alt-generate" data-id="' . esc_attr($post->ID) . '">' . esc_html__('Générer alt avec WP AI Alt', 'wp-ai-alt') . '</button>';
        $form_fields['wpai_alt_button'] = [
            'label' => __('Texte alternatif', 'wp-ai-alt'),
            'input' => 'html',
            'html'  => $button . '<p class="description">' . esc_html__('Crée un alt concis et pertinent avec le moteur configuré.', 'wp-ai-alt') . '</p>',
        ];
        return $form_fields;
    }
    public function add_sidebox() {
        add_meta_box('wpai-alt-box', __('WP AI Alt', 'wp-ai-alt'), [$this, 'render_sidebox'], 'attachment', 'side', 'high');
    }
    public function render_sidebox($post) {
        if (strpos($post->post_mime_type, 'image/') !== 0) { echo '<p>' . esc_html__('Ce fichier n’est pas une image.', 'wp-ai-alt') . '</p>'; return; }
        echo '<p><button type="button" class="button button-primary wpai-alt-generate" data-id="' . esc_attr($post->ID) . '">' . esc_html__('Générer le ALT maintenant', 'wp-ai-alt') . '</button></p>';
        echo '<p class="description">' . esc_html__('Le résultat remplira automatiquement le champ « Texte alternatif ».', 'wp-ai-alt') . '</p>';
    }
}
