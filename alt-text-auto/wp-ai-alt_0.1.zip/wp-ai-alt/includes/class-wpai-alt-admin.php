<?php
namespace WPAIAlt;
if (!defined('ABSPATH')) { exit; }
class Admin {
    private $generator;
    public function __construct(Generator $generator) {
        $this->generator = $generator;
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
        add_action('wp_ajax_wpai_alt_generate', [$this, 'ajax_generate']);
        add_action('wp_ajax_wpai_alt_test_ollama', [$this, 'ajax_test_ollama']);
        add_action('wp_ajax_wpai_alt_detect_ollama', [$this, 'ajax_detect_ollama']);
        add_action('wp_ajax_wpai_alt_test_openai', [$this, 'ajax_test_openai']);
        add_action('admin_init', [$this, 'register_settings']);
    }
    public function menu() {
        $cap = 'upload_files';
        add_menu_page(__('WP AI Alt', 'wp-ai-alt'), __('WP AI Alt', 'wp-ai-alt'), $cap, 'wpai-alt-settings', [$this, 'render_settings'], 'dashicons-visibility', 59);
        add_submenu_page('wpai-alt-settings', __('Réglages', 'wp-ai-alt'), __('Réglages', 'wp-ai-alt'), $cap, 'wpai-alt-settings', [$this, 'render_settings']);
        add_submenu_page('wpai-alt-settings', __('Outils', 'wp-ai-alt'), __('Outils', 'wp-ai-alt'), $cap, 'wpai-alt-tools', [$this, 'render_tools']);
        add_submenu_page('wpai-alt-settings', __('Aide', 'wp-ai-alt'), __('Aide', 'wp-ai-alt'), $cap, 'wpai-alt-help', [$this, 'render_help']);
    }
    public function assets($hook) {
        if (strpos($hook, 'wpai-alt') === false) { return; }
        wp_enqueue_style('wpai-alt-admin', WPAIALT_URL . 'assets/admin.css', [], WPAIALT_VERSION);
        wp_enqueue_script('wpai-alt-admin', WPAIALT_URL . 'assets/admin.js', ['jquery'], WPAIALT_VERSION, true);
        wp_localize_script('wpai-alt-admin', 'WPAIALT', ['nonce'=>wp_create_nonce('wpai_alt'),'ajax'=>admin_url('admin-ajax.php')]);
    }
    public function register_settings() {
        register_setting('wpai_alt_options', Generator::OPTS_KEY, ['type'=>'array','sanitize_callback'=>[$this, 'sanitize_options']]);
    }
    public function sanitize_options($opts) {
        $d = $this->generator->get_options();
        $opts = wp_parse_args((array)$opts, $d);
        $opts['mode'] = in_array($opts['mode'], ['ollama','openai']) ? $opts['mode'] : 'ollama';
        $opts['language'] = sanitize_text_field($opts['language']);
        $opts['style'] = sanitize_text_field($opts['style']);
        $opts['length_min'] = max(4, intval($opts['length_min']));
        $opts['length_max'] = max($opts['length_min'], intval($opts['length_max']));
        $opts['ollama_url'] = esc_url_raw($opts['ollama_url']);
        $opts['ollama_model'] = sanitize_text_field($opts['ollama_model']);
        $opts['openai_endpoint'] = esc_url_raw($opts['openai_endpoint']);
        $opts['openai_api_key'] = sanitize_text_field($opts['openai_api_key']);
        $opts['openai_model'] = sanitize_text_field($opts['openai_model']);
        return $opts;
    }
    public function render_settings() { $opts = $this->generator->get_options(); include WPAIALT_DIR . 'templates/settings.php'; }
    public function render_tools() { include WPAIALT_DIR . 'templates/tools.php'; }
    public function render_help() { include WPAIALT_DIR . 'templates/help.php'; }
    public function ajax_generate() {
        check_ajax_referer('wpai_alt', 'nonce');
        $id = isset($_POST['attachment_id']) ? intval($_POST['attachment_id']) : 0;
        if (!$id) { wp_send_json_error(['message'=>'ID manquant']); }
        $res = $this->generator->generate_for_attachment($id);
        if (is_wp_error($res)) { wp_send_json_error(['message'=>$res->get_error_message(),'data'=>$res->get_error_data()]); }
        else { wp_send_json_success(['alt'=>$res]); }
    }
    public function ajax_test_ollama() {
        check_ajax_referer('wpai_alt', 'nonce');
        $base = isset($_POST['base']) ? esc_url_raw($_POST['base']) : '';
        if (!$base) { wp_send_json_error(['message'=>'URL de base manquante']); }
        $res = $this->generator->test_ollama($base);
        if (is_wp_error($res)) { wp_send_json_error(['message'=>$res->get_error_message()]); }
        wp_send_json_success($res);
    }
    public function ajax_detect_ollama() {
        check_ajax_referer('wpai_alt', 'nonce');
        $res = $this->generator->detect_ollama_candidates();
        wp_send_json_success(['candidates'=>$res]);
    }
    public function ajax_test_openai() {
        check_ajax_referer('wpai_alt', 'nonce');
        $endpoint = isset($_POST['endpoint']) ? esc_url_raw($_POST['endpoint']) : '';
        $key = isset($_POST['key']) ? sanitize_text_field($_POST['key']) : '';
        $model = isset($_POST['model']) ? sanitize_text_field($_POST['model']) : '';
        if (!$endpoint) { wp_send_json_error(['message'=>'Endpoint manquant']); }
        $res = $this->generator->test_openai($endpoint, $key, $model);
        if (is_wp_error($res)) { wp_send_json_error(['message'=>$res->get_error_message()]); }
        wp_send_json_success($res);
    }
}
