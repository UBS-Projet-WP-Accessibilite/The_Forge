<?php
namespace WPAIAlt;
if (!defined('ABSPATH')) { exit; }
class Generator {
    const OPTS_KEY = 'wpai_alt_options';
    public function get_options() {
        $defaults = [
            'mode' => 'ollama',
            'language' => 'fr',
            'style' => 'concis, descriptif',
            'length_min' => 12,
            'length_max' => 125,
            'ollama_url' => 'http://localhost:11434',
            'ollama_model' => 'llava:latest',
            'ollama_timeout' => 30,
            'openai_endpoint' => 'https://api.openai.com/v1',
            'openai_api_key' => '',
            'openai_model' => 'gpt-4o-mini',
            'openai_timeout' => 45,
        ];
        return wp_parse_args(get_option(self::OPTS_KEY, []), $defaults);
    }
    public function save_options($opts) { update_option(self::OPTS_KEY, $opts); }
    public function generate_for_attachment($attachment_id) {
        if (!current_user_can('upload_files')) { return new \WP_Error('forbidden', 'Permissions insuffisantes'); }
        $file = get_attached_file($attachment_id);
        if (!$file || !file_exists($file)) { return new \WP_Error('nofile', 'Fichier introuvable'); }
        $mime = get_post_mime_type($attachment_id);
        if (strpos($mime, 'image/') !== 0) { return new \WP_Error('notimage', 'Le fichier n’est pas une image'); }
        $image_b64 = base64_encode(file_get_contents($file));
        $opts = $this->get_options();
        $prompt = $this->build_prompt($attachment_id);
        if ($opts['mode'] === 'ollama') { return $this->call_ollama($opts, $image_b64, $prompt, $attachment_id); }
        else { return $this->call_openai($opts, $image_b64, $prompt, $attachment_id); }
    }
    private function build_prompt($attachment_id) {
        $title = get_the_title($attachment_id);
        $alt_existing = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
        $langs = sanitize_text_field($this->get_options()['language']);
        $style = sanitize_text_field($this->get_options()['style']);
        $len_min = intval($this->get_options()['length_min']);
        $len_max = intval($this->get_options()['length_max']);
        $avoid = $alt_existing ? "Évite de répéter : {$alt_existing}. " : "";
        $prompt = "Décris le contenu utile de l’image pour un attribut ALT SEO et accessibilité. Langue: {$langs}. Style: {$style}. Longueur cible: {$len_min}-{$len_max} caractères. Pas de mots vides, pas de ‘image de’. {$avoid}Retourne uniquement la phrase finale.";
        if ($title) { $prompt .= " Contexte possible depuis le nom du fichier ou titre WordPress: " . wp_strip_all_tags($title) . "."; }
        return $prompt;
    }
    private function call_ollama($opts, $image_b64, $prompt, $attachment_id) {
        $url = rtrim($opts['ollama_url'], '/') . '/api/generate';
        $body = ['model'=>$opts['ollama_model'],'prompt'=>$prompt,'images'=>[$image_b64],'stream'=>false];
        $resp = wp_remote_post($url, ['timeout'=>intval($opts['ollama_timeout']),'headers'=>['Content-Type'=>'application/json'],'body'=>wp_json_encode($body)]);
        if (is_wp_error($resp)) { return $resp; }
        $code = wp_remote_retrieve_response_code($resp);
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if ($code !== 200 || !is_array($data)) { return new \WP_Error('ollama_bad_response', 'Réponse Ollama invalide', ['http_code'=>$code,'body'=>wp_remote_retrieve_body($resp)]); }
        $text = isset($data['response']) ? trim($data['response']) : '';
        if (!$text && isset($data['message']['content'])) { $text = trim($data['message']['content']); }
        if (!$text) { return new \WP_Error('ollama_empty', 'Réponse vide d’Ollama'); }
        update_post_meta($attachment_id, '_wp_attachment_image_alt', $text);
        return $text;
    }
    private function call_openai($opts, $image_b64, $prompt, $attachment_id) {
        $endpoint = rtrim($opts['openai_endpoint'], '/');
        $url = $endpoint . '/chat/completions';
        $image_data_uri = 'data:image/jpeg;base64,' . $image_b64;
        $payload = ['model'=>$opts['openai_model'],'messages'=>[[ 'role'=>'user','content'=>[ ['type'=>'input_text','text'=>$prompt], ['type'=>'input_image','image'=>$image_data_uri] ] ]],'temperature'=>0.2];
        $payload_alt = ['model'=>$opts['openai_model'],'messages'=>[[ 'role'=>'user','content'=>[ ['type'=>'text','text'=>$prompt], ['type'=>'image_url','image_url'=>['url'=>$image_data_uri]] ] ]],'temperature'=>0.2];
        $headers = ['Content-Type'=>'application/json']; if (!empty($opts['openai_api_key'])) { $headers['Authorization'] = 'Bearer ' . $opts['openai_api_key']; }
        $resp = wp_remote_post($url, ['timeout'=>intval($opts['openai_timeout']),'headers'=>$headers,'body'=>wp_json_encode($payload)]);
        if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) >= 400) {
            $resp = wp_remote_post($url, ['timeout'=>intval($opts['openai_timeout']),'headers'=>$headers,'body'=>wp_json_encode($payload_alt)]);
        }
        if (is_wp_error($resp)) { return $resp; }
        $code = wp_remote_retrieve_response_code($resp);
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if ($code >= 400 || !is_array($data)) { return new \WP_Error('openai_bad_response', 'Réponse Vision invalide', ['http_code'=>$code,'body'=>wp_remote_retrieve_body($resp)]); }
        $text = '';
        if (isset($data['choices'][0]['message']['content'])) { $text = trim($data['choices'][0]['message']['content']); }
        elseif (isset($data['message']['content'])) { $text = trim($data['message']['content']); }
        if (!$text) { return new \WP_Error('openai_empty', 'Réponse vide du provider Vision'); }
        update_post_meta($attachment_id, '_wp_attachment_image_alt', $text);
        return $text;
    }
    public function test_ollama($base) {
        $url = rtrim($base, '/') . '/api/tags';
        $resp = wp_remote_get($url, ['timeout'=>10]);
        if (is_wp_error($resp)) { return $resp; }
        $code = wp_remote_retrieve_response_code($resp);
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if ($code !== 200) { return new \WP_Error('ollama_http', 'Ollama a répondu avec un code ' . $code); }
        $models = []; if (isset($body['models']) && is_array($body['models'])) { foreach($body['models'] as $m){ if (!empty($m['name'])) { $models[] = $m['name']; } } }
        $v = wp_remote_get(rtrim($base,'/') . '/api/version', ['timeout'=>10]);
        $ver = is_wp_error($v) ? '' : (json_decode(wp_remote_retrieve_body($v), true)['version'] ?? '');
        return ['ok'=>true, 'version'=>$ver, 'models'=>$models];
    }
    public function detect_ollama_candidates() {
        $candidates = ['http://localhost:11434','http://127.0.0.1:11434','http://host.docker.internal:11434','http://172.17.0.1:11434'];
        $found = [];
        foreach ($candidates as $base) {
            $test = $this->test_ollama($base);
            if (!is_wp_error($test) && !empty($test['ok'])) { $found[] = array_merge(['base'=>$base], $test); }
        }
        return $found;
    }
    public function test_openai($endpoint, $api_key, $model) {
        $url = rtrim($endpoint, '/') . '/models';
        $headers = ['Content-Type'=>'application/json']; if (!empty($api_key)) { $headers['Authorization'] = 'Bearer ' . $api_key; }
        $resp = wp_remote_get($url, ['headers'=>$headers, 'timeout'=>15]);
        if (is_wp_error($resp)) { return $resp; }
        $code = wp_remote_retrieve_response_code($resp);
        if ($code >= 400) { return new \WP_Error('api_http', 'HTTP ' . $code . ' depuis l’API. Vérifie endpoint et clé.'); }
        return ['ok'=>true];
    }
}
