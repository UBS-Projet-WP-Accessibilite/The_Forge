<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap">
  <h1><span class="dashicons dashicons-visibility" style="margin-right:8px"></span>WP AI Alt — Aide (Images / Texte alternatif)</h1>
  <p class="description">Guide pas à pas pour configurer Ollama (local) ou un provider Vision hébergé, et générer automatiquement des ALT accessibles et pertinents.</p>
  <div class="wpai-alt-grid">
    <div class="wpai-card">
      <h2>0) À qui s’adresse ce guide</h2>
      <p>Débutant·e WordPress. Objectif : générer automatiquement des attributs alt utiles.</p>
    </div>
    <div class="wpai-card">
      <h2>1) Prérequis rapides</h2>
      <ul>
        <li>WordPress + PHP 8.0+</li>
        <li><strong>Soit</strong> Ollama local (Mac/Windows/Linux)</li>
        <li><strong>Soit</strong> un provider Vision compatible OpenAI</li>
      </ul>
    </div>
    <div class="wpai-card">
      <h2>2) Option A — Utiliser Ollama (local)</h2>
      <ol>
        <li>Installez Ollama depuis <code>https://ollama.com</code>. Lancez-le.</li>
        <li>Téléchargez un modèle vision : <code>ollama pull llava</code> ou autre modèle LLaVA/Minicpm-vision.</li>
        <li>URL par défaut : <code>http://localhost:11434</code>. Cliquez dans <strong>WP AI Alt → Réglages → Détecter automatiquement</strong>. Le plugin testera aussi <code>host.docker.internal</code> et <code>172.17.0.1</code> pour LocalWP/Docker.</li>
        <li>Test manuel : <code>curl http://localhost:11434/api/version</code>. Depuis le conteneur WP : <code>curl http://host.docker.internal:11434/api/version</code> (Linux : <code>172.17.0.1</code>).</li>
        <li>Collez l’URL et le modèle dans Réglages puis <strong>Enregistrer</strong>.</li>
      </ol>
    </div>
    <div class="wpai-card">
      <h2>3) Option B — Provider Vision (hébergé)</h2>
      <ol>
        <li>Récupérez l’endpoint API (ex. <code>https://api.openai.com/v1</code>) et la clé API.</li>
        <li>Choisissez un modèle Vision (ex. <code>gpt-4o-mini</code>).</li>
        <li>Dans <strong>Réglages</strong>, saisissez endpoint, clé et modèle puis utilisez <strong>Tester connexion</strong>.</li>
      </ol>
    </div>
    <div class="wpai-card">
      <h2>4) Réglages de génération</h2>
      <ul>
        <li>Langue, style, longueur cible.</li>
        <li>Pas de “image de…”, pas de mots vides.</li>
        <li>Le champ ALT existant est respecté : la génération évite de le répéter.</li>
      </ul>
    </div>
    <div class="wpai-card">
      <h2>5) Utiliser la fonctionnalité</h2>
      <ul>
        <li>Médiathèque → action “Générer alt (WP AI Alt)”</li>
        <li>Écran pièce jointe → bouton “Générer le ALT maintenant”</li>
        <li>WP AI Alt → <strong>Outils</strong> → liste des images sans ALT</li>
      </ul>
    </div>
    <div class="wpai-card">
      <h2>6) Conseils de qualité</h2>
      <ul>
        <li>Décrire l’essentiel : objet, action, contexte.</li>
        <li>Éviter les détails décoratifs.</li>
        <li>Conserver 12–125 caractères en moyenne.</li>
      </ul>
    </div>
    <div class="wpai-card">
      <h2>7) Dépannage</h2>
      <details open><summary><strong>LocalWP / Docker</strong></summary>
        <p>Si le test échoue sur <code>http://localhost:11434</code>, essayez :</p>
        <ul>
          <li>Mac/Windows : <code>http://host.docker.internal:11434</code></li>
          <li>Linux : <code>http://172.17.0.1:11434</code></li>
        </ul>
        <p>Commandes utiles :</p>
        <pre>curl http://localhost:11434/api/version
docker exec -it &lt;container_wp&gt; curl http://host.docker.internal:11434/api/version
ip addr show docker0   # l’IP est souvent 172.17.0.1</pre>
      </details>
      <details><summary><strong>Modèle introuvable</strong></summary>
        <pre>ollama pull llava</pre>
      </details>
      <details><summary><strong>Erreurs 401/403 sur provider</strong></summary>
        <p>Vérifiez endpoint, modèle et clé. Utilisez “Tester connexion”.</p>
      </details>
    </div>
    <div class="wpai-card">
      <h2>8) Ergonomie — idées à intégrer</h2>
      <ul>
        <li>Assistant de configuration en 3 étapes.</li>
        <li>Prévisualisation : bouton “Essayer sur une image d’exemple”.</li>
        <li>Actions rapides : “Écraser seulement si vide”.</li>
        <li>Logs sur la page Outils.</li>
        <li>Accessibilité : contrastes, focus, messages clairs.</li>
      </ul>
    </div>
    <div class="wpai-card">
      <h2>9) Check‑list rapide</h2>
      <ul>
        <li>Plugin activé</li>
        <li>Moteur : Ollama ou Vision</li>
        <li>Test connexion OK</li>
        <li>Langue/Style/Longueur définis</li>
        <li>Génération : depuis Outils ou Médiathèque</li>
      </ul>
    </div>
  </div>
  <p class="wpai-muted">Version d’aide : 1.00</p>
</div>
