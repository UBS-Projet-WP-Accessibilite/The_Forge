<?php
if (!defined('ABSPATH')) { exit; }
$args = [
  'post_type'      => 'attachment',
  'post_mime_type' => 'image',
  'posts_per_page' => 24,
  'meta_query'     => [
    ['key'=>'_wp_attachment_image_alt', 'compare'=>'NOT EXISTS']
  ],
];
$q = new WP_Query($args);
?>
<div class="wrap">
  <h1><span class="dashicons dashicons-visibility" style="margin-right:8px"></span>WP AI Alt — Outils</h1>
  <p class="description">Générez rapidement des ALT pour les images sans texte alternatif.</p>
  <?php if ($q->have_posts()): ?>
    <div class="wpai-tools-list">
    <?php while($q->have_posts()): $q->the_post();
      $id = get_the_ID();
      $src = wp_get_attachment_image_src($id, 'thumbnail');
      $src = $src ? $src[0] : '';
      ?>
      <div class="wpai-item">
        <img class="wpai-thumb" src="<?php echo esc_url($src); ?>" alt="thumb">
        <div style="flex:1">
          <div><strong>#<?php echo esc_html($id); ?></strong> <?php echo esc_html(get_the_title()); ?></div>
          <div class="wpai-actions">
            <button class="button button-primary wpai-alt-generate" data-id="<?php echo esc_attr($id); ?>">Générer alt</button>
            <a class="button" href="<?php echo esc_url(get_edit_post_link($id)); ?>">Ouvrir la pièce jointe</a>
          </div>
        </div>
      </div>
    <?php endwhile; wp_reset_postdata(); ?>
    </div>
  <?php else: ?>
    <div class="wpai-card"><p>Toutes vos images ont déjà un ALT ou aucune image trouvée. Utilisez la Médiathèque pour régénérer un ALT individuellement si besoin.</p></div>
  <?php endif; ?>
</div>
