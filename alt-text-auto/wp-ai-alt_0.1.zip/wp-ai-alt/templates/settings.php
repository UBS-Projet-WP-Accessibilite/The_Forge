<?php
if (!defined('ABSPATH')) { exit; }
$opts = $opts ?? $this->generator->get_options();
?>
<div class="wrap">
  <h1><span class="dashicons dashicons-visibility" style="margin-right:8px"></span>WP AI Alt — Réglages</h1>
  <p class="description">Choisissez le moteur, configurez l’URL et testez la connexion. Le menu principal (icône œil) ouvre cette page de réglages.</p>
  <form method="post" action="options.php">
    <?php settings_fields('wpai_alt_options'); ?>
    <?php $name = \WPAIAlt\Generator::OPTS_KEY; ?>
    <div class="wpai-alt-grid">
      <div class="wpai-card">
        <h2>Moteur</h2>
        <label><input type="radio" name="<?php echo esc_attr($name); ?>[mode]" value="ollama" <?php checked($opts['mode'],'ollama'); ?>> Ollama (local)</label><br>
        <label><input type="radio" name="<?php echo esc_attr($name); ?>[mode]" value="openai" <?php checked($opts['mode'],'openai'); ?>> Provider Vision (hébergé, API compatible OpenAI)</label>
      </div>
      <div class="wpai-card">
        <h2>Paramètres linguistiques</h2>
        <table class="form-table">
          <tr><th scope="row"><label>Langue</label></th><td><input type="text" name="<?php echo esc_attr($name); ?>[language]" value="<?php echo esc_attr($opts['language']); ?>" placeholder="fr"></td></tr>
          <tr><th scope="row"><label>Style</label></th><td><input type="text" name="<?php echo esc_attr($name); ?>[style]" value="<?php echo esc_attr($opts['style']); ?>" placeholder="concis, descriptif"></td></tr>
          <tr><th scope="row"><label>Longueur cible</label></th><td>
            min <input type="number" name="<?php echo esc_attr($name); ?>[length_min]" value="<?php echo esc_attr($opts['length_min']); ?>" style="width:80px">
            max <input type="number" name="<?php echo esc_attr($name); ?>[length_max]" value="<?php echo esc_attr($opts['length_max']); ?>" style="width:80px">
          </td></tr>
        </table>
      </div>
      <div class="wpai-card">
        <h2>Ollama (local)</h2>
        <table class="form-table">
          <tr><th scope="row"><label for="ollama_url">URL de base</label></th>
              <td><input id="ollama_url" type="url" name="<?php echo esc_attr($name); ?>[ollama_url]" value="<?php echo esc_attr($opts['ollama_url']); ?>" placeholder="http://localhost:11434" style="width:100%"></td></tr>
          <tr><th scope="row"><label for="ollama_model">Modèle</label></th>
              <td><input id="ollama_model" type="text" name="<?php echo esc_attr($name); ?>[ollama_model]" value="<?php echo esc_attr($opts['ollama_model']); ?>" placeholder="llava:latest"></td></tr>
        </table>
        <p class="wpai-rows">
          <button type="button" class="button" id="wpai-detect-ollama">Détecter automatiquement</button>
          <button type="button" class="button" id="wpai-test-ollama">Tester connexion</button>
        </p>
        <p id="wpai-ollama-test-out" class="wpai-muted"></p>
        <details>
          <summary><strong>Fonctionnement en local (LocalWP, Docker, WSL)</strong></summary>
          <ol>
            <li>Installez Ollama sur votre machine hôte et lancez-le. Par défaut: <code>http://localhost:11434</code>.</li>
            <li>Si WordPress tourne dans un conteneur (LocalWP/Docker), <code>localhost</code> du conteneur ne pointe pas vers l’hôte. Essayez:
              <ul>
                <li>Mac/Windows: <code>http://host.docker.internal:11434</code></li>
                <li>Linux: <code>http://172.17.0.1:11434</code></li>
              </ul>
              Utilisez le bouton “Détecter automatiquement” ci-dessus.</li>
            <li>Vérifiez depuis le terminal hôte que l’API répond: <code>curl http://localhost:11434/api/version</code></li>
            <li>Depuis le conteneur WordPress: <code>curl http://host.docker.internal:11434/api/version</code> (ou l’IP Linux). Si cela répond, collez la même URL ici.</li>
            <li>Téléchargez un modèle Vision si besoin, ex.: <code>ollama pull llava</code> ou <code>ollama pull llava:13b</code>.</li>
          </ol>
        </details>
      </div>
      <div class="wpai-card">
        <h2>Provider Vision (hébergé)</h2>
        <table class="form-table">
          <tr><th scope="row"><label for="openai_endpoint">Endpoint API</label></th>
              <td><input id="openai_endpoint" type="url" name="<?php echo esc_attr($name); ?>[openai_endpoint]" value="<?php echo esc_attr($opts['openai_endpoint']); ?>" placeholder="https://api.openai.com/v1" style="width:100%"></td></tr>
          <tr><th scope="row"><label for="openai_api_key">Clé API</label></th>
              <td><input id="openai_api_key" type="password" name="<?php echo esc_attr($name); ?>[openai_api_key]" value="<?php echo esc_attr($opts['openai_api_key']); ?>" placeholder="sk-..." style="width:100%"></td></tr>
          <tr><th scope="row"><label for="openai_model">Modèle</label></th>
              <td><input id="openai_model" type="text" name="<?php echo esc_attr($name); ?>[openai_model]" value="<?php echo esc_attr($opts['openai_model']); ?>" placeholder="gpt-4o-mini"></td></tr>
        </table>
        <p class="wpai-rows">
          <button type="button" class="button" id="wpai-test-openai">Tester connexion</button>
        </p>
        <p id="wpai-openai-test-out" class="wpai-muted"></p>
        <details>
          <summary><strong>Où trouver les informations</strong></summary>
          <ul>
            <li>Endpoint: fourni par votre hébergeur d’API compatible OpenAI.</li>
            <li>Clé API: depuis le tableau de bord du provider.</li>
            <li>Modèle: ex. <code>gpt-4o-mini</code>, <code>gpt-4o</code> ou tout modèle Vision pris en charge.</li>
          </ul>
          <p>Le plugin encode l’image en base64 côté serveur et envoie un prompt concis. Pas de CORS.</p>
        </details>
      </div>
    </div>
    <?php submit_button(); ?>
  </form>
</div>
