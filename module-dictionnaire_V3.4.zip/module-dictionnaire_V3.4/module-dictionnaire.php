<?php
/**
 * Plugin Name:       Module Dictionnaire (v31.2 - Protocole OpenAI)
 * Description:       Parle le langage des API compatibles OpenAI.
 * Version:           31.2
 * Author:            Votre Nom
 */
if (!defined('ABSPATH')) exit;

define('DICTIONARY_MODULE_URL', plugin_dir_url(__FILE__));
define('DICTIONARY_MODULE_PATH', plugin_dir_path(__FILE__));

class DictionaryModuleV31_2 {
    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_front_assets']);
        add_action('wp_footer', [$this, 'inject_plugin_footer_elements']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('wp_ajax_nopriv_dm_log_usage', [$this, 'log_api_usage']);
        add_action('wp_ajax_dm_log_usage', [$this, 'log_api_usage']);
        add_action('wp_ajax_nopriv_get_definition', [$this, 'get_definition_from_api']);
        add_action('wp_ajax_get_definition', [$this, 'get_definition_from_api']);
    }

    public function enqueue_front_assets() {
        wp_enqueue_style('dictionary-module-css', DICTIONARY_MODULE_URL . 'assets/dictionary-module.css', [], '31.2');
        wp_enqueue_script('dictionary-module-js', DICTIONARY_MODULE_URL . 'assets/dictionary-module.js', ['jquery'], '31.2', true);
        
        $options = get_option('dm_options', ['api_key' => '', 'api_url' => '', 'daily_token_limit' => 0]);
        
        wp_localize_script('dictionary-module-js', 'dm_vars', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('dm_ajax_nonce'),
            'limit_reached' => $this->is_daily_limit_reached(),
            'limit_message' => 'Le quota de définitions pour aujourd\'hui a été atteint. Réessayez demain.'
        ]);
    }

    public function inject_plugin_footer_elements() {
        echo '<div id="dm-popup" class="dm-hidden"></div>';
        echo '<div id="dm-tooltip" class="dm-hidden"><p><b>Astuce :</b> Double-cliquez sur un mot pour obtenir sa définition.</p><button id="dm-tooltip-close">&times;</button></div>';
    }

    public function add_admin_menu() {
        add_menu_page('Module Dictionnaire', 'Dictionnaire', 'manage_options', 'dictionary-module-settings', [$this, 'create_admin_page'], 'dashicons-book-alt', 80);
    }

    public function create_admin_page() {
        include(DICTIONARY_MODULE_PATH . 'admin/admin-page.php');
    }

    public function register_settings() {
        register_setting('dm_options_group', 'dm_options');
    }
    
    public function is_daily_limit_reached() {
        $options = get_option('dm_options', ['daily_token_limit' => 0]);
        $limit = intval($options['daily_token_limit']);
        if ($limit <= 0) return false;
        $today_tokens = $this->get_today_usage()['tokens'];
        return $today_tokens >= $limit;
    }
    
    public function get_today_usage() {
        $stats = get_option('dm_daily_usage_stats', []);
        $today = date('Y-m-d');
        return isset($stats[$today]) ? $stats[$today] : ['requests' => 0, 'tokens' => 0];
    }

    public function log_api_usage() {
        check_ajax_referer('dm_ajax_nonce', 'nonce');
        $tokens_used = isset($_POST['tokens']) ? intval($_POST['tokens']) : 0;
        $stats = get_option('dm_daily_usage_stats', []);
        $today = date('Y-m-d');
        if (!isset($stats[$today])) {
            $stats[$today] = ['requests' => 0, 'tokens' => 0];
        }
        $stats[$today]['requests']++;
        $stats[$today]['tokens'] += $tokens_used;
        if (count($stats) > 7) {
            $stats = array_slice($stats, -7, 7, true);
        }
        update_option('dm_daily_usage_stats', $stats);
        wp_send_json_success($stats[$today]);
    }

    /**
     * **MODIFIÉ** : Cette fonction parle maintenant le protocole OpenAI.
     */
    public function get_definition_from_api() {
        check_ajax_referer('dm_ajax_nonce', 'nonce');

        if (!isset($_POST['word']) || empty($_POST['word'])) {
            wp_send_json_error(['message' => 'Aucun mot fourni.']);
            return;
        }
        $word = sanitize_text_field($_POST['word']);

        $options = get_option('dm_options', ['api_key' => '', 'api_url' => '']);
        $api_url = $options['api_url'];
        $api_key = $options['api_key'];

        if (empty($api_url)) {
            wp_send_json_error(['message' => 'L\'URL de l\'API n\'est pas configurée.']);
            return;
        }

        // 1. On construit l'URL complète de l'endpoint
        $full_api_url = rtrim($api_url, '/') . '/v1/chat/completions';
        
        $headers = [
            'Content-Type'  => 'application/json; charset=utf-8',
            'Authorization' => 'Bearer ' . $api_key
        ];

        // 2. On formate le corps de la requête selon le protocole OpenAI
        $body = json_encode([
            'model' => 'gpt-3.5-turbo', // Modèle par défaut, à vérifier dans la doc de Ragarenn
            'messages' => [
                [
                    'role' => 'user',
                    'content' => 'Donne une définition simple et courte pour le mot : "' . $word . '"'
                ]
            ],
            'max_tokens' => 150,
            'temperature' => 0.3
        ]);

        $args = [
            'body'      => $body,
            'headers'   => $headers,
            'timeout'   => 30,
            'method'    => 'POST',
            'sslverify' => false
        ];

        $response = wp_remote_post($full_api_url, $args);

        if (is_wp_error($response)) {
            wp_send_json_error(['message' => $response->get_error_message()]);
            return;
        }

        $response_body = wp_remote_retrieve_body($response);
        $data = json_decode($response_body, true);

        // 3. On extrait la définition de la structure de réponse OpenAI
        $definition_text = $data['choices'][0]['message']['content'] ?? null;

        if ($definition_text) {
             // On renvoie une réponse simple au JavaScript
            wp_send_json_success(['definition' => trim($definition_text)]);
        } else {
            // Si la structure de la réponse est inattendue ou vide
            wp_send_json_error(['message' => 'La réponse de l\'API est dans un format inattendu.', 'details' => $data]);
        }
    }
}
new DictionaryModuleV31_2();
?>