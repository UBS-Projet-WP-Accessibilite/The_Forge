import { pipeline } from '@xenova/transformers';

/**
 * Module Speech-to-Text pour WordPress
 * Compatible WASM (Transformers.js) et Web Speech API
 */
class WPSpeechToTextModule {
    constructor(config = {}) {
        // Attendre que wpSttConfig soit disponible
        if (typeof window.wpSttConfig === 'undefined') {
            console.warn('[WP STT] Configuration non disponible, utilisation des valeurs par défaut');
        }
        
        // Configuration avec valeurs par défaut WordPress
        this.config = {
            wasmModelName: 'Xenova/whisper-tiny',
            language: window.wpSttConfig?.language || 'fr',
            ajaxUrl: window.wpSttConfig?.ajaxUrl || '',
            nonce: window.wpSttConfig?.nonce || '',
            i18n: window.wpSttConfig?.i18n || {},
            ...config
        };

        // Modèles disponibles pour WASM
        this.availableModels = {
            'tiny': {
                name: 'Xenova/whisper-tiny',
                size: '39 MB',
                description: 'Rapide, précision correcte',
                speed: 'Très rapide',
                multilingue: 'Limité',
                performance: 'Léger - Fonctionne sur tous les appareils',
                maxDuration: 60, // Durée max recommandée en secondes
                chunkLength: 30
            },
            'base': {
                name: 'Xenova/whisper-base',
                size: '74 MB',
                description: 'Bon équilibre vitesse/précision',
                speed: 'Rapide',
                multilingue: 'Bon',
                performance: 'Modéré - Recommandé pour usage quotidien',
                maxDuration: 45,
                chunkLength: 30
            },
            'small': {
                name: 'Xenova/whisper-small',
                size: '244 MB',
                description: 'Haute précision, meilleur multilingue',
                speed: 'Moyen à lent',
                multilingue: 'Excellent',
                performance: 'Gourmand - Peut ralentir sur petits appareils',
                maxDuration: 30,
                chunkLength: 20 // Chunks plus courts pour réduire la charge
            }
        };

        // Langues disponibles avec leurs codes ISO
        this.availableLanguages = {
            'fr': { name: 'Français', webSpeechCode: 'fr-FR' },
            'en': { name: 'English', webSpeechCode: 'en-US' },
            'es': { name: 'Español', webSpeechCode: 'es-ES' },
            'de': { name: 'Deutsch', webSpeechCode: 'de-DE' },
            'it': { name: 'Italiano', webSpeechCode: 'it-IT' },
            'pt': { name: 'Português', webSpeechCode: 'pt-PT' },
            'nl': { name: 'Nederlands', webSpeechCode: 'nl-NL' },
            'pl': { name: 'Polski', webSpeechCode: 'pl-PL' },
            'ru': { name: 'Русский', webSpeechCode: 'ru-RU' },
            'zh': { name: '中文', webSpeechCode: 'zh-CN' },
            'ja': { name: '日本語', webSpeechCode: 'ja-JP' },
            'ko': { name: '한국어', webSpeechCode: 'ko-KR' },
            'ar': { name: 'العربية', webSpeechCode: 'ar-SA' }
        };

        this.state = {
            currentMethod: window.wpSttConfig?.defaultMethod || 'wasm',
            selectedModel: 'tiny',
            selectedLanguage: this.config.language,
            isModelLoaded: false,
            isRecording: false,
            isProcessing: false,
            wasmPipeline: null,
            recognition: null,
            mediaRecorder: null,
            audioChunks: [],
            loadedModelKey: null,
            recordingStartTime: null
        };

        this.elements = {};
        this.isModuleVisible = false;
        this.targetEditor = null;
        this.recordingTimer = null;
        this.init();
    }

    async init() {
        try {
            // Attendre que le DOM soit prêt
            if (document.readyState === 'loading') {
                await new Promise(resolve => document.addEventListener('DOMContentLoaded', resolve));
            }
            
            this.bindElements();
            this.bindEvents();
            this.populateModelSelect();
            this.populateLanguageSelect();
            this.updateMethodDescription();
            this.updateUI();
            
            console.log('[WP STT] Module initialisé avec succès');
        } catch (error) {
            console.error('[WP STT] Erreur d\'initialisation:', error);
        }
    }

    bindElements() {
        this.elements = {
            // Boutons déclencheurs
            triggers: document.querySelectorAll('.wp-stt-trigger'),
            editorButton: document.getElementById('wp-stt-editor-button'),
            toggleBtn: document.getElementById('wp-stt-toggle-btn'),
            closeBtn: document.getElementById('wp-stt-close'),
            
            // Module et overlay
            module: document.getElementById('wp-stt-module'),
            overlay: document.getElementById('wp-stt-overlay'),
            
            // Contrôles
            methodSelect: document.getElementById('wp-stt-method-select'),
            modelSelect: document.getElementById('wp-stt-model-select'),
            languageSelect: document.getElementById('wp-stt-language-select'),
            descriptionText: document.getElementById('wp-stt-description-text'),
            modelInfo: document.getElementById('wp-stt-model-info'),
            performanceWarning: document.getElementById('wp-stt-performance-warning'),
            startBtn: document.getElementById('wp-stt-start'),
            recordingTimer: document.getElementById('wp-stt-recording-timer'),
            
            // Sections
            wasmSettings: document.getElementById('wp-stt-wasm-settings'),
            downloadSection: document.getElementById('wp-stt-download-section'),
            downloadBtn: document.getElementById('wp-stt-download'),
            progressContainer: document.getElementById('wp-stt-progress-container'),
            progressFill: document.getElementById('wp-stt-progress-fill'),
            progressText: document.getElementById('wp-stt-progress-text'),
            
            // Transcription
            transcriptionDisplay: document.getElementById('wp-stt-transcription'),
            
            // Actions
            actionButtons: document.getElementById('wp-stt-actions'),
            copyBtn: document.getElementById('wp-stt-copy'),
            insertBtn: document.getElementById('wp-stt-insert'),
            
            // Status
            statusText: document.getElementById('wp-stt-status-text'),
            statusDot: document.getElementById('wp-stt-status-dot')
        };
    }

    bindEvents() {
        // Bouton flottant principal
        this.elements.toggleBtn?.addEventListener('click', (e) => {
            e.preventDefault();
            this.captureActiveEditor();
            this.toggleModule();
        });
        
        // Support clavier pour le bouton flottant
        this.elements.toggleBtn?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.captureActiveEditor();
                this.toggleModule();
            }
        });
        
        // Autres boutons déclencheurs
        this.elements.triggers?.forEach(trigger => {
            trigger.addEventListener('click', (e) => {
                e.preventDefault();
                this.captureActiveEditor();
                this.showModule();
            });
            
            trigger.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.captureActiveEditor();
                    this.showModule();
                }
            });
        });

        // Fermeture
        this.elements.closeBtn?.addEventListener('click', () => this.hideModule());
        this.elements.overlay?.addEventListener('click', () => this.hideModule());
        
        // Escape pour fermer
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isModuleVisible) {
                this.hideModule();
            }
        });

        // Contrôles
        this.elements.methodSelect?.addEventListener('change', (e) => {
            this.state.currentMethod = e.target.value;
            this.updateMethodDescription();
            this.updateUI();
        });

        this.elements.modelSelect?.addEventListener('change', (e) => {
            this.state.selectedModel = e.target.value;
            this.updateModelInfo();
            this.checkModelChange();
            this.showPerformanceWarning();
        });

        this.elements.languageSelect?.addEventListener('change', (e) => {
            this.state.selectedLanguage = e.target.value;
            this.updateWebSpeechLanguage();
            console.log('[WP STT] Langue sélectionnée:', this.state.selectedLanguage);
        });

        this.elements.downloadBtn?.addEventListener('click', () => this.downloadWasmModel());
        this.elements.startBtn?.addEventListener('click', () => this.handleRecording());
        this.elements.copyBtn?.addEventListener('click', () => this.copyText());
        this.elements.insertBtn?.addEventListener('click', () => this.insertText());
    }

    populateModelSelect() {
        if (!this.elements.modelSelect) return;

        this.elements.modelSelect.innerHTML = '';
        
        Object.entries(this.availableModels).forEach(([key, model]) => {
            const option = document.createElement('option');
            option.value = key;
            option.textContent = `${key.charAt(0).toUpperCase() + key.slice(1)} (${model.size})`;
            this.elements.modelSelect.appendChild(option);
        });

        this.elements.modelSelect.value = this.state.selectedModel;
        this.updateModelInfo();
        this.showPerformanceWarning();
    }

    populateLanguageSelect() {
        if (!this.elements.languageSelect) return;

        this.elements.languageSelect.innerHTML = '';
        
        Object.entries(this.availableLanguages).forEach(([code, lang]) => {
            const option = document.createElement('option');
            option.value = code;
            option.textContent = lang.name;
            this.elements.languageSelect.appendChild(option);
        });

        this.elements.languageSelect.value = this.state.selectedLanguage;
    }

    updateModelInfo() {
        if (!this.elements.modelInfo) return;

        const model = this.availableModels[this.state.selectedModel];
        if (!model) return;

        this.elements.modelInfo.innerHTML = `
            <strong>Taille :</strong> ${model.size} | 
            <strong>Vitesse :</strong> ${model.speed} | 
            <strong>Multilingue :</strong> ${model.multilingue}<br>
            <strong>${model.description}</strong><br>
            <em>${model.performance}</em>
        `;
    }

    showPerformanceWarning() {
        if (!this.elements.performanceWarning) return;

        const model = this.availableModels[this.state.selectedModel];
        
        if (this.state.selectedModel === 'small') {
            this.elements.performanceWarning.style.display = 'block';
            this.elements.performanceWarning.innerHTML = `
                ⚠️ <strong>Attention :</strong> Le modèle Small peut ralentir votre navigateur pendant la transcription. 
                Limitez vos enregistrements à <strong>${model.maxDuration} secondes max</strong> pour de meilleures performances.
            `;
        } else {
            this.elements.performanceWarning.style.display = 'none';
        }
    }

    checkModelChange() {
        // Si un modèle différent est sélectionné et qu'un modèle est déjà chargé
        if (this.state.isModelLoaded && this.state.loadedModelKey !== this.state.selectedModel) {
            this.state.isModelLoaded = false;
            this.state.wasmPipeline = null;
            this.state.loadedModelKey = null;
            
            if (this.elements.downloadBtn) {
                this.elements.downloadBtn.style.display = 'block';
                this.elements.downloadBtn.disabled = false;
            }
            
            this.updateStatus('Nouveau modèle sélectionné - Téléchargez-le', 'ready');
            this.updateUI();
        }
    }

    updateWebSpeechLanguage() {
        // Si Web Speech API est en cours, redémarrer avec la nouvelle langue
        if (this.state.isRecording && this.state.currentMethod === 'webspeech') {
            this.stopRecording();
            this.showNotification('Changement de langue - redémarrez l\'enregistrement', 'info');
        }
    }

    captureActiveEditor() {
        this.targetEditor = null;
        
        // Gutenberg
        if (typeof wp !== 'undefined' && wp.data && wp.data.select('core/editor')) {
            try {
                this.targetEditor = { type: 'gutenberg' };
                console.log('[WP STT] Éditeur Gutenberg détecté');
                return;
            } catch (e) {
                console.log('[WP STT] Gutenberg présent mais pas actif');
            }
        }
        
        // TinyMCE
        if (typeof tinymce !== 'undefined') {
            const editor = tinymce.activeEditor;
            if (editor && !editor.isHidden()) {
                this.targetEditor = { type: 'tinymce', editor: editor };
                console.log('[WP STT] Éditeur TinyMCE détecté');
                return;
            }
        }
        
        // Textarea classique
        const textarea = document.getElementById('content');
        if (textarea) {
            this.targetEditor = { type: 'textarea', element: textarea };
            console.log('[WP STT] Textarea classique détecté');
            return;
        }
        
        // Commentaires WordPress
        const commentField = document.getElementById('comment');
        if (commentField) {
            this.targetEditor = { type: 'comment', element: commentField };
            console.log('[WP STT] Champ de commentaire détecté');
            return;
        }
        
        // Champ textarea actif
        const activeElement = document.activeElement;
        if (activeElement && activeElement.tagName === 'TEXTAREA') {
            this.targetEditor = { type: 'textarea', element: activeElement };
            console.log('[WP STT] Textarea actif détecté:', activeElement.id || activeElement.name);
            return;
        }
        
        // Champ contenteditable actif
        if (activeElement && activeElement.isContentEditable) {
            this.targetEditor = { type: 'contenteditable', element: activeElement };
            console.log('[WP STT] ContentEditable détecté');
            return;
        }
        
        console.warn('[WP STT] Aucun éditeur actif détecté');
    }

    checkWebSpeechSupport() {
        return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
    }

    updateMethodDescription() {
        const descriptions = {
            wasm: `Utilise Transformers.js avec le modèle Whisper. Traitement 100% local dans votre navigateur. Aucune donnée envoyée. Fonctionne hors ligne après téléchargement. Compatible avec Chrome 91+, Firefox 89+, Safari 14.1+, Edge 91+.`,
            webspeech: `Utilise l'API native du navigateur. L'audio est envoyé en ligne pour traitement. Nécessite une connexion internet. Compatible avec Chrome, Edge, Safari (partiel).`
        };

        if (this.elements.descriptionText) {
            this.elements.descriptionText.textContent = descriptions[this.state.currentMethod];
        }
    }

    updateUI() {
        const isWasm = this.state.currentMethod === 'wasm';
        const hasWebSpeech = this.checkWebSpeechSupport();
        
        // Section paramètres WASM (modèle + langue)
        if (this.elements.wasmSettings) {
            this.elements.wasmSettings.style.display = isWasm ? 'block' : 'none';
        }

        // Section téléchargement (visible uniquement pour WASM)
        if (this.elements.downloadSection) {
            this.elements.downloadSection.style.display = isWasm ? 'block' : 'none';
        }

        // Bouton d'enregistrement
        if (this.elements.startBtn) {
            if (isWasm) {
                // Pour WASM, désactiver si le modèle n'est pas chargé
                this.elements.startBtn.disabled = !this.state.isModelLoaded;
                if (!this.state.isModelLoaded) {
                    this.updateStatus('Téléchargez d\'abord le modèle', 'ready');
                } else {
                    this.updateStatus(`Prêt (${this.availableLanguages[this.state.selectedLanguage].name})`, 'ready');
                }
            } else {
                // Pour Web Speech API, désactiver si non supporté
                this.elements.startBtn.disabled = !hasWebSpeech;
                if (hasWebSpeech) {
                    this.updateStatus('Web Speech API prêt', 'ready');
                } else {
                    this.updateStatus('Web Speech API non supporté par ce navigateur', 'error');
                }
            }
        }
    }

    async downloadWasmModel() {
        try {
            const modelKey = this.state.selectedModel;
            const model = this.availableModels[modelKey];
            
            this.updateStatus(`Téléchargement du modèle ${modelKey}...`, 'loading');
            this.elements.downloadBtn.disabled = true;
            this.showProgress(true);
            
            // Initialiser la barre à 0%
            this.updateProgress(0);

            // Variables pour suivre la progression globale
            let totalFiles = 0;
            let loadedFiles = 0;
            const fileProgress = {};

            this.state.wasmPipeline = await pipeline(
                'automatic-speech-recognition',
                model.name,
                {
                    quantized: true,
                    progress_callback: (progress) => {
                        console.log('[WP STT] Progress:', progress);
                        
                        if (progress.status === 'progress') {
                            const percent = Math.round(progress.progress);
                            this.updateProgress(percent);
                            this.updateStatus(`Téléchargement: ${percent}%`, 'loading');
                        } 
                        else if (progress.status === 'downloading' || progress.status === 'download') {
                            const file = progress.file || progress.name || 'unknown';
                            
                            if (progress.loaded !== undefined && progress.total !== undefined) {
                                const filePercent = (progress.loaded / progress.total) * 100;
                                fileProgress[file] = filePercent;
                                
                                const files = Object.keys(fileProgress);
                                totalFiles = Math.max(totalFiles, files.length);
                                const totalPercent = files.reduce((sum, f) => sum + fileProgress[f], 0) / totalFiles;
                                
                                const percent = Math.round(totalPercent);
                                this.updateProgress(percent);
                                this.updateStatus(`Téléchargement: ${percent}%`, 'loading');
                            } else {
                                loadedFiles++;
                                const estimatedPercent = Math.min(95, Math.round((loadedFiles / Math.max(totalFiles, 5)) * 100));
                                this.updateProgress(estimatedPercent);
                                this.updateStatus(`Téléchargement en cours... ${loadedFiles} fichier(s)`, 'loading');
                            }
                        } 
                        else if (progress.status === 'loading' || progress.status === 'ready') {
                            this.updateProgress(99);
                            this.updateStatus('Initialisation du modèle...', 'loading');
                        }
                        else if (progress.status === 'done') {
                            this.updateProgress(100);
                        }
                    }
                }
            );

            this.state.isModelLoaded = true;
            this.state.loadedModelKey = modelKey;
            this.showProgress(false);
            this.updateStatus(`Modèle ${modelKey} prêt`, 'ready');
            this.elements.downloadBtn.style.display = 'none';
            this.updateUI();

        } catch (error) {
            this.showProgress(false);
            this.handleError('Erreur de téléchargement', error);
            this.elements.downloadBtn.disabled = false;
        }
    }

    async handleRecording() {
        if (this.state.isRecording) {
            this.stopRecording();
        } else {
            await this.startRecording();
        }
    }

    async startRecording() {
        try {
            this.clearTranscription();
            this.state.isRecording = true;
            this.state.recordingStartTime = Date.now();
            this.updateRecordingButton();

            if (this.state.currentMethod === 'wasm') {
                await this.startWasmRecording();
                this.startRecordingTimer();
            } else {
                await this.startWebSpeechRecording();
            }
        } catch (error) {
            this.handleError('Erreur d\'enregistrement', error);
            this.state.isRecording = false;
            this.updateRecordingButton();
        }
    }

    startRecordingTimer() {
        const model = this.availableModels[this.state.selectedModel];
        const maxDuration = model.maxDuration;
        
        this.recordingTimer = setInterval(() => {
            if (!this.state.isRecording) {
                clearInterval(this.recordingTimer);
                return;
            }
            
            const elapsed = Math.floor((Date.now() - this.state.recordingStartTime) / 1000);
            const remaining = maxDuration - elapsed;
            
            if (this.elements.recordingTimer) {
                this.elements.recordingTimer.textContent = `${elapsed}s / ${maxDuration}s`;
                
                // Alerte quand on approche de la limite
                if (remaining === 5) {
                    this.showNotification(`⏱️ Arrêt recommandé dans ${remaining}s`, 'info');
                }
                
                // Arrêt automatique à la limite
                if (elapsed >= maxDuration) {
                    this.showNotification('⏱️ Durée maximale atteinte', 'info');
                    this.stopRecording();
                }
            }
        }, 1000);
    }

    async startWasmRecording() {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            audio: {
                sampleRate: 16000,
                channelCount: 1,
                echoCancellation: true,
                noiseSuppression: true
            } 
        });

        this.state.mediaRecorder = new MediaRecorder(stream);
        this.state.audioChunks = [];

        this.state.mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
                this.state.audioChunks.push(event.data);
            }
        };

        this.state.mediaRecorder.onstop = () => this.processWasmAudio();
        this.state.mediaRecorder.start();
        
        const langName = this.availableLanguages[this.state.selectedLanguage].name;
        this.updateStatus(`🎤 Enregistrement (${langName})...`, 'recording');
        
        if (this.elements.recordingTimer) {
            this.elements.recordingTimer.style.display = 'block';
        }
    }

    async startWebSpeechRecording() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.state.recognition = new SpeechRecognition();
        
        this.state.recognition.continuous = true;
        this.state.recognition.interimResults = true;
        
        // Utiliser la langue sélectionnée
        const langCode = this.availableLanguages[this.state.selectedLanguage]?.webSpeechCode || 'fr-FR';
        this.state.recognition.lang = langCode;
        
        console.log('[WP STT] Web Speech API - Langue:', langCode);

        this.state.recognition.onstart = () => {
            this.updateStatus('🎤 Écoute en cours...', 'recording');
        };

        this.state.recognition.onresult = (event) => {
            let finalTranscript = '';
            for (let i = event.resultIndex; i < event.results.length; i++) {
                if (event.results[i].isFinal) {
                    finalTranscript += event.results[i][0].transcript;
                }
            }
            if (finalTranscript) {
                this.displayTranscription(finalTranscript, true);
            }
        };

        this.state.recognition.onerror = (event) => {
            this.handleError('Erreur Web Speech API', event.error);
        };

        this.state.recognition.onend = () => {
            this.state.isRecording = false;
            this.updateRecordingButton();
            this.updateStatus('Transcription terminée', 'ready');
            this.showActionButtons();
        };

        this.state.recognition.start();
    }

    stopRecording() {
        this.state.isRecording = false;
        this.updateRecordingButton();
        
        if (this.recordingTimer) {
            clearInterval(this.recordingTimer);
            this.recordingTimer = null;
        }
        
        if (this.elements.recordingTimer) {
            this.elements.recordingTimer.style.display = 'none';
        }

        if (this.state.currentMethod === 'wasm' && this.state.mediaRecorder) {
            this.state.mediaRecorder.stop();
            this.state.mediaRecorder.stream.getTracks().forEach(track => track.stop());
            this.updateStatus('Traitement en cours...', 'loading');
        } else if (this.state.recognition) {
            this.state.recognition.stop();
        }
    }

    async processWasmAudio() {
        try {
            this.state.isProcessing = true;
            const audioBlob = new Blob(this.state.audioChunks, { type: 'audio/webm' });
            const audioData = await this.convertAudioForWhisper(audioBlob);
            
            const model = this.availableModels[this.state.selectedModel];
            const langName = this.availableLanguages[this.state.selectedLanguage].name;
            this.updateStatus(`🧠 Transcription (${langName})...`, 'loading');
            
            // Message spécial pour le modèle Small
            if (this.state.selectedModel === 'small') {
                this.updateStatus(`🧠 Transcription... Peut prendre 10-30s`, 'loading');
            }

            console.log('[WP STT] Transcription avec langue:', this.state.selectedLanguage);

            // Configuration de transcription avec langue FORCÉE et paramètres optimisés
            const transcriptionOptions = {
                chunk_length_s: model.chunkLength, // Adapté au modèle
                stride_length_s: Math.min(5, Math.floor(model.chunkLength / 6)), // Adaptatif
                return_timestamps: false,
                language: this.state.selectedLanguage,
                task: 'transcribe' // Pas de traduction
            };

            console.log('[WP STT] Options de transcription:', transcriptionOptions);

            const result = await this.state.wasmPipeline(audioData, transcriptionOptions);

            console.log('[WP STT] Résultat brut:', result);

            const transcription = result.text || '';
            
            // Nettoyage explicite des données audio
            this.state.audioChunks = [];
            
            if (transcription.trim()) {
                this.displayTranscription(transcription, true);
                this.updateStatus('✅ Transcription terminée', 'ready');
                this.showActionButtons();
            } else {
                this.updateStatus('Aucun texte détecté', 'ready');
            }
        } catch (error) {
            this.handleError('Erreur de transcription', error);
        } finally {
            this.state.isProcessing = false;
            // Double sécurité : vider les chunks audio
            this.state.audioChunks = [];
        }
    }

    async convertAudioForWhisper(audioBlob) {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
        const arrayBuffer = await audioBlob.arrayBuffer();
        const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
        const audioData = audioBuffer.getChannelData(0);
        await audioContext.close();
        return audioData;
    }

    displayTranscription(text, isFinal = false) {
        if (this.elements.transcriptionDisplay) {
            this.elements.transcriptionDisplay.textContent = text;
            this.elements.transcriptionDisplay.classList.remove('placeholder');
        }
    }

    clearTranscription() {
        if (this.elements.transcriptionDisplay) {
            this.elements.transcriptionDisplay.textContent = 'Le texte transcrit apparaîtra ici...';
            this.elements.transcriptionDisplay.classList.add('placeholder');
        }
        this.hideActionButtons();
        
        // Nettoyer les données audio précédentes
        this.state.audioChunks = [];
    }

    showActionButtons() {
        this.elements.actionButtons?.classList.remove('hidden');
    }

    hideActionButtons() {
        this.elements.actionButtons?.classList.add('hidden');
    }

    copyText() {
        const text = this.elements.transcriptionDisplay?.textContent;
        if (text && text !== 'Le texte transcrit apparaîtra ici...') {
            navigator.clipboard.writeText(text).then(() => {
                this.showNotification(this.config.i18n.copied || 'Texte copié !', 'success');
            }).catch(() => {
                this.showNotification('Erreur lors de la copie', 'error');
            });
        }
    }

    insertText() {
        const text = this.elements.transcriptionDisplay?.textContent;
        if (!text || text === 'Le texte transcrit apparaîtra ici...') {
            this.showNotification('Aucun texte à insérer', 'error');
            return;
        }

        if (!this.targetEditor) {
            console.warn('[WP STT] Aucun éditeur cible, tentative de re-détection');
            this.captureActiveEditor();
        }

        if (!this.targetEditor) {
            this.showNotification('Éditeur non détecté', 'error');
            console.error('[WP STT] Aucun éditeur disponible pour l\'insertion');
            return;
        }

        try {
            switch (this.targetEditor.type) {
                case 'gutenberg':
                    this.insertIntoGutenberg(text);
                    break;
                case 'tinymce':
                    this.insertIntoTinyMCE(text);
                    break;
                case 'textarea':
                case 'comment':
                    this.insertIntoTextarea(text);
                    break;
                case 'contenteditable':
                    this.insertIntoContentEditable(text);
                    break;
                default:
                    this.showNotification('Type d\'éditeur non supporté', 'error');
                    return;
            }
            
            this.showNotification(this.config.i18n.inserted || 'Texte inséré !', 'success');
            this.hideModule();
        } catch (error) {
            console.error('[WP STT] Erreur lors de l\'insertion:', error);
            this.showNotification('Erreur lors de l\'insertion', 'error');
        }
    }

    insertIntoGutenberg(text) {
        const { insertBlocks } = wp.data.dispatch('core/block-editor');
        const { createBlock } = wp.blocks;
        const block = createBlock('core/paragraph', { content: text });
        insertBlocks(block);
    }

    insertIntoTinyMCE(text) {
        if (this.targetEditor.editor && !this.targetEditor.editor.isHidden()) {
            this.targetEditor.editor.insertContent(text);
        } else {
            throw new Error('TinyMCE editor not available');
        }
    }

    insertIntoTextarea(text) {
        const element = this.targetEditor.element;
        if (!element) {
            throw new Error('Textarea element not found');
        }

        const cursorPos = element.selectionStart || 0;
        const textBefore = element.value.substring(0, cursorPos);
        const textAfter = element.value.substring(element.selectionEnd || cursorPos);
        
        element.value = textBefore + text + textAfter;
        
        const newCursorPos = cursorPos + text.length;
        element.setSelectionRange(newCursorPos, newCursorPos);
        element.focus();
        
        const event = new Event('input', { bubbles: true });
        element.dispatchEvent(event);
    }

    insertIntoContentEditable(text) {
        const element = this.targetEditor.element;
        if (!element || !element.isContentEditable) {
            throw new Error('ContentEditable element not available');
        }

        element.focus();
        document.execCommand('insertText', false, text);
    }

    updateRecordingButton() {
        if (!this.elements.startBtn) return;

        if (this.state.isRecording) {
            this.elements.startBtn.textContent = 'Arrêter l\'enregistrement';
            this.elements.startBtn.classList.add('recording');
            this.elements.startBtn.setAttribute('aria-pressed', 'true');
        } else {
            this.elements.startBtn.textContent = 'Démarrer l\'enregistrement';
            this.elements.startBtn.classList.remove('recording');
            this.elements.startBtn.setAttribute('aria-pressed', 'false');
        }
    }

    showProgress(show = true) {
        if (this.elements.progressContainer) {
            this.elements.progressContainer.style.display = show ? 'block' : 'none';
        }
    }

    updateProgress(percent) {
        if (this.elements.progressFill) {
            this.elements.progressFill.style.width = `${percent}%`;
            this.elements.progressFill.parentElement.setAttribute('aria-valuenow', percent);
        }
        if (this.elements.progressText) {
            this.elements.progressText.textContent = `${percent}%`;
        }
    }

    updateStatus(text, type = 'ready') {
        if (this.elements.statusText) {
            this.elements.statusText.textContent = text;
        }
        if (this.elements.statusDot) {
            this.elements.statusDot.className = `wp-stt-status-dot ${type}`;
        }
    }

    handleError(message, error) {
        console.error('[WP STT]', message, error);
        this.updateStatus(`❌ ${message}`, 'error');
        this.showNotification(message, 'error');
    }

    toggleModule() {
        this.isModuleVisible ? this.hideModule() : this.showModule();
    }

    showModule() {
        if (this.elements.module && this.elements.overlay) {
            this.elements.module.classList.remove('hidden');
            this.elements.module.setAttribute('aria-hidden', 'false');
            this.elements.overlay.classList.remove('hidden');
            this.elements.overlay.setAttribute('aria-hidden', 'false');
            this.isModuleVisible = true;
            
            if (this.elements.toggleBtn) {
                this.elements.toggleBtn.setAttribute('aria-expanded', 'true');
            }
            
            const firstFocusable = this.elements.module.querySelector('button:not(:disabled), select, input');
            if (firstFocusable) {
                setTimeout(() => firstFocusable.focus(), 100);
            }
        }
    }

    hideModule() {
        if (this.elements.module && this.elements.overlay) {
            this.elements.module.classList.add('hidden');
            this.elements.module.setAttribute('aria-hidden', 'true');
            this.elements.overlay.classList.add('hidden');
            this.elements.overlay.setAttribute('aria-hidden', 'true');
            this.isModuleVisible = false;
            
            if (this.elements.toggleBtn) {
                this.elements.toggleBtn.setAttribute('aria-expanded', 'false');
            }
            
            if (this.state.isRecording) {
                this.stopRecording();
            }
        }
    }

    showNotification(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `wp-stt-toast wp-stt-toast-${type}`;
        toast.textContent = message;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'polite');
        
        Object.assign(toast.style, {
            position: 'fixed',
            top: '32px',
            right: '20px',
            padding: '12px 20px',
            borderRadius: '4px',
            color: 'white',
            fontSize: '14px',
            fontWeight: '500',
            zIndex: '9999999',
            opacity: '0',
            transform: 'translateY(-20px)',
            transition: 'all 0.3s ease',
            maxWidth: '300px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
            backgroundColor: type === 'error' ? '#dc3545' : type === 'success' ? '#28a745' : '#007bff'
        });

        document.body.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '1';
            toast.style.transform = 'translateY(0)';
        }, 100);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(-20px)';
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }
}

// Initialisation après chargement du DOM
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initWPSpeechToText);
} else {
    initWPSpeechToText();
}

function initWPSpeechToText() {
    window.wpSpeechToText = new WPSpeechToTextModule();
}