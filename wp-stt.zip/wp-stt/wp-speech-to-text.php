<?php
/**
 * Plugin Name: WP Speech to Text
 * Plugin URI: https://github.com/marie2026/wp-stt
 * Description: Plugin de speech-to-text utilisant WASM (Transformers.js) et Web Speech API avec interface accessible
 * Version: 1.0.0
 * Author: Marie
 * Author URI: https://github.com/marie2026
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-speech-to-text
 * Domain Path: /languages
 */

// Sécurité : empêcher l'accès direct
if (!defined('ABSPATH')) {
    exit;
}

// Constantes du plugin
define('WP_STT_VERSION', '1.0.0');
define('WP_STT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_STT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WP_STT_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Classe principale du plugin
 */
class WP_Speech_To_Text {
    
    private static $instance = null;
    
    /**
     * Singleton
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructeur
     */
    private function __construct() {
        $this->init_hooks();
    }
    
    /**
     * Initialisation des hooks
     */
    private function init_hooks() {
        // Activation/Désactivation
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Chargement des scripts et styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Ajout du bouton dans l'éditeur
        add_action('media_buttons', array($this, 'add_editor_button'), 15);
        
        // Injection du module HTML
        add_action('wp_footer', array($this, 'render_speech_module'));
        add_action('admin_footer', array($this, 'render_speech_module'));
        
        // AJAX pour l'insertion dans l'éditeur
        add_action('wp_ajax_wpstt_insert_text', array($this, 'ajax_insert_text'));
        
        // Shortcode
        add_shortcode('speech_to_text', array($this, 'shortcode_handler'));
    }
    
    /**
     * Activation du plugin
     */
    public function activate() {
        // Options par défaut
        add_option('wpstt_default_method', 'wasm');
        add_option('wpstt_language', 'fr');
        add_option('wpstt_enabled_locations', array('post', 'page'));
    }
    
    /**
     * Désactivation du plugin
     */
    public function deactivate() {
        // Nettoyage si nécessaire
    }
    
    /**
     * Chargement des assets frontend
     */
    public function enqueue_frontend_assets() {
        // CSS
        wp_enqueue_style(
            'wp-stt-styles',
            WP_STT_PLUGIN_URL . 'assets/css/speech-styles.css',
            array(),
            WP_STT_VERSION
        );
        
        // Configuration inline AVANT l'import map
        wp_add_inline_script('jquery', $this->get_inline_config(), 'after');
        
        // Import map pour Transformers.js (ES6 modules)
        add_action('wp_head', array($this, 'add_importmap'), 5);
        add_action('admin_head', array($this, 'add_importmap'), 5);
        
        // Script principal (ES6 module)
        wp_enqueue_script(
            'wp-stt-module',
            WP_STT_PLUGIN_URL . 'assets/js/speech-module.js',
            array(),
            WP_STT_VERSION,
            true
        );
        
        // Marquer comme module ES6
        add_filter('script_loader_tag', array($this, 'add_module_attribute'), 10, 3);
    }
    
    /**
     * Chargement des assets admin
     */
    public function enqueue_admin_assets($hook) {
        // Sur toutes les pages admin pour le bouton flottant
        $this->enqueue_frontend_assets();
    }
    
    /**
     * Configuration JavaScript inline
     */
    private function get_inline_config() {
        $config = array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpstt_nonce'),
            'language' => get_option('wpstt_language', 'fr'),
            'defaultMethod' => get_option('wpstt_default_method', 'wasm'),
            'isAdmin' => is_admin(),
            'i18n' => array(
                'ready' => __('Prêt', 'wp-speech-to-text'),
                'recording' => __('Enregistrement en cours...', 'wp-speech-to-text'),
                'processing' => __('Traitement en cours...', 'wp-speech-to-text'),
                'error' => __('Erreur', 'wp-speech-to-text'),
                'copied' => __('Texte copié !', 'wp-speech-to-text'),
                'inserted' => __('Texte inséré !', 'wp-speech-to-text'),
            )
        );
        
        return 'window.wpSttConfig = ' . wp_json_encode($config) . ';';
    }
    
    /**
     * Ajout de l'import map pour Transformers.js
     */
    public function add_importmap() {
        // Éviter les doublons
        static $importmap_added = false;
        if ($importmap_added) {
            return;
        }
        $importmap_added = true;
        
        ?>
        <script type="importmap">
        {
            "imports": {
                "@xenova/transformers": "https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2/dist/transformers.min.js"
            }
        }
        </script>
        <?php
    }
    
    /**
     * Ajout de l'attribut type="module" aux scripts ES6
     */
    public function add_module_attribute($tag, $handle, $src) {
        if ('wp-stt-module' === $handle) {
            $tag = '<script type="module" src="' . esc_url($src) . '" id="' . $handle . '-js"></script>';
        }
        return $tag;
    }
    
    /**
     * Ajout du bouton dans l'éditeur
     */
    public function add_editor_button() {
        ?>
        <button 
            type="button" 
            id="wp-stt-editor-button" 
            class="button wp-stt-trigger"
            aria-label="<?php esc_attr_e('Ouvrir la saisie vocale', 'wp-speech-to-text'); ?>"
            title="<?php esc_attr_e('Saisie vocale', 'wp-speech-to-text'); ?>"
        >
            <span class="dashicons dashicons-microphone" style="margin-top: 3px;"></span>
            <?php _e('Saisie vocale', 'wp-speech-to-text'); ?>
        </button>
        <?php
    }
    
    /**
     * Rendu du module speech-to-text
     */
    public function render_speech_module() {
        // Éviter les doublons
        static $module_rendered = false;
        if ($module_rendered) {
            return;
        }
        $module_rendered = true;
        
        include WP_STT_PLUGIN_DIR . 'templates/speech-module.php';
    }
    
    /**
     * Gestion AJAX pour insertion
     */
    public function ajax_insert_text() {
        check_ajax_referer('wpstt_nonce', 'nonce');
        
        $text = isset($_POST['text']) ? sanitize_textarea_field($_POST['text']) : '';
        
        if (empty($text)) {
            wp_send_json_error(array('message' => __('Aucun texte à insérer', 'wp-speech-to-text')));
        }
        
        wp_send_json_success(array('text' => $text));
    }
    
    /**
     * Shortcode [speech_to_text]
     */
    public function shortcode_handler($atts) {
        $atts = shortcode_atts(array(
            'method' => 'wasm',
            'button_text' => __('🎤 Saisie vocale', 'wp-speech-to-text'),
        ), $atts);
        
        ob_start();
        ?>
        <button 
            type="button" 
            class="wp-stt-trigger wp-stt-shortcode-button"
            data-method="<?php echo esc_attr($atts['method']); ?>"
            aria-label="<?php esc_attr_e('Ouvrir la saisie vocale', 'wp-speech-to-text'); ?>"
        >
            <?php echo esc_html($atts['button_text']); ?>
        </button>
        <?php
        return ob_get_clean();
    }
}

// Initialisation du plugin
function wp_speech_to_text_init() {
    return WP_Speech_To_Text::get_instance();
}

add_action('plugins_loaded', 'wp_speech_to_text_init');