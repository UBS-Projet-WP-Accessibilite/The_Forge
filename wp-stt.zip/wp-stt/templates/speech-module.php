<?php
/**
 * Template du module Speech-to-Text
 * 
 * @package WP_Speech_To_Text
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<!-- Bouton flottant pour ouvrir le module -->
<button 
    type="button" 
    id="wp-stt-toggle-btn" 
    class="wp-stt-floating-button" 
    aria-label="<?php esc_attr_e('Ouvrir/Fermer la saisie vocale', 'wp-speech-to-text'); ?>"
    aria-expanded="false"
    aria-controls="wp-stt-module"
>
    <span aria-hidden="true">🎤</span>
    <span class="sr-only"><?php esc_html_e('Saisie vocale', 'wp-speech-to-text'); ?></span>
</button>

<!-- Module principal -->
<div id="wp-stt-module" class="wp-stt-module hidden" role="dialog" aria-labelledby="wp-stt-title" aria-modal="true">
    <div class="wp-stt-header">
        <div class="wp-stt-header-content">
            <div class="wp-stt-icon" aria-hidden="true">🎤</div>
            <h3 id="wp-stt-title"><?php esc_html_e('Saisie vocale', 'wp-speech-to-text'); ?></h3>
        </div>
        <button 
            type="button" 
            id="wp-stt-close" 
            class="wp-stt-close-btn" 
            aria-label="<?php esc_attr_e('Fermer la saisie vocale', 'wp-speech-to-text'); ?>"
        >
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    
    <div class="wp-stt-content">
        <!-- Section méthode -->
        <div class="wp-stt-method-section">
            <label for="wp-stt-method-select" class="wp-stt-label">
                <?php esc_html_e('Méthode de reconnaissance :', 'wp-speech-to-text'); ?>
            </label>
            <select id="wp-stt-method-select" class="wp-stt-method-select" aria-describedby="wp-stt-description-text">
                <option value="wasm"><?php esc_html_e('WASM - Transformers.js (hors ligne)', 'wp-speech-to-text'); ?></option>
                <option value="webspeech"><?php esc_html_e('Web Speech API (en ligne)', 'wp-speech-to-text'); ?></option>
            </select>
        </div>

        <!-- Description -->
        <div class="wp-stt-description" role="region" aria-live="polite">
            <p id="wp-stt-description-text">
                <?php esc_html_e('Utilise Transformers.js avec le modèle Whisper. Fonctionne hors ligne après téléchargement.', 'wp-speech-to-text'); ?>
            </p>
        </div>

        <!-- Paramètres WASM -->
        <div id="wp-stt-wasm-settings" class="wp-stt-wasm-settings">
            <!-- Sélection du modèle -->
            <div class="wp-stt-setting-group">
                <label for="wp-stt-model-select" class="wp-stt-label">
                    <?php esc_html_e('Modèle Whisper :', 'wp-speech-to-text'); ?>
                </label>
                <select id="wp-stt-model-select" class="wp-stt-select">
                    <!-- Rempli dynamiquement par JavaScript -->
                </select>
                <div id="wp-stt-model-info" class="wp-stt-model-info">
                    <!-- Rempli dynamiquement par JavaScript -->
                </div>
                
                <!-- Avertissement de performance -->
                <div id="wp-stt-performance-warning" class="wp-stt-performance-warning" style="display: none;">
                    <!-- Rempli dynamiquement par JavaScript -->
                </div>
            </div>

            <!-- Sélection de la langue -->
            <div class="wp-stt-setting-group">
                <label for="wp-stt-language-select" class="wp-stt-label">
                    <?php esc_html_e('Langue de transcription :', 'wp-speech-to-text'); ?>
                </label>
                <select id="wp-stt-language-select" class="wp-stt-select">
                    <!-- Rempli dynamiquement par JavaScript -->
                </select>
            </div>
        </div>

        <!-- Section téléchargement (WASM uniquement) -->
        <div id="wp-stt-download-section" class="wp-stt-download-section">
            <button 
                type="button" 
                id="wp-stt-download" 
                class="wp-stt-download-btn"
                aria-describedby="wp-stt-download-info"
            >
                <span aria-hidden="true">📥</span> <?php esc_html_e('Télécharger le modèle (requis)', 'wp-speech-to-text'); ?>
            </button>
            <span id="wp-stt-download-info" class="sr-only">
                <?php esc_html_e('Télécharge le modèle de reconnaissance vocale WASM', 'wp-speech-to-text'); ?>
            </span>
            
            <!-- Barre de progression -->
            <div id="wp-stt-progress-container" style="display: none;" role="status" aria-live="polite">
                <div class="wp-stt-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-labelledby="wp-stt-progress-text">
                    <div id="wp-stt-progress-fill"></div>
                </div>
                <div id="wp-stt-progress-text" class="wp-stt-progress-text">0%</div>
            </div>
        </div>

        <!-- Timer d'enregistrement -->
        <div id="wp-stt-recording-timer" class="wp-stt-recording-timer" style="display: none;">
            0s / 30s
        </div>

        <!-- Bouton démarrer -->
        <button 
            type="button" 
            id="wp-stt-start" 
            class="wp-stt-start-btn" 
            disabled
            aria-pressed="false"
        >
            <?php esc_html_e('Démarrer l\'enregistrement', 'wp-speech-to-text'); ?>
        </button>

        <!-- Zone de transcription -->
        <div class="wp-stt-transcription-area" role="region" aria-label="<?php esc_attr_e('Zone de transcription', 'wp-speech-to-text'); ?>">
            <div id="wp-stt-transcription" class="placeholder" aria-live="polite" aria-atomic="true">
                <?php esc_html_e('Le texte transcrit apparaîtra ici...', 'wp-speech-to-text'); ?>
            </div>
        </div>

        <!-- Boutons d'action -->
        <div id="wp-stt-actions" class="wp-stt-actions hidden">
            <button 
                type="button" 
                id="wp-stt-copy" 
                class="wp-stt-action-btn"
                aria-label="<?php esc_attr_e('Copier le texte transcrit', 'wp-speech-to-text'); ?>"
            >
                <span aria-hidden="true">📋</span> <?php esc_html_e('Copier', 'wp-speech-to-text'); ?>
            </button>
            <button 
                type="button" 
                id="wp-stt-insert" 
                class="wp-stt-action-btn"
                aria-label="<?php esc_attr_e('Insérer le texte dans l\'éditeur', 'wp-speech-to-text'); ?>"
            >
                <span aria-hidden="true">✍️</span> <?php esc_html_e('Insérer', 'wp-speech-to-text'); ?>
            </button>
        </div>

        <!-- Indicateur de status -->
        <div class="wp-stt-status" role="status" aria-live="polite">
            <span id="wp-stt-status-text"><?php esc_html_e('Prêt', 'wp-speech-to-text'); ?></span>
            <div id="wp-stt-status-dot" class="wp-stt-status-dot ready" aria-hidden="true"></div>
        </div>
    </div>
</div>

<!-- Overlay pour fermer en cliquant à l'extérieur -->
<div id="wp-stt-overlay" class="wp-stt-overlay hidden" aria-hidden="true"></div>