<?php
if (!defined('ABSPATH')) { exit; }

class WPAIAlt_Providers {
    private $opts;
    private $logger;

    public function __construct($opts, $logger) {
        $this->opts = $opts;
        $this->logger = $logger;
    }

    public function test_provider($which = '') {
        $which = $which ?: ($this->opts['provider'] ?? 'ollama');
        if ($which === 'ollama') {
            $base = rtrim($this->opts['ollama_base'] ?? 'http://localhost:11434', '/');
            $this->logger->maybe_debug('Test Ollama', $base);
            $r = wp_remote_get($base . '/api/version', array('timeout'=>5));
            if (is_wp_error($r)) {
                return array('ok'=>false, 'data'=>array('error'=>$r->get_error_message()));
            }
            $code = wp_remote_retrieve_response_code($r);
            $body = wp_remote_retrieve_body($r);
            if ($code === 200) {
                // liste des modèles
                $tags = wp_remote_get($base . '/api/tags', array('timeout'=>8));
                $models = array();
                if (!is_wp_error($tags) && wp_remote_retrieve_response_code($tags) === 200) {
                    $json = json_decode(wp_remote_retrieve_body($tags), true);
                    foreach (($json['models'] ?? array()) as $m) {
                        $models[] = $m['name'] ?? '';
                    }
                }
                return array('ok'=>true, 'data'=>array(
                    'version'=>json_decode($body, true)['version'] ?? '',
                    'models'=>$models,
                    'base'=>$base,
                ));
            }
            return array('ok'=>false, 'data'=>array('code'=>$code, 'body'=>$body));
        }

        if ($which === 'gemini') {
            $key = $this->opts['gemini_key'] ?? '';
            if (!$key) {
                return array('ok'=>false, 'data'=>array('error'=>'API key manquante'));
            }
            $model = urlencode($this->opts['gemini_model'] ?? 'gemini-1.5-flash');
            $url = 'https://generativelanguage.googleapis.com/v1beta/models/'.$model.':generateContent?key='.$key;
            $this->logger->maybe_debug('Test Gemini', $model);

            $payload = array(
                'contents' => array(
                    array('parts'=>array(array('text'=>'ping')))
                )
            );
            $r = wp_remote_post($url, array(
                'timeout'=>10,
                'headers'=>array('Content-Type'=>'application/json'),
                'body'=>wp_json_encode($payload),
            ));
            if (is_wp_error($r)) {
                return array('ok'=>false, 'data'=>array('error'=>$r->get_error_message()));
            }
            $code = wp_remote_retrieve_response_code($r);
            $body = wp_remote_retrieve_body($r);
            if ($code === 200) {
                return array('ok'=>true, 'data'=>array('note'=>'Appel réussi. Les quotas officiels ne sont pas exposés par une API publique.'));
            }
            return array('ok'=>false, 'data'=>array('code'=>$code, 'body'=>$body));
        }

        return array('ok'=>false, 'data'=>array('error'=>'provider inconnu'));
    }

    /** Génère un ALT à partir d'une URL d'image. */
    public function generate_alt_from_url($image_url, $max_len = 160, $lang = 'fr') {
        $prov = $this->opts['provider'] ?? 'ollama';
        if ($prov === 'ollama') {
            return $this->ollama_alt($image_url, $max_len, $lang);
        }
        if ($prov === 'gemini') {
            return $this->gemini_alt($image_url, $max_len, $lang);
        }
        return array('ok'=>false, 'error'=>'provider inconnu');
    }

    private function sanitize_alt($text, $max_len) {
        $text = wp_strip_all_tags($text);
        $text = html_entity_decode($text, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8');
        $text = preg_replace('/\s+/', ' ', $text);
        $text = trim($text);
        if (strlen($text) > $max_len) {
            $text = mb_substr($text, 0, $max_len);
        }
        return $text;
    }

    private function ollama_alt($image_url, $max_len, $lang) {
        $base = rtrim($this->opts['ollama_base'] ?? 'http://localhost:11434', '/');
        $model = $this->opts['ollama_model'] ?? 'moondream:latest';

        $prompt = "Décris l'image pour un attribut ALT en ".$lang.
            " en une seule phrase concise et factuelle (pas de jugement, pas de 'image de'). Maximum ".$max_len." caractères.";

        $payload = array(
            'model' => $model,
            'prompt'=> $prompt,
            'images'=> array($image_url),
            'stream'=> false,
        );
        $this->logger->maybe_debug('Ollama payload', array('base'=>$base, 'model'=>$model, 'image'=>$image_url));

        $r = wp_remote_post($base.'/api/generate', array(
            'timeout'=>60,
            'headers'=>array('Content-Type'=>'application/json'),
            'body'=>wp_json_encode($payload),
        ));

        if (is_wp_error($r)) {
            return array('ok'=>false, 'error'=>$r->get_error_message());
        }
        $code = wp_remote_retrieve_response_code($r);
        $body = wp_remote_retrieve_body($r);
        if ($code !== 200) {
            return array('ok'=>false, 'error'=>"HTTP $code: $body");
        }
        $json = json_decode($body, true);
        $out  = $json['response'] ?? '';
        if (!$out) {
            return array('ok'=>false, 'error'=>'réponse vide');
        }
        $alt = $this->sanitize_alt($out, $max_len);
        $this->logger->maybe_debug('Ollama alt', $alt);
        return array('ok'=>true, 'alt'=>$alt);
    }

    private function gemini_alt($image_url, $max_len, $lang) {
        $key = $this->opts['gemini_key'] ?? '';
        if (!$key) { return array('ok'=>false, 'error'=>'API key Gemini manquante'); }
        $model = $this->opts['gemini_model'] ?? 'gemini-1.5-flash';

        $prompt = "Décris l'image pour un attribut ALT en ".$lang.
            " en une seule phrase concise et factuelle (pas de jugement, pas de 'image de'). Maximum ".$max_len." caractères.";

        $url = 'https://generativelanguage.googleapis.com/v1beta/models/'.rawurlencode($model).':generateContent?key='.$key;
        $payload = array(
            'contents' => array(array(
                'parts' => array(
                    array('text'=>$prompt),
                    array(
                        'inline_data' => array(
                            'mime_type' => 'image/jpeg'
                        )
                    )
                )
            )),
            'safetySettings'=>array(),
        );

        // Télécharger l'image et encoder
        $img = wp_remote_get($image_url, array('timeout'=>20));
        if (is_wp_error($img)) { return array('ok'=>false, 'error'=>'Téléchargement image: '.$img->get_error_message()); }
        $code = wp_remote_retrieve_response_code($img);
        if ($code !== 200) { return array('ok'=>false, 'error'=>'Téléchargement image HTTP '.$code); }
        $data = wp_remote_retrieve_body($img);
        $payload['contents'][0]['parts'][1]['inline_data']['data'] = base64_encode($data);

        $this->logger->maybe_debug('Gemini call', array('model'=>$model));

        $r = wp_remote_post($url, array(
            'timeout'=>60,
            'headers'=>array('Content-Type'=>'application/json'),
            'body'=>wp_json_encode($payload),
        ));
        if (is_wp_error($r)) { return array('ok'=>false, 'error'=>$r->get_error_message()); }
        $code = wp_remote_retrieve_response_code($r);
        $body = wp_remote_retrieve_body($r);
        if ($code !== 200) { return array('ok'=>false, 'error'=>"HTTP $code: $body"); }
        $json = json_decode($body, true);
        $text = '';
        if (isset($json['candidates'][0]['content']['parts'])) {
            foreach ($json['candidates'][0]['content']['parts'] as $p) {
                if (!empty($p['text'])) { $text .= $p['text']; }
            }
        }
        if (!$text) { return array('ok'=>false, 'error'=>'réponse vide'); }
        $alt = $this->sanitize_alt($text, $max_len);
        return array('ok'=>true, 'alt'=>$alt);
    }
}
