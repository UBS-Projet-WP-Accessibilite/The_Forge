<?php
if (!defined('ABSPATH')) { exit; }

class WPAIAlt_Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'menu'));
        add_filter('plugin_action_links_' . plugin_basename(WPAIALT_DIR.'wp-ai-alt.php'), array($this, 'links'));
    }

    public function links($links) {
        $links[] = '<a href="'.admin_url('admin.php?page=wpai-ai-alt').'">Outils</a>';
        $links[] = '<a href="'.admin_url('admin.php?page=wpai-ai-alt-settings').'">Réglages</a>';
        $links[] = '<a href="'.admin_url('admin.php?page=wpai-ai-alt-help').'">Aide</a>';
        return $links;
    }

    public function menu() {
        // Menu principal avec icône oeil
        add_menu_page(
            'WP AI Alt',
            'WP AI Alt',
            'upload_files',
            'wpai-ai-alt',
            array($this, 'page_tools'),
            'dashicons-visibility',
            58
        );
        // Sous-menus
        add_submenu_page('wpai-ai-alt', 'Outils', 'Outils', 'upload_files', 'wpai-ai-alt', array($this, 'page_tools'));
        add_submenu_page('wpai-ai-alt', 'Réglages', 'Réglages', 'manage_options', 'wpai-ai-alt-settings', array($this, 'page_settings'));
        add_submenu_page('wpai-ai-alt', 'Aide', 'Aide', 'read', 'wpai-ai-alt-help', array($this, 'page_help'));
    }

    public function page_tools() { include WPAIALT_DIR . 'views/page-tools.php'; }
    public function page_settings() {
        if (isset($_POST['wpai_alt_save']) && check_admin_referer('wpai_alt_save_settings')) {
            $opts = get_option('wpai_alt_options', array());
            $opts['provider']     = sanitize_text_field($_POST['provider'] ?? 'ollama');
            $opts['ollama_base']  = esc_url_raw($_POST['ollama_base'] ?? 'http://localhost:11434');
            $opts['ollama_model'] = sanitize_text_field($_POST['ollama_model'] ?? 'moondream:latest');
            $opts['gemini_key']   = sanitize_text_field($_POST['gemini_key'] ?? '');
            $opts['gemini_model'] = sanitize_text_field($_POST['gemini_model'] ?? 'gemini-1.5-flash');
            $opts['max_length']   = max(10, intval($_POST['max_length'] ?? 160));
            $opts['language']     = sanitize_text_field($_POST['language'] ?? 'fr');
            $opts['debug']        = isset($_POST['debug']);
            $opts['quota_month_soft'] = max(0, intval($_POST['quota_month_soft'] ?? 0));
            update_option('wpai_alt_options', $opts);
            echo '<div class="updated"><p>Réglages enregistrés.</p></div>';
        }
        include WPAIALT_DIR . 'views/page-settings.php';
    }
    public function page_help() { include WPAIALT_DIR . 'views/page-help.php'; }
}
