<?php
if (!defined('ABSPATH')) { exit; }

class WPAIAlt_Logger {
    private $entries = array();

    public function maybe_debug($msg, $data = null) {
        $opts = get_option('wpai_alt_options', array());
        if (!($opts['debug'] ?? false)) { return; }
        $line = '['.current_time('mysql').'] ' . $msg;
        if ($data !== null) {
            $line .= ' | ' . (is_string($data) ? $data : wp_json_encode($data));
        }
        $this->entries[] = $line;
    }

    public function get_log() {
        return $this->entries;
    }
}
