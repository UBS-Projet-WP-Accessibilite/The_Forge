<?php
if (!defined('ABSPATH')) { exit; }
?>
<div class="wrap wpai-alt">
  <h1>WP AI Alt — Aide (Images / Texte alternatif)</h1>
  <p>Guide pas à pas pour configurer <strong>Ollama</strong> (local) ou <strong>Gemini Vision</strong> (hébergé) et générer automatiquement des ALT.</p>

  <div class="wpai-grid">
    <div class="wpai-card">
      <h2>0) À qui s'adresse ce guide</h2>
      <p>Débutant WordPress bienvenu. Objectif: générer des attributs ALT de qualité.</p>
    </div>

    <div class="wpai-card">
      <h2>1) Prérequis rapides</h2>
      <ul>
        <li>WordPress + PHP 8+</li>
        <li><strong>Option A</strong>: Ollama local avec modèle <code>moondream:latest</code> ou <code>llava:latest</code>.</li>
        <li><strong>Option B</strong>: Gemini Vision via Google AI Studio (clé API).</li>
      </ul>
    </div>

    <div class="wpai-card">
      <h2>2) Option A — Ollama (local)</h2>
      <ol>
        <li>Installez Ollama. Vérifiez: <code>http://localhost:11434</code> affiche “Ollama is running”.</li>
        <li>Installez un modèle: <code>ollama pull moondream:latest</code></li>
        <li><strong>LocalWP</strong>:
          <pre>curl http://localhost:11434/api/version
curl http://host.docker.internal:11434/api/version
ip route | awk '/default/ {print $3}'   # ex. 172.17.0.1
curl http://172.17.0.1:11434/api/version</pre>
          La première URL qui répond sera votre <em>URL de base</em>.</li>
        <li>Dans <em>Réglages → Ollama</em>, collez l’URL et le modèle. Utilisez <em>Détecter automatiquement</em> puis <em>Tester connexion</em>.</li>
      </ol>
    </div>

    <div class="wpai-card">
      <h2>3) Option B — Gemini Vision</h2>
      <ol>
        <li>Créez une clé dans Google AI Studio. Copiez-la.</li>
        <li>Dans <em>Réglages → Gemini Vision</em>, collez la clé et le modèle, puis <em>Tester connexion</em>.</li>
        <li>Les quotas officiels ne sont pas fournis par API. Le plugin gère un quota “soft”.</li>
      </ol>
    </div>

    <div class="wpai-card">
      <h2>4) Utilisation</h2>
      <ul>
        <li>Menu <strong>WP AI Alt → Outils</strong>: bouton <em>Rechercher</em>, sélection, <em>Tout générer</em>.</li>
        <li>Journal visible si <em>Mode debug</em> activé.</li>
      </ul>
    </div>

    <div class="wpai-card">
      <h2>5) Dépannage</h2>
      <ul>
        <li>Firewall: autoriser le port 11434 pour Ollama.</li>
        <li>Si <code>host.docker.internal</code> ne répond pas, utilisez l’IP passerelle.</li>
      </ul>
    </div>

    <div class="wpai-card">
      <h2>6) Ergonomie, idées à intégrer</h2>
      <ul>
        <li>Assistant d’installation en 3 étapes.</li>
        <li>Prévisualisation sur image d’exemple.</li>
        <li>Logs exportables.</li>
      </ul>
    </div>
  </div>
</div>
