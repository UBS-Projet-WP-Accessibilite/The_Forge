<?php
if (!defined('ABSPATH')) { exit; }
$opts = get_option('wpai_alt_options', array());
?>
<div class="wrap wpai-alt">
  <h1>WP AI Alt — Outils</h1>
  <p>Générez rapidement des ALT pour les images sans texte alternatif. Mode debug recommandé pour diagnostiquer.</p>

  <div class="wpai-card">
    <h2>1) Recherche d'images sans ALT</h2>
    <button class="button button-primary" id="wpai-scan">Rechercher</button>
    <span id="wpai-scan-status"></span>
    <div id="wpai-scan-results"></div>
  </div>

  <div class="wpai-card">
    <h2>2) Traitement de masse</h2>
    <p>Sélectionnez puis lancez la génération.</p>
    <button class="button" id="wpai-generate-selected" disabled>Générer pour la sélection</button>
    <button class="button" id="wpai-generate-all" disabled>Tout générer</button>
    <div id="wpai-progress"></div>
  </div>

  <div class="wpai-card">
    <h2>Journal (debug)</h2>
    <pre id="wpai-log" style="max-height:260px; overflow:auto; background:#111; color:#9f9; padding:10px;"></pre>
  </div>
</div>
