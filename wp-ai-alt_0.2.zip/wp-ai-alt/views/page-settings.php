<?php
if (!defined('ABSPATH')) { exit; }
$opts = get_option('wpai_alt_options', array());
?>
<div class="wrap wpai-alt">
  <h1>WP AI Alt — Réglages</h1>

  <form method="post">
    <?php wp_nonce_field('wpai_alt_save_settings'); ?>
    <div class="wpai-grid">
      <div class="wpai-card">
        <h2>Moteur</h2>
        <label><input type="radio" name="provider" value="ollama" <?php checked(($opts['provider'] ?? '')==='ollama'); ?>> Ollama (local)</label><br>
        <label><input type="radio" name="provider" value="gemini" <?php checked(($opts['provider'] ?? '')==='gemini'); ?>> Gemini Vision (hébergé)</label>
      </div>

      <div class="wpai-card">
        <h2>Ollama local</h2>
        <label>URL de base<br>
          <input type="text" name="ollama_base" value="<?php echo esc_attr($opts['ollama_base'] ?? 'http://localhost:11434'); ?>" class="regular-text">
        </label>
        <p class="description">Exemples: <code>http://localhost:11434</code> • <code>http://host.docker.internal:11434</code> • passerelle Docker.</p>
        <label>Modèle<br>
          <input type="text" name="ollama_model" value="<?php echo esc_attr($opts['ollama_model'] ?? 'moondream:latest'); ?>" class="regular-text">
        </label>
        <p>
          <button type="button" class="button" id="wpai-detect-local">Détecter automatiquement</button>
          <button type="button" class="button" data-which="ollama" id="wpai-test-ollama">Tester connexion</button>
        </p>
        <div id="wpai-ollama-detect"></div>
      </div>

      <div class="wpai-card">
        <h2>Gemini Vision</h2>
        <label>API Key<br>
          <input type="password" name="gemini_key" value="<?php echo esc_attr($opts['gemini_key'] ?? ''); ?>" class="regular-text">
        </label>
        <label>Modèle<br>
          <input type="text" name="gemini_model" value="<?php echo esc_attr($opts['gemini_model'] ?? 'gemini-1.5-flash'); ?>" class="regular-text">
        </label>
        <p><button type="button" class="button" data-which="gemini" id="wpai-test-gemini">Tester connexion</button></p>
        <div id="wpai-gemini-test"></div>
      </div>

      <div class="wpai-card">
        <h2>Génération</h2>
        <label>Langue<br>
          <input type="text" name="language" value="<?php echo esc_attr($opts['language'] ?? 'fr'); ?>" class="small-text">
        </label>
        <label>Longueur max<br>
          <input type="number" name="max_length" value="<?php echo esc_attr($opts['max_length'] ?? 160); ?>" class="small-text">
        </label>
        <label><input type="checkbox" name="debug" <?php checked(!empty($opts['debug'])); ?>> Mode debug</label>
      </div>

      <div class="wpai-card">
        <h2>Quota</h2>
        <label>Limite mensuelle (0 = illimité)<br>
          <input type="number" name="quota_month_soft" value="<?php echo esc_attr($opts['quota_month_soft'] ?? 0); ?>" class="small-text">
        </label>
        <p>Mois: <?php echo esc_html(($opts['usage_month']['month'] ?? date('Y-m'))); ?> — Appels: <strong><?php echo intval($opts['usage_month']['calls'] ?? 0); ?></strong></p>
      </div>
    </div>

    <p><button class="button button-primary" name="wpai_alt_save" value="1">Enregistrer</button></p>
  </form>
</div>
