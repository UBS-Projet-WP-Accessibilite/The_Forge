<?php
/**
 * Plugin Name: WP AI Alt
 * Description: Génère et gère des textes alternatifs (ALT) pour les images avec Ollama local ou Gemini Vision. Inclut une page d'aide détaillée, un mode debug et un traitement de masse.
 * Version: 1.1.1
 * Author: ChatGPT
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) { exit; }

define('WPAIALT_VER', '1.1.1');
define('WPAIALT_DIR', plugin_dir_path(__FILE__));
define('WPAIALT_URL', plugin_dir_url(__FILE__));

require_once WPAIALT_DIR . 'inc/class-wpaialt-logger.php';
require_once WPAIALT_DIR . 'inc/class-wpaialt-admin.php';
require_once WPAIALT_DIR . 'inc/class-wpaialt-providers.php';

/** Activation: options par défaut. */
function wpai_alt_activate() {
    $defaults = array(
        'provider' => 'ollama', // ollama|gemini
        'ollama_base' => 'http://localhost:11434',
        'ollama_model' => 'moondream:latest',
        'gemini_key'  => '',
        'gemini_model'=> 'gemini-1.5-flash',
        'max_length'  => 160,
        'language'    => 'fr',
        'debug'       => false,
        'quota_month_soft' => 0,
        'usage_month' => array('month'=>date('Y-m'), 'calls'=>0),
    );
    add_option('wpai_alt_options', $defaults);
}
register_activation_hook(__FILE__, 'wpai_alt_activate');

/** Reset usage monthly. */
function wpai_alt_maybe_reset_usage() {
    $opts = get_option('wpai_alt_options', array());
    $month = date('Y-m');
    if (!isset($opts['usage_month']) || !is_array($opts['usage_month']) || ($opts['usage_month']['month'] ?? '') !== $month) {
        $opts['usage_month'] = array('month'=>$month, 'calls'=>0);
        update_option('wpai_alt_options', $opts);
    }
}
add_action('init', 'wpai_alt_maybe_reset_usage');

/** Assets. */
function wpai_alt_admin_assets($hook) {
    if (strpos($hook, 'wpai-ai-alt') === false && strpos($hook,'wp-ai-alt') === false) { return; }
    wp_enqueue_style('wpai-alt-admin', WPAIALT_URL.'assets/admin.css', array(), WPAIALT_VER);
    wp_enqueue_script('wpai-alt-admin', WPAIALT_URL.'assets/admin.js', array('jquery'), WPAIALT_VER, true);
    wp_localize_script('wpai-alt-admin', 'WPAIAlt', array(
        'ajax' => admin_url('admin-ajax.php'),
        'nonce'=> wp_create_nonce('wpai_alt_nonce'),
        'i18n' => array(
            'scanning'=>'Recherche des images…',
            'generating'=>'Génération en cours…',
        ),
    ));
}
add_action('admin_enqueue_scripts', 'wpai_alt_admin_assets');

/** AJAX: scanner les images sans ALT. */
function wpai_alt_ajax_scan() {
    check_ajax_referer('wpai_alt_nonce','nonce');
    if (!current_user_can('upload_files')) { wp_send_json_error('forbidden', 403); }

    $paged = isset($_POST['paged']) ? max(1,intval($_POST['paged'])) : 1;
    $per  = isset($_POST['per']) ? max(1,intval($_POST['per'])) : 200;

    $args = array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'post_mime_type' => 'image',
        'posts_per_page' => $per,
        'paged'          => $paged,
        'fields'         => 'ids',
        'meta_query'     => array(
            'relation' => 'OR',
            array('key' => '_wp_attachment_image_alt', 'compare' => 'NOT EXISTS'),
            array('key' => '_wp_attachment_image_alt', 'value' => '', 'compare' => '='),
        ),
    );
    $q = new WP_Query($args);
    $ids = $q->posts;

    $total = $q->found_posts;

    $items = array();
    foreach ($ids as $id) {
        $url = wp_get_attachment_url($id);
        $items[] = array('id'=>$id, 'url'=>$url, 'title'=>get_the_title($id));
    }
    wp_send_json_success(array('items'=>$items, 'total'=>$total, 'page'=>$paged, 'pages'=>max(1,ceil($total/$per))));
}
add_action('wp_ajax_wpai_alt_scan', 'wpai_alt_ajax_scan');

/** AJAX: générer un ALT pour un ID. */
function wpai_alt_ajax_generate() {
    check_ajax_referer('wpai_alt_nonce','nonce');
    if (!current_user_can('upload_files')) { wp_send_json_error('forbidden', 403); }

    $id  = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if (!$id) { wp_send_json_error('missing id'); }
    $url = wp_get_attachment_url($id);
    if (!$url) { wp_send_json_error('missing url'); }

    $opts = get_option('wpai_alt_options', array());
    $max  = intval($opts['max_length'] ?? 160);
    $lang = sanitize_text_field($opts['language'] ?? 'fr');

    $logger = new WPAIAlt_Logger();
    $logger->maybe_debug('Génération demandée pour ID '.$id.' ('.$url.')');

    $provider = new WPAIAlt_Providers($opts, $logger);
    $result = $provider->generate_alt_from_url($url, $max, $lang);

    if ($result['ok']) {
        $alt = sanitize_text_field($result['alt']);
        update_post_meta($id, '_wp_attachment_image_alt', $alt);

        // usage soft quota
        $opts['usage_month']['calls'] = intval($opts['usage_month']['calls']??0) + 1;
        update_option('wpai_alt_options', $opts);

        wp_send_json_success(array('id'=>$id, 'alt'=>$alt, 'log'=>$logger->get_log()));
    } else {
        wp_send_json_error(array('id'=>$id, 'error'=>$result['error'], 'log'=>$logger->get_log()));
    }
}
add_action('wp_ajax_wpai_alt_generate', 'wpai_alt_ajax_generate');

/** AJAX: test provider + auto-détection LocalWP. */
function wpai_alt_ajax_test_provider() {
    check_ajax_referer('wpai_alt_nonce','nonce');
    if (!current_user_can('manage_options')) { wp_send_json_error('forbidden', 403); }

    $which = sanitize_text_field($_POST['which'] ?? '');
    $opts = get_option('wpai_alt_options', array());
    $logger = new WPAIAlt_Logger();

    $prov = new WPAIAlt_Providers($opts, $logger);
    $out = $prov->test_provider($which);

    $resp = array('ok'=>$out['ok'], 'data'=>$out['data'], 'log'=>$logger->get_log());
    wp_send_json_success($resp);
}
add_action('wp_ajax_wpai_alt_test_provider', 'wpai_alt_ajax_test_provider');

/** AJAX: récupérer info réseau pour LocalWP. */
function wpai_alt_ajax_probe_network() {
    check_ajax_referer('wpai_alt_nonce','nonce');
    if (!current_user_can('manage_options')) { wp_send_json_error('forbidden', 403); }

    $candidates = array(
        'http://localhost:11434',
        'http://host.docker.internal:11434',
    );
    // Ajout passerelle par défaut si possible
    $gateway = null;
    if (function_exists('shell_exec')) {
        $ip = @shell_exec('ip route | awk "/default/ {print $3}"');
        if ($ip) {
            $ip = trim($ip);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                $gateway = 'http://' . $ip . ':11434';
                $candidates[] = $gateway;
            }
        }
    }
    $hits = array();
    foreach ($candidates as $base) {
        $r = wp_remote_get($base . '/api/version', array('timeout'=>3));
        if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) {
            $hits[] = array('base'=>$base, 'version'=>json_decode(wp_remote_retrieve_body($r), true)['version'] ?? '');
        }
    }
    wp_send_json_success(array('candidates'=>$candidates, 'hits'=>$hits, 'gateway'=>$gateway));
}
add_action('wp_ajax_wpai_alt_probe_network', 'wpai_alt_probe_network');

// Init admin UI
new WPAIAlt_Admin();
