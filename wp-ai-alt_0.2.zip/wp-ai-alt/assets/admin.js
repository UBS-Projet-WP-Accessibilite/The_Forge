(function($){
  function log(lines){
    var el = $('#wpai-log');
    if(!el.length) return;
    if($.isArray(lines)){ lines.forEach(function(l){ el.append(document.createTextNode(l+"\n")); }); }
    else if(typeof lines==='string'){ el.append(document.createTextNode(lines+"\n")); }
    el.scrollTop(el[0].scrollHeight);
  }

  function renderList(items){
    var wrap = $('#wpai-scan-results').empty();
    if(!items.length){ wrap.html('<p>Aucune image sans ALT trouvée.</p>'); $('#wpai-generate-all').prop('disabled', true); $('#wpai-generate-selected').prop('disabled', true); return; }
    var tbl = $('<table class="wp-list-table widefat fixed striped"><thead><tr><th><input type="checkbox" id="wpai-check-all"></th><th>ID</th><th>Image</th><th>Titre</th><th>ALT actuel</th></tr></thead><tbody></tbody></table>');
    items.forEach(function(it){
      var alt = '—';
      tbl.find('tbody').append(
        $('<tr>').append(
          $('<td>').append($('<input type="checkbox" class="wpai-row">').data('id', it.id)),
          $('<td>').text(it.id),
          $('<td>').append($('<img>').attr('src', it.url).css({maxWidth:'80px', height:'auto'})),
          $('<td>').text(it.title || ''),
          $('<td>').text(alt)
        )
      );
    });
    wrap.append(tbl);
    $('#wpai-generate-all').prop('disabled', false);
    $('#wpai-generate-selected').prop('disabled', false);
    $('#wpai-check-all').on('change', function(){ $('.wpai-row').prop('checked', this.checked); });
  }

  $('#wpai-scan').on('click', function(){
    $('#wpai-scan-status').text(WPAIAlt.i18n.scanning);
    $.post(WPAIAlt.ajax, {action:'wpai_alt_scan', nonce:WPAIAlt.nonce, per:200}, function(resp){
      $('#wpai-scan-status').empty();
      if(!resp || !resp.success){ alert('Erreur de scan'); return; }
      renderList(resp.data.items || []);
      log(['Scan total: '+resp.data.total+' images sans ALT potentielles.']);
    });
  });

  function processQueue(ids){
    var idx = 0, ok=0, ko=0;
    function step(){
      if(idx>=ids.length){ $('#wpai-progress').text('Terminé. OK: '+ok+' — Erreurs: '+ko); return; }
      var id = ids[idx++];
      $('#wpai-progress').text('Traitement '+idx+'/'+ids.length+' (ID '+id+')');
      $.post(WPAIAlt.ajax, {action:'wpai_alt_generate', nonce:WPAIAlt.nonce, id:id}, function(resp){
        if(resp && resp.success){ ok++; log(resp.data.log || []); }
        else{ ko++; if(resp && resp.data){ log(resp.data.log || []); log('Erreur: '+(resp.data.error||'inconnue')); } }
        step();
      }).fail(function(){ ko++; log('Erreur réseau'); step(); });
    }
    step();
  }

  $('#wpai-generate-all').on('click', function(){
    var ids = [];
    $('.wpai-row').each(function(){ ids.push($(this).data('id')); });
    if(!ids.length){ alert('Aucune image listée'); return; }
    processQueue(ids);
  });

  $('#wpai-generate-selected').on('click', function(){
    var ids = [];
    $('.wpai-row:checked').each(function(){ ids.push($(this).data('id')); });
    if(!ids.length){ alert('Sélectionnez des images'); return; }
    processQueue(ids);
  });

  // Settings: tests
  $('#wpai-test-ollama, #wpai-test-gemini').on('click', function(){
    var which = $(this).data('which');
    $(this).prop('disabled', true);
    $.post(WPAIAlt.ajax, {action:'wpai_alt_test_provider', nonce:WPAIAlt.nonce, which:which}, function(resp){
      if(!resp || !resp.success){ alert('Test échoué'); return; }
      var box = which==='gemini' ? $('#wpai-gemini-test') : $('#wpai-ollama-detect');
      box.empty();
      if(resp.data.ok){
        box.append($('<p>').text('OK').css('color','green'));
        if(which==='ollama' && resp.data.data){
          var d = resp.data.data;
          var p = $('<p>').text('Détecté '+(d.version||'')+' sur '+(d.base||''));
          box.append(p);
          if(d.models && d.models.length){
            box.append($('<p>').text('Modèles: '+d.models.join(', ')));
          }
        }
      } else {
        box.append($('<p>').text('Erreur: '+(resp.data.data && (resp.data.data.error || resp.data.data.code) || 'inconnue')).css('color','red'));
      }
      if(resp.data.log){ log(resp.data.log); }
    }).always(()=>$(this).prop('disabled', false));
  });

  $('#wpai-detect-local').on('click', function(){
    var box = $('#wpai-ollama-detect').empty().text('Détection en cours…');
    $.post(WPAIAlt.ajax, {action:'wpai_alt_probe_network', nonce:WPAIAlt.nonce}, function(resp){
      box.empty();
      if(!resp || !resp.success){ box.text('Échec de détection'); return; }
      var hits = resp.data.hits || [];
      if(hits.length){
        hits.forEach(function(h){
          var btn = $('<button class="button">').text('Utiliser '+h.base+' (v'+h.version+')').on('click', function(){
            $('input[name="ollama_base"]').val(h.base);
          });
          box.append($('<p>').append(btn));
        });
      } else {
        box.text('Aucun service détecté automatiquement. Essayez manuellement.');
      }
      if(resp.data.gateway){ box.append($('<p>').text('Passerelle détectée: '+resp.data.gateway)); }
    });
  });

})(jQuery);
