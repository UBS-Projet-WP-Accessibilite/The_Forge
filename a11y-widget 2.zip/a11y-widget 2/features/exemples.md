<!-- Sections retirées : anciens exemples auditifs et navigation alternative supprimés. -->
