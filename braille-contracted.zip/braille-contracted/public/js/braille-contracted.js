jQuery(document).ready(function($) {
    // État global
    let isScreenReaderDetected = false;
    let lastTranslatedText = '';
    let braillePanel = null;
    let brailleToggle = null;
    let currentFocusElement = null;

    // Initialisation
    initBrailleModule();

    function initBrailleModule() {
        createBrailleToggle();
        createBraillePanel();
        loadBrailleCSS();
        startScreenReaderDetection();
        setupEventHandlers();
    }

    function loadBrailleCSS() {
        const style = document.createElement('style');
        style.textContent = `
            #braille-contract-toggle {
                position: fixed;
                bottom: 20px;
                right: 80px;
                width: 50px;
                height: 50px;
                background: #4CAF50;
                color: white;
                border: none;
                border-radius: 50%;
                cursor: pointer;
                box-shadow: 0 2px 5px rgba(0,0,0,0.2);
                z-index: 999999;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 20px;
                transition: all 0.3s ease;
            }
            #braille-contract-toggle:hover { background: #45a049; transform: scale(1.05); }
            #braille-contract-toggle.active { background: #388e3c; }
            #braille-contract-panel {
                position: fixed;
                bottom: 80px;
                right: 20px;
                width: 90%;
                max-width: 500px;
                background: white;
                border: 1px solid #ddd;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                display: none;
                max-height: 70vh;
                overflow-y: auto;
                z-index: 999998;
                margin: 0 10px;
                border-left: 4px solid #4CAF50;
            }
            @media (min-width: 768px) { #braille-contract-panel { width: 400px; margin: 0; } }
            #braille-contract-panel.visible { display: block; animation: slideUp 0.3s ease-out; }
            @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
            .braille-contract-header { display: flex; justify-content: space-between; align-items: center; padding: 15px; border-bottom: 1px solid #eee; }
            .braille-contract-header h2 { margin: 0; font-size: 1.1em; color: #333; }
            .braille-contract-close { background: none; border: none; font-size: 20px; cursor: pointer; color: #777; }
            .braille-contract-close:hover { color: #333; }
            .braille-contract-content { padding: 15px; }
            .braille-contract-result { margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee; }
            .braille-contract-original { font-size: 0.9em; color: #666; margin-bottom: 8px; word-break: break-word; }
            .braille-contract-output {
                font-family: monospace;
                font-size: 1.6em;
                line-height: 1.8;
                padding: 12px;
                background: #f0f8f0;
                border-radius: 6px;
                border: 1px solid #eee;
                min-height: 50px;
                white-space: pre-wrap;
                word-break: break-word;
            }
            .braille-char { display: inline-block; margin-right: 1px; line-height: 1.4; }
            .sr-only {
                position: absolute;
                width: 1px;
                height: 1px;
                padding: 0;
                margin: -1px;
                overflow: hidden;
                clip: rect(0, 0, 0, 0);
                white-space: nowrap;
                border: 0;
            }
            body.screen-reader-active:before {
                content: "screenreader";
                position: absolute;
                height: 1px;
                width: 1px;
                overflow: hidden;
                clip: rect(1px, 1px, 1px, 1px);
            }
        `;
        document.head.appendChild(style);
    }

    function createBrailleToggle() {
        brailleToggle = document.createElement('button');
        brailleToggle.id = 'braille-contract-toggle';
        brailleToggle.setAttribute('aria-label', 'Activer le braille contracté');
        brailleToggle.innerHTML = '⠇⠡';
        document.body.appendChild(brailleToggle);

        brailleToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            if (this.classList.contains('active')) {
                showBraillePanel();
                announceToScreenReader("Mode braille contracté activé.");
            } else {
                hideBraillePanel();
                announceToScreenReader("Mode braille contracté désactivé.");
            }
        });
    }

    function createBraillePanel() {
        braillePanel = document.createElement('div');
        braillePanel.id = 'braille-contract-panel';
        braillePanel.setAttribute('role', 'dialog');
        braillePanel.setAttribute('aria-modal', 'true');
        braillePanel.setAttribute('aria-labelledby', 'braille-contract-title');
        braillePanel.setAttribute('aria-hidden', 'true');
        braillePanel.style.display = 'none';

        braillePanel.innerHTML = `
            <div class="braille-contract-header">
                <h2 id="braille-contract-title">Braille Contracté (Grade 2)</h2>
                <button class="braille-contract-close" aria-label="Fermer le panneau">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="braille-contract-content">
                <div class="braille-contract-result">
                    <div class="braille-contract-original" aria-label="Texte original"></div>
                    <div class="braille-contract-output" aria-hidden="true"></div>
                    <div class="sr-only">Traduction en braille contracté du texte ci-dessus.</div>
                </div>
            </div>
        `;
        document.body.appendChild(braillePanel);

        braillePanel.querySelector('.braille-contract-close').addEventListener('click', function() {
            hideBraillePanel();
            brailleToggle.classList.remove('active');
        });
    }

    function showBraillePanel() {
        braillePanel.style.display = 'block';
        setTimeout(() => {
            braillePanel.classList.add('visible');
            braillePanel.setAttribute('aria-hidden', 'false');
        }, 10);
    }

    function hideBraillePanel() {
        braillePanel.classList.remove('visible');
        braillePanel.setAttribute('aria-hidden', 'true');
        setTimeout(() => {
            braillePanel.style.display = 'none';
        }, 300);
    }

    function setupEventHandlers() {
        // Sélection de texte
        document.addEventListener('mouseup', handleTextSelection);
        document.addEventListener('keyup', handleTextSelection);

        // Navigation clavier et ARIA
        document.addEventListener('focusin', handleFocusChange);

        // Détection des touches de navigation
        document.addEventListener('keydown', handleKeyboardNavigation);
    }

    function startScreenReaderDetection() {
        // Méthode 1: Détection via CSS
        detectScreenReaderViaCSS();

        // Méthode 2: Écoute des raccourcis clavier spécifiques
        setupKeyboardShortcuts();

        // Méthode 3: Détection via les attributs ARIA
        setupARIADetection();

        // Méthode 4: Vérification périodique
        setInterval(checkScreenReaderStatus, 2000);
    }

    function detectScreenReaderViaCSS() {
        const style = window.getComputedStyle(document.body, ':before');
        const content = style.getPropertyValue('content');
        if (content && content.includes('screenreader')) {
            activateScreenReaderMode();
        }
    }

    function setupKeyboardShortcuts() {
        const screenReaderShortcuts = [
            {key: 'Tab', ctrl: true},      // NVDA: Ctrl+Tab
            {key: 'ArrowDown', alt: true}, // JAWS: Alt+Flèche bas
            {key: 'ArrowUp', alt: true},   // JAWS: Alt+Flèche haut
            {key: 'Escape', ctrl: true},   // NVDA: Ctrl+Échap
            {key: 'Insert', shift: true}, // JAWS: Shift+Insert
            {key: 'F6', shift: true},      // NVDA: Shift+F6
            {key: 'F7', shift: true}       // JAWS: Shift+F7
        ];

        document.addEventListener('keydown', function(e) {
            if (brailleToggle.classList.contains('active')) return;

            screenReaderShortcuts.forEach(combo => {
                if (e.key === combo.key &&
                    (combo.ctrl ? e.ctrlKey : true) &&
                    (combo.alt ? e.altKey : true) &&
                    (combo.shift ? e.shiftKey : true)) {
                    activateScreenReaderMode();
                }
            });
        });
    }

    function setupARIADetection() {
        // Vérifier la présence massive d'attributs ARIA
        const ariaElements = document.querySelectorAll('[aria-live], [aria-label], [role]');
        if (ariaElements.length > 10) {
            activateScreenReaderMode();
        }

        // Écouter les changements dynamiques
        const observer = new MutationObserver(function(mutations) {
            if (brailleToggle.classList.contains('active')) return;

            let ariaCount = 0;
            mutations.forEach(mutation => {
                if (mutation.addedNodes) {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === 1) {
                            ariaCount += node.querySelectorAll('[aria-live], [aria-label], [role]').length;
                        }
                    });
                }
            });

            if (ariaCount > 5) {
                activateScreenReaderMode();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['aria-live', 'aria-label', 'role']
        });
    }

    function checkScreenReaderStatus() {
        if (brailleToggle.classList.contains('active')) return;

        // Vérifier les classes spécifiques aux lecteurs d'écran
        if (document.querySelector('.nvda, .jaws, .voiceover, .screen-reader')) {
            activateScreenReaderMode();
            return;
        }

        // Vérifier les éléments de focus virtuels
        const virtualFocus = document.querySelectorAll('[id^="virtual-focus-"], [class^="focus-"]');
        if (virtualFocus.length > 0) {
            activateScreenReaderMode();
            return;
        }

        // Vérifier les propriétés d'accessibilité
        if (window.accessibilityEnabled) {
            activateScreenReaderMode();
            return;
        }
    }

    function activateScreenReaderMode() {
        if (brailleToggle.classList.contains('active')) return;

        brailleToggle.classList.add('active');
        showBraillePanel();
        announceToScreenReader("Lecteur d'écran détecté. Mode braille contracté activé automatiquement.");

        // Traduire l'élément actuellement focalisé
        if (document.activeElement && document.activeElement !== document.body) {
            handleFocusChange({ target: document.activeElement });
        }
    }

    function handleTextSelection(e) {
        if (!brailleToggle.classList.contains('active')) return;

        const selection = window.getSelection();
        if (!selection || selection.toString().length === 0) return;

        const selectedText = selection.toString().trim();
        if (selectedText === lastTranslatedText) return;

        lastTranslatedText = selectedText;
        translateText(selectedText);
    }

    function handleFocusChange(e) {
        if (!brailleToggle.classList.contains('active')) return;

        const element = e.target;

        // Ignorer les éléments de notre interface
        if (element.closest('#braille-contract-panel, #braille-contract-toggle')) {
            return;
        }

        // Mémoriser l'élément courant pour la navigation clavier
        currentFocusElement = element;

        let textToTranslate = '';

        // Champs de formulaire
        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA' ||
            element.isContentEditable || element.getAttribute('role') === 'textbox') {

            const label = document.querySelector(`label[for="${element.id}"]`);
            if (label) {
                textToTranslate = `Champ: ${label.textContent.trim()} - `;
            }
            textToTranslate += element.value || element.textContent;
        }
        // Liens et boutons
        else if (element.tagName === 'A' || element.tagName === 'BUTTON') {
            textToTranslate = element.textContent.trim();
            if (element.getAttribute('aria-label')) {
                textToTranslate = element.getAttribute('aria-label');
            }
        }
        // Éléments avec ARIA
        else if (element.hasAttribute('aria-label') || element.hasAttribute('aria-labelledby')) {
            textToTranslate = element.getAttribute('aria-label') ||
                             (element.getAttribute('aria-labelledby') ?
                              document.getElementById(element.getAttribute('aria-labelledby')).textContent : '') ||
                             element.textContent.trim();
        }
        // Autres éléments avec du texte
        else if (element.textContent.trim()) {
            textToTranslate = element.textContent.trim();
        }

        if (textToTranslate) {
            translateText(textToTranslate);
        }
    }

    function handleKeyboardNavigation(e) {
        if (!brailleToggle.classList.contains('active')) return;

        // Touches de navigation (flèches, tabulation)
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.key)) {
            setTimeout(() => {
                if (document.activeElement && document.activeElement !== currentFocusElement) {
                    handleFocusChange({ target: document.activeElement });
                }
            }, 50);
        }
    }

    function translateText(text) {
        if (!text) return;

        document.querySelector('.braille-contract-original').textContent = text;
        document.querySelector('.braille-contract-output').innerHTML = '<div class="sr-only">Traduction en cours...</div>';

        jQuery.ajax({
            url: brailleContracted.ajaxurl,
            type: 'POST',
            data: {
                action: 'braille_contract_translate',
                text: text,
                nonce: brailleContracted.nonce
            },
            success: function(response) {
                if (response.success) {
                    document.querySelector('.braille-contract-output').innerHTML = response.data.braille;
                }
            },
            error: function() {
                document.querySelector('.braille-contract-output').innerHTML = '<div class="sr-only">Erreur de traduction</div>';
            }
        });
    }

    function announceToScreenReader(message) {
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'assertive');
        announcement.setAttribute('class', 'sr-only');
        announcement.textContent = message;
        document.body.appendChild(announcement);

        setTimeout(() => {
            announcement.remove();
        }, 2000);
    }
});
